-- Add credits column to user table
ALTER TABLE "user" ADD COLUMN IF NOT EXISTS "credits" INTEGER DEFAULT 5;

-- Create Transaction table
CREATE TABLE IF NOT EXISTS "Transaction" (
  "id" SERIAL PRIMARY KEY,
  "transactionType" TEXT NOT NULL,
  "transactionStatus" BOOLEAN NOT NULL DEFAULT true,
  "creditAmount" INTEGER NOT NULL,
  "description" TEXT,
  "stripePaymentId" TEXT UNIQUE,
  "userId" INTEGER NOT NULL,
  "createBy" TEXT,
  "createAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updateBy" TEXT,
  "updateAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "delFlag" BOOLEAN NOT NULL DEFAULT false,
  CONSTRAINT "Transaction_userId_fkey" FOREIGN KEY ("userId") REFERENCES "user"("id") ON DELETE CASCADE ON UPDATE CASCADE
);

-- Create indexes for Transaction
CREATE INDEX IF NOT EXISTS "Transaction_userId_idx" ON "Transaction"("userId");
CREATE INDEX IF NOT EXISTS "Transaction_stripePaymentId_idx" ON "Transaction"("stripePaymentId");
CREATE INDEX IF NOT EXISTS "Transaction_createAt_idx" ON "Transaction"("createAt");

-- Create TransactionType enum
DO $$ BEGIN
  CREATE TYPE "TransactionType" AS ENUM ('IN', 'OUT');
EXCEPTION
  WHEN duplicate_object THEN null;
END $$;

-- Update Transaction table to use enum
ALTER TABLE "Transaction" ALTER COLUMN "transactionType" TYPE "TransactionType" USING "transactionType"::"TransactionType";

-- Create CreditPackage table
CREATE TABLE IF NOT EXISTS "CreditPackage" (
  "id" SERIAL PRIMARY KEY,
  "name" TEXT UNIQUE NOT NULL,
  "credits" INTEGER NOT NULL,
  "bonusCredits" INTEGER NOT NULL DEFAULT 0,
  "priceUsd" DOUBLE PRECISION NOT NULL,
  "priceVnd" DOUBLE PRECISION NOT NULL,
  "stripePriceId" TEXT,
  "isActive" BOOLEAN NOT NULL DEFAULT true,
  "displayOrder" INTEGER NOT NULL DEFAULT 0,
  "createAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updateAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- Create index for CreditPackage
CREATE INDEX IF NOT EXISTS "CreditPackage_isActive_displayOrder_idx" ON "CreditPackage"("isActive", "displayOrder");

-- Insert credit packages
INSERT INTO "CreditPackage" ("name", "credits", "bonusCredits", "priceUsd", "priceVnd", "displayOrder")
VALUES 
  ('Starter', 50, 0, 2, 50000, 1),
  ('Basic', 125, 25, 5, 125000, 2),
  ('Popular', 275, 75, 10, 250000, 3),
  ('Premium', 625, 125, 20, 500000, 4)
ON CONFLICT ("name") DO UPDATE SET
  "credits" = EXCLUDED."credits",
  "bonusCredits" = EXCLUDED."bonusCredits",
  "priceUsd" = EXCLUDED."priceUsd",
  "priceVnd" = EXCLUDED."priceVnd",
  "displayOrder" = EXCLUDED."displayOrder";
