import paramiko

hostname = "160.250.180.132"
username = "root"
password = "Do@nhkiet262205"

def execute_ssh_command(command):
    try:
        client = paramiko.SSHClient()
        client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        client.connect(hostname, username=username, password=password)
        
        print(f"--- Executing: {command} ---")
        stdin, stdout, stderr = client.exec_command(command)
        
        output = stdout.read().decode().strip()
        error = stderr.read().decode().strip()
        
        if output:
            print(output)
        if error:
            print(f"Error/Stderr: {error}")
            
        client.close()
    except Exception as e:
        print(f"Connection failed: {e}")

if __name__ == "__main__":
    print("Checking if user exists in DB...")
    # We can use docker exec to run psql inside the postgres container
    # Password is in env var POSTGRES_PASSWORD=290503Sang.
    cmd = 'docker exec glowlab_postgres psql -U physio_db -d physio_db -c "SELECT * FROM \\"public\\".\\"user\\" WHERE email = \'krildelier99@gmail.com\';"'
    execute_ssh_command(cmd)
