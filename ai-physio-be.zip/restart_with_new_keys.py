import paramiko
import time

hostname = "160.250.180.132"
username = "root"
password = "Do@nhkiet262205"

def execute_ssh_command(command):
    try:
        client = paramiko.SSHClient()
        client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        client.connect(hostname, username=username, password=password)
        
        print(f"--- Executing: {command} ---")
        stdin, stdout, stderr = client.exec_command(command)
        
        output = stdout.read().decode().strip()
        error = stderr.read().decode().strip()
        
        if output:
            print(output)
        if error:
            print(f"Error/Stderr: {error}")
            
        client.close()
    except Exception as e:
        print(f"Connection failed: {e}")

if __name__ == "__main__":
    print("Stopping old container...")
    execute_ssh_command('docker stop glowlab_backend')
    execute_ssh_command('docker rm glowlab_backend')
    
    print("\nStarting container with NEW KEYS...")
    start_cmd = """docker run -d \\
--name glowlab_backend \\
--network glowlab_glowlab_network \\
-p 3000:3000 \\
-e STRIPE_SECRET_KEY=sk_test_51SR6hxPofBTvOXyOkCNZzLSks11IrUpP03ymouaCI6QC4I91lZKSmOpn02OUUdKkQmYVkZYXK7iVG9G0kEd3wCz200TqIrV4Wa \\
-e STRIPE_PUBLISHABLE_KEY=pk_test_51SR6hxPofBTvOXyOgfTqc2CwRZex2Oe1u0NesBJKFOAD3MgxxbzQqInnzpbTNODCC0rv2QjuPOMyUp9RzwMHXXTr00jGlA5ohH \\
-e JWT_SECRET=production-secret-key-change-this-123456 \\
-e REFRESH_TOKEN_SECRET=production-refresh-secret-123456 \\
-e GEMINI_API_KEY=AIzaSyDummyKeyForTesting123456789 \\
-e DATABASE_URL=postgresql://physio_db:290503Sang.@glowlab_postgres:5432/physio_db \\
-e PORT=3000 \\
-e NODE_ENV=development \\
-e STRIPE_BASE_URL_LOCAL=http://160.250.180.132:3000 \\
-e GOOGLE_WEB_CLIENT_ID=474899214737-v83c6o8elkm1d9g9i49shpgun3jmp9h1.apps.googleusercontent.com \\
-e GOOGLE_ANDROID_CLIENT_ID=474899214737-d15hrivskcck92piqakl9ugctdsungo6.apps.googleusercontent.com \\
-e GOOGLE_WEB_CLIENT_SECRET=dummy_secret_for_id_token_flow \\
--health-cmd="node -e \\"require('http').get('http://127.0.0.1:3000/healthz', (r) => {if (r.statusCode !== 200) throw new Error(r.statusCode)})\\"" \\
--health-interval=30s \\
--health-timeout=10s \\
--health-retries=3 \\
--restart unless-stopped \\
--entrypoint node \\
glowlab-backend:new dist/server.js"""
    
    execute_ssh_command(start_cmd)
    
    print("\nWaiting 10s...")
    time.sleep(10)
    
    print("\nChecking logs...")
    execute_ssh_command('docker logs glowlab_backend --tail 20')
    
    print("\nTesting endpoint with new keys...")
    execute_ssh_command('curl -X POST -s "http://localhost:3000/payment/payment-sheet?amount=10&email=test@example.com" | python3 -m json.tool')
