const { PrismaClient } = require('@prisma/client');

console.log('DATABASE_URL:', process.env.DATABASE_URL);

const prisma = new PrismaClient({
  log: ['query', 'error', 'info', 'warn'],
});

prisma.user.findMany()
  .then(result => {
    console.log('✅ Connected! Found', result.length, 'users');
  })
  .catch(error => {
    console.error('❌ Error:', error.message);
    console.error('Full error:', error);
  })
  .finally(() => {
    prisma.$disconnect();
  });
