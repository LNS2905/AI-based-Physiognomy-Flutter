import paramiko

hostname = "160.250.180.132"
username = "root"
password = "Do@nhkiet262205"

def execute_ssh_command(command):
    try:
        client = paramiko.SSHClient()
        client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        client.connect(hostname, username=username, password=password)
        
        print(f"--- Executing: {command} ---")
        stdin, stdout, stderr = client.exec_command(command)
        
        output = stdout.read().decode().strip()
        error = stderr.read().decode().strip()
        
        if output:
            print(output)
        if error:
            print(f"Error/Stderr: {error}")
            
        client.close()
    except Exception as e:
        print(f"Connection failed: {e}")

if __name__ == "__main__":
    print("Creating stripe test script on VPS...")
    
    stripe_script = """
import stripe
import sys

stripe.api_key = "sk_test_51QTDsECUavwJmGCRXNfLd0aFPrAnb7TgMDxFqTTDGMWQNOZ3RlO5N9Y5RWxfLz6fRKfJa3NFGGkCm37kbmFXUJQ200vZUJAYwt"

try:
    print("Testing Stripe connection...")
    # List customers
    customers = stripe.Customer.list(limit=1)
    print(f"Successfully listed customers. Count: {len(customers.data)}")
    
    # Create ephemeral key (this requires a customer ID)
    if len(customers.data) > 0:
        customer_id = customers.data[0].id
        print(f"Testing Ephemeral Key creation for customer {customer_id}...")
        key = stripe.EphemeralKey.create(
            customer=customer_id,
            stripe_version="2024-06-20"
        )
        print("Successfully created Ephemeral Key")
    else:
        print("No customers found to test Ephemeral Key")
        
except Exception as e:
    print(f"Stripe Error: {e}")
    sys.exit(1)
"""
    
    # Escape quotes for echo
    escaped_script = stripe_script.replace('"', '\\"')
    
    # Write to file
    create_cmd = f"cat <<EOF > /root/test_stripe.py\n{stripe_script}\nEOF"
    execute_ssh_command(create_cmd)
    
    print("\nRunning stripe test script...")
    execute_ssh_command("python3 /root/test_stripe.py")
