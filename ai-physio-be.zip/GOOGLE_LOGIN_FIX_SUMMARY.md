# Google Login Fix - Summary

## Problem Identified

**Root Cause**: Client ID Mismatch between Frontend and Backend

### Frontend Configuration
- Location: `lib/core/services/google_sign_in_service.dart`
- Uses `serverClientId: '474899214737-v83c6o8elkm1d9g9i49shpgun3jmp9h1.apps.googleusercontent.com'`
- This is a **Web Client ID**
- Google generates ID tokens with this Web Client ID as the `aud` (audience) claim

### Backend Configuration (Before Fix)
- Location: `src/services/auth.service.ts` → `loginWithGoogleIdToken` method
- Was trying to verify tokens using `googleAndroidClientId`
- Verification failed because token audience (Web Client ID) didn't match expected audience (Android Client ID)

### Error Symptoms
- Status: 500 Internal Server Error
- Error Message: `{"message":"Internal server error","code":"INTERNAL_ERROR","data":""}`
- Log showed: `AuthApiService: Google login response status: 500`

## Solution Implemented

### Backend Changes
Modified `loginWithGoogleIdToken` method to try verification with **both** client IDs:

1. **Primary**: Try verification with `googleWebClientId` (matches frontend configuration)
2. **Fallback**: If Web Client verification fails, try `googleAndroidClientId`
3. **Error Handling**: Throw `INVALID_GOOGLE_TOKEN` if both fail

### Files Modified

#### Local (Source)
- `c:\Code\ai-physio-be\src\services\auth.service.ts` (lines 145-170)

#### Remote (Deployed)
- VPS: `160.250.180.132`
- Container: `glowlab_backend`
- File: `/app/dist/services/auth.service.js`
- Method: Patched compiled JavaScript file directly
- Container restarted to apply changes

## Deployment Process

1. Connected to VPS via SSH (root@160.250.180.132)
2. Retrieved current `auth.service.js` from Docker container
3. Applied fix to JavaScript file
4. Uploaded patched file back to container
5. Restarted `glowlab_backend` container

## Testing Recommendation

1. Open Flutter app
2. Tap "Đăng nhập với Google" button
3. Select Google account (krildelier99@gmail.com from logs)
4. Verify successful login (should receive access/refresh tokens)
5. Check that user is redirected to home screen

## Technical Details

### Code Changes (TypeScript)
```typescript
public async loginWithGoogleIdToken(idToken: string): Promise<AuthResponse> {
  try {
    // Try Web Client ID first
    const ticket = await webClient.verifyIdToken({
      idToken,
      audience: config.auth.googleWebClientId,
    });
    const payload = ticket.getPayload();
    if (payload?.email) {
      return this.upsertAndIssue(payload);
    }
  } catch (e) {
    // Fallback to Android Client ID
    try {
      const ticket = await androidClient.verifyIdToken({
        idToken,
        audience: config.auth.googleAndroidClientId,
      });
      const payload = ticket.getPayload();
      if (payload?.email) {
        return this.upsertAndIssue(payload);
      }
    } catch (e2) {
      throw new ErrorResponseV2(ErrorCode.INVALID_GOOGLE_TOKEN);
    }
  }
  throw new ErrorResponseV2(ErrorCode.INVALID_GOOGLE_TOKEN);
}
```

## Future Improvements

1. **Proper Deployment Pipeline**: Instead of patching compiled files, rebuild Docker image with updated source code
2. **Environment Variable Verification**: Ensure `GOOGLE_WEB_CLIENT_ID` matches the `serverClientId` used in Flutter app
3. **Logging**: Add logging to track which client ID successfully verified the token
4. **Error Messages**: Return more specific error messages for debugging (e.g., "Token audience mismatch")

## Files Created for Deployment

- `read_remote_file.py`: Script to read files from Docker container
- `deploy_auth_fix.py`: Script to deploy patched file and restart container
- `explore_container.py`: Script to explore container filesystem
- `remote_auth_service.js`: Patched JavaScript file

## Status

✅ **Fix Deployed Successfully**
✅ **Container Restarted**
🔄 **Ready for Testing**

Date: 2025-11-20
Time: 21:15 (GMT+7)
