# 💳 STRIPE PAYMENT IMPLEMENTATION PLAN
## AI-Physio Backend - Detailed Implementation Guide

> **Objective:** Implement Stripe payment flow in ai-physio-be identical to badminton-academy-be pattern

---

## 📊 PROJECT COMPARISON

### **Badminton BE Structure**
```
badminton-academy-be/
├── src/
│   ├── controllers/
│   │   ├── payment.controller.ts       ✅ Has
│   │   └── user.controller.ts          ✅ Has (with recharge)
│   ├── services/
│   │   ├── user.service.ts             ✅ Has (updateCredit, recharge)
│   │   └── booking.service.ts          ✅ Has (deduct credits)
│   ├── repositories/
│   │   └── transaction.repository.ts   ✅ Has
│   ├── entities/
│   │   └── transaction.ts              ✅ Has
│   ├── utils/
│   │   └── payment/
│   │       └── stripe.ts               ✅ Has
│   └── business_objects/
│       └── payment.ts                  ✅ Has
└── package.json                        ✅ Has stripe: ^18.2.1
```

### **AI-Physio BE Structure (Current)**
```
ai-physio-be/
├── src/
│   ├── controllers/
│   │   ├── payment.controller.ts       ❌ Missing
│   │   └── user.controller.ts          ✅ Has (no recharge)
│   ├── services/
│   │   └── user.service.ts             ✅ Has (no credit methods)
│   ├── repositories/
│   │   └── transaction.repository.ts   ❌ Missing
│   ├── entities/
│   │   └── transaction.ts              ❌ Missing
│   ├── utils/
│   │   └── payment/
│   │       └── stripe.ts               ❌ Missing
│   └── business_objects/
│       └── payment.ts                  ❌ Missing
└── package.json                        ❌ No stripe package
```

---

## 🎯 IMPLEMENTATION PHASES

### **PHASE 1: Database Schema** ⏱️ 30 minutes

#### 1.1 Update User Table
```prisma
model user {
  // ... existing fields
  credits Float? @default(5)  // Add this - default 5 free credits
  
  // Add relationship
  transactions Transaction[]
}
```

#### 1.2 Create Transaction Table
```prisma
model Transaction {
  id                Int      @id @default(autoincrement())
  transactionType   TransactionType  // "IN" or "OUT"
  transactionStatus Boolean  @default(true)
  creditAmount      Int      // Credits amount
  description       String?  // Optional description
  stripePaymentId   String?  @unique  // Stripe session ID
  userId            Int
  
  createBy          String?
  createAt          DateTime @default(now())
  updateBy          String?
  updateAt          DateTime @updatedAt
  delFlag           Boolean  @default(false)
  
  // Relationships
  user              user     @relation(fields: [userId], references: [id], onDelete: Cascade)
  
  @@index([userId])
  @@index([stripePaymentId])
  @@index([createAt])
}

enum TransactionType {
  IN
  OUT
}
```

#### 1.3 Create CreditPackage Table (Optional - for predefined packages)
```prisma
model CreditPackage {
  id              Int      @id @default(autoincrement())
  name            String   // "Starter", "Basic", "Popular", "Premium"
  credits         Int      // Base credits
  bonusCredits    Int      @default(0)  // Bonus credits
  priceUsd        Float    // Price in USD
  priceVnd        Float    // Price in VND
  stripePriceId   String?  // Stripe Price ID (optional)
  isActive        Boolean  @default(true)
  displayOrder    Int      @default(0)
  
  createAt        DateTime @default(now())
  updateAt        DateTime @updatedAt
  
  @@index([isActive, displayOrder])
}
```

#### 1.4 Migration Commands
```bash
# Step 1: Create migration
npx prisma migrate dev --name add_payment_tables

# Step 2: Generate Prisma client
npx prisma generate

# Step 3: Seed credit packages (optional)
npx ts-node prisma/seed-packages.ts
```

---

### **PHASE 2: Install Dependencies** ⏱️ 5 minutes

#### 2.1 Add Stripe Package
```bash
npm install stripe@^18.2.1
npm install --save-dev @types/stripe
```

#### 2.2 Update package.json
```json
{
  "dependencies": {
    "stripe": "^18.2.1",
    // ... existing dependencies
  }
}
```

---

### **PHASE 3: Environment Configuration** ⏱️ 10 minutes

#### 3.1 Update .env
```bash
# Add to .env file

# Stripe Configuration
STRIPE_PUBLISHABLE_KEY=pk_test_51RAX9V4EHf4ag09n...
STRIPE_SECRET_KEY=sk_test_51RAX9V4EHf4ag09n...
STRIPE_BASE_URL_LOCAL=http://localhost:3000
STRIPE_BASE_URL_PRODUCTION=https://api.yourdomain.com
```

#### 3.2 Update environment.ts
```typescript
// File: src/utils/environments/environment.ts

export interface StripeConfig {
  publishableKey: string;
  secretKey: string;
  baseUrl: string;
}

export interface Config {
  // ... existing config
  stripe: StripeConfig;
}

const config: Config = {
  // ... existing config
  
  stripe: {
    publishableKey: process.env.STRIPE_PUBLISHABLE_KEY || "",
    secretKey: process.env.STRIPE_SECRET_KEY || "",
    baseUrl: environment === 'development' 
      ? process.env.STRIPE_BASE_URL_LOCAL || ""
      : process.env.STRIPE_BASE_URL_PRODUCTION || "",
  },
};

// Add validation
function validateStripeConfig() {
  if (!config.stripe.publishableKey) {
    throw new Error("STRIPE_PUBLISHABLE_KEY is required");
  }
  if (!config.stripe.secretKey) {
    throw new Error("STRIPE_SECRET_KEY is required");
  }
  if (!config.stripe.baseUrl) {
    throw new Error("STRIPE_BASE_URL is required");
  }
}

validateStripeConfig();
```

---

### **PHASE 4: Create Business Objects** ⏱️ 15 minutes

#### 4.1 Create payment.ts
```typescript
// File: src/business_objects/payment.ts

import { IsEnum, IsObject, IsArray, IsNumber, IsString, IsNotEmpty, ValidateNested } from 'class-validator';
import { Type } from 'class-transformer';
import Stripe from 'stripe';

export class PaymentRequest {
    @IsNumber()
    amount!: number;
    
    @IsString()
    @IsNotEmpty()
    currency!: string;
    
    @IsString()
    @IsNotEmpty()
    paymentMethodType!: string;
}

export class PaymentRequestResponse {
    clientSecret!: string | null;
    nextAction!: Stripe.PaymentIntent.NextAction | null;
}

export class StripeProductData {
    @IsString()
    @IsNotEmpty()
    name!: string;
}

export class StripePriceData {
    @IsString()
    @IsNotEmpty()
    currency!: string;
    
    @ValidateNested()
    @Type(() => StripeProductData)
    @IsObject()
    product_data!: StripeProductData;
    
    @IsNumber()
    unit_amount!: number;
}

export class StripeLineItem {
    @ValidateNested()
    @Type(() => StripePriceData)
    @IsObject()
    price_data!: StripePriceData;
    
    @IsNumber()
    quantity!: number;
}

export class PaymentSessionRequest {
    @IsArray()
    @ValidateNested({ each: true })
    @Type(() => StripeLineItem)
    lineItems!: StripeLineItem[];
    
    @IsEnum(['payment', 'setup', 'subscription'])
    mode!: Stripe.Checkout.Session.Mode;
}
```

---

### **PHASE 5: Create Entities** ⏱️ 20 minutes

#### 5.1 Create transaction.ts
```typescript
// File: src/entities/transaction.ts

import { BaseEntity } from "./base/base.entity";
import { Expose } from "class-transformer";
import { IsEnum, IsNumber, IsBoolean, IsString, IsOptional, Min, IsNotEmpty } from "class-validator";

export enum TransactionType {
    IN = 'IN', 
    OUT = 'OUT'
}

export class Transaction extends BaseEntity {
    @Expose()
    @IsEnum(TransactionType)
    transactionType!: string;
    
    @Expose()
    @IsNumber()
    @Min(0)
    creditAmount!: number;
    
    @Expose()
    @IsBoolean()
    transactionStatus!: boolean;
    
    @Expose()
    @IsString()
    @IsOptional()
    description?: string;
    
    @Expose()
    @IsString()
    @IsOptional()
    stripePaymentId?: string;
    
    @IsNumber()
    @IsNotEmpty()
    userId!: number;
}

export class BaseTransaction {
    @Expose()
    id!: number;
    
    @Expose()
    @IsEnum(TransactionType)
    transactionType!: TransactionType;
    
    @Expose()
    @IsNumber()
    @Min(0)
    creditAmount!: number;
    
    @Expose()
    @IsBoolean()
    transactionStatus!: boolean;
    
    @Expose()
    @IsString()
    @IsOptional()
    description?: string;
    
    @Expose()
    @IsString()
    @IsOptional()
    stripePaymentId?: string;
    
    @Expose()
    createAt!: Date;
    
    @Expose()
    updateAt!: Date;
}

export class CreateTransactionDto {
    @IsEnum(TransactionType)
    transactionType!: string;
    
    @IsNumber()
    @Min(0)
    creditAmount!: number;
    
    @IsBoolean()
    transactionStatus!: boolean;
    
    @IsString()
    @IsOptional()
    description?: string;
    
    @IsString()
    @IsOptional()
    stripePaymentId?: string;
    
    @IsNumber()
    @IsNotEmpty()
    userId!: number;
}
```

#### 5.2 Update user.ts
```typescript
// File: src/entities/user.ts
// Add credits field

export class User extends BaseEntity {
  // ... existing fields
  
  @Expose()
  @IsNumber()
  @IsOptional()
  credits?: number;  // Add this
}

export class BaseUser {
  // ... existing fields
  
  @Expose()
  @IsNumber()
  @IsOptional()
  credits?: number;  // Add this
}
```

---

### **PHASE 6: Create Repositories** ⏱️ 30 minutes

#### 6.1 Create ITransaction.repository.ts
```typescript
// File: src/repositories/interfaces/itransaction.repository.ts

import { BaseTransaction, CreateTransactionDto } from "../../entities/transaction";
import { Pagination, PaginationParameter } from "../../business_objects/pagination";

export interface ITransactionRepository {
    create(data: CreateTransactionDto): Promise<BaseTransaction | null>;
    getById(id: number): Promise<BaseTransaction | null>;
    getByUserId(userId: number, para: PaginationParameter): Promise<Pagination<BaseTransaction>>;
    getByStripeId(stripePaymentId: string): Promise<BaseTransaction | null>;
    getAll(para: PaginationParameter): Promise<Pagination<BaseTransaction>>;
}
```

#### 6.2 Create transaction.repository.ts
```typescript
// File: src/repositories/transaction.repository.ts

import { injectable } from "inversify";
import { ITransactionRepository } from "./interfaces/itransaction.repository";
import { BaseTransaction, CreateTransactionDto } from "../entities/transaction";
import { Pagination, PaginationParameter } from "../business_objects/pagination";
import { plainToClass } from "class-transformer";
import prisma from "../utils/prisma";

@injectable()
export class TransactionRepository implements ITransactionRepository {
    
    public async create(data: CreateTransactionDto): Promise<BaseTransaction | null> {
        const transaction = await prisma.transaction.create({
            data: {
                transactionType: data.transactionType,
                creditAmount: data.creditAmount,
                transactionStatus: data.transactionStatus,
                description: data.description,
                stripePaymentId: data.stripePaymentId,
                userId: data.userId,
            }
        });
        
        return plainToClass(BaseTransaction, transaction, { 
            excludeExtraneousValues: true 
        });
    }
    
    public async getById(id: number): Promise<BaseTransaction | null> {
        const transaction = await prisma.transaction.findUnique({
            where: { id }
        });
        
        if (!transaction) return null;
        
        return plainToClass(BaseTransaction, transaction, { 
            excludeExtraneousValues: true 
        });
    }
    
    public async getByUserId(
        userId: number, 
        para: PaginationParameter
    ): Promise<Pagination<BaseTransaction>> {
        const skip = (para.pageIndex - 1) * para.pageSize;
        
        const [items, total] = await Promise.all([
            prisma.transaction.findMany({
                where: { 
                    userId,
                    delFlag: false 
                },
                skip,
                take: para.pageSize,
                orderBy: { createAt: 'desc' }
            }),
            prisma.transaction.count({
                where: { 
                    userId,
                    delFlag: false 
                }
            })
        ]);
        
        const transactions = items.map(item => 
            plainToClass(BaseTransaction, item, { 
                excludeExtraneousValues: true 
            })
        );
        
        return new Pagination<BaseTransaction>(
            transactions,
            total,
            para.pageIndex,
            para.pageSize
        );
    }
    
    public async getByStripeId(stripePaymentId: string): Promise<BaseTransaction | null> {
        const transaction = await prisma.transaction.findFirst({
            where: { 
                stripePaymentId,
                delFlag: false 
            }
        });
        
        if (!transaction) return null;
        
        return plainToClass(BaseTransaction, transaction, { 
            excludeExtraneousValues: true 
        });
    }
    
    public async getAll(para: PaginationParameter): Promise<Pagination<BaseTransaction>> {
        const skip = (para.pageIndex - 1) * para.pageSize;
        
        const [items, total] = await Promise.all([
            prisma.transaction.findMany({
                where: { delFlag: false },
                skip,
                take: para.pageSize,
                orderBy: { createAt: 'desc' }
            }),
            prisma.transaction.count({
                where: { delFlag: false }
            })
        ]);
        
        const transactions = items.map(item => 
            plainToClass(BaseTransaction, item, { 
                excludeExtraneousValues: true 
            })
        );
        
        return new Pagination<BaseTransaction>(
            transactions,
            total,
            para.pageIndex,
            para.pageSize
        );
    }
}
```

---

### **PHASE 7: Create Stripe Utility** ⏱️ 20 minutes

#### 7.1 Create stripe.ts
```typescript
// File: src/utils/payment/stripe.ts

import Stripe from "stripe";
import config, { StripeConfig } from "../environments/environment";
import { 
    PaymentRequest, 
    PaymentRequestResponse, 
    PaymentSessionRequest 
} from "../../business_objects/payment";

export class StripeUtil {
    private static readonly config: StripeConfig = config.stripe;

    private static readonly stripeInstance = new Stripe(this.config.secretKey, {
        appInfo: {
            name: "ai-physiognomy-payment",
            url: "https://github.com/ai-physiognomy",
            version: "1.0.0",
        },
        typescript: true,
    });

    /**
     * Create Stripe Checkout Session
     * @param data - Payment session request with line items
     * @param userId - User ID for success/cancel redirect
     * @returns Stripe Checkout Session object
     */
    public static async requestSessionPayment(
        data: PaymentSessionRequest, 
        userId: number
    ): Promise<Stripe.Checkout.Session> {
        return await this.stripeInstance.checkout.sessions.create({
            line_items: data.lineItems,
            mode: data.mode,
            success_url: `${this.config.baseUrl}/payment/success?session_id={CHECKOUT_SESSION_ID}&userId=${userId}`,
            cancel_url: `${this.config.baseUrl}/payment/cancel?userId=${userId}`
        });
    }

    /**
     * Retrieve Stripe Session by ID
     * @param sessionId - Stripe session ID
     * @returns Stripe Checkout Session details
     */
    public static async responseSessionPayment(
        sessionId: string
    ): Promise<Stripe.Response<Stripe.Checkout.Session>> {
        return await this.stripeInstance.checkout.sessions.retrieve(sessionId);
    }

    /**
     * NOT RECOMMENDED - Use Checkout Sessions instead
     * Create Payment Intent (no backend callback)
     */
    public static async requestPayment(
        data: PaymentRequest
    ): Promise<PaymentRequestResponse> {
        const paymentIntent = await this.stripeInstance.paymentIntents.create({
            amount: data.amount * 100, // Stripe works in cents
            currency: data.currency,
            payment_method_types: data.paymentMethodType === 'link' 
                ? ['link', 'card'] 
                : [data.paymentMethodType],
        });
        
        return {
            clientSecret: paymentIntent.client_secret,
            nextAction: paymentIntent.next_action,
        };
    }
}
```

---

### **PHASE 8: Update User Service** ⏱️ 30 minutes

#### 8.1 Update IUser.service.ts
```typescript
// File: src/services/interfaces/iuser.service.ts

import Stripe from "stripe";
import { PaymentSessionRequest } from "../../business_objects/payment";

export interface IUserService {
    // ... existing methods
    
    // Add these methods
    recharge(data: PaymentSessionRequest, email: string): Promise<Stripe.Checkout.Session>;
    updateCredit(sessionId: string, userId: number): Promise<BaseUser>;
}
```

#### 8.2 Update user.service.ts
```typescript
// File: src/services/user.service.ts

import Stripe from "stripe";
import { PaymentSessionRequest } from "../business_objects/payment";
import { StripeUtil } from "../utils/payment/stripe";
import { ITransactionRepository } from "../repositories/interfaces/itransaction.repository";
import { TransactionType } from "../entities/transaction";

@injectable()
export class UserService implements IUserService {
    constructor(
        @inject("IUserRepository") private userRepository: IUserRepository,
        @inject("IUserRoleRepository") private userRoleRepository: IUserRoleRepository,
        @inject("ITransactionRepository") private transactionRepository: ITransactionRepository  // Add this
    ) {}
    
    // ... existing methods
    
    /**
     * Create Stripe Checkout Session for user recharge
     * @param data - Payment session request
     * @param email - User email (from JWT)
     * @returns Stripe Checkout Session
     */
    public async recharge(
        data: PaymentSessionRequest, 
        email: string
    ): Promise<Stripe.Checkout.Session> {
        const user = await this.userRepository.getByEmail(email);
        if (!user || !user.id) {
            throw new ErrorResponseV2(ErrorCode.NOT_FOUND_USER);
        }
        
        return StripeUtil.requestSessionPayment(data, user.id);
    }
    
    /**
     * Update user credits after successful payment
     * @param sessionId - Stripe session ID
     * @param userId - User ID
     * @returns Updated user object
     */
    public async updateCredit(
        sessionId: string, 
        userId: number
    ): Promise<BaseUser> {
        // 1. Retrieve payment info from Stripe
        const paymentInfo = await StripeUtil.responseSessionPayment(sessionId);
        
        if (!paymentInfo || !paymentInfo.amount_total) {
            throw new ErrorResponseV2(ErrorCode.STRIPE_PAYMENT_INCOMPLETE);
        }

        // 2. Get user from database
        const user = await this.userRepository.getById(userId);
        if (!user || !user.id) {
            throw new ErrorResponseV2(ErrorCode.STRIPE_PAYMENT_INCOMPLETE);
        }

        // 3. Check if transaction already processed (idempotency)
        const existingTransaction = await this.transactionRepository.getByStripeId(
            paymentInfo.id
        );
        if (existingTransaction) {
            throw new ErrorResponseV2(ErrorCode.STRIPE_PAYMENT_COMPLETE);
        }

        // 4. Initialize credits if null
        if (!user.credits) {
            user.credits = 0;
        }

        // 5. Convert from cents to credits
        // Formula: $1 USD = 25 credits
        // Example: 500 cents = $5 = 125 credits
        const creditAmount = Math.floor((paymentInfo.amount_total / 100) * 25);
        user.credits += creditAmount;

        // 6. Create transaction record (IN type)
        await this.transactionRepository.create({
            transactionType: TransactionType.IN.toString(),
            transactionStatus: true,
            creditAmount: creditAmount,
            description: `Top-up via Stripe: $${paymentInfo.amount_total / 100}`,
            stripePaymentId: paymentInfo.id,
            userId: user.id
        });

        // 7. Update user credits in database
        return plainToClass(
            BaseUser, 
            await this.userRepository.update(user.id, { credits: user.credits }),
            { excludeExtraneousValues: true }
        );
    }
}
```

---

### **PHASE 9: Create Payment Controller** ⏱️ 25 minutes

#### 9.1 Create payment.controller.ts
```typescript
// File: src/controllers/payment.controller.ts

import { controller, httpGet, httpPost } from "inversify-express-utils";
import { 
    Controller, 
    Get, 
    Hidden, 
    Post, 
    Query, 
    Res, 
    Route, 
    Tags, 
    TsoaResponse 
} from "tsoa";
import { inject } from "inversify";
import { IUserService } from "../services/interfaces/iuser.service";
import { GeneralResponse } from "../business_objects/general.response";
import { SuccessCode } from "../utils/enums/enums";

@Route("payment")
@Tags("Payment")
@controller("payment")
export class PaymentController extends Controller {
    
    constructor(
        @inject("IUserService") private readonly userService: IUserService
    ) {
        super();
    }
    
    /**
     * Handle successful payment redirect from Stripe
     * @param session_id - Stripe session ID
     * @param userId - User ID
     * @returns Redirect to success page
     */
    @Hidden()
    @Get("/success")
    @httpGet("/success")
    public async responseSessionPaymentSuccess(
        @Query() session_id: string,
        @Query() userId: number,
        @Res() redirect: TsoaResponse<302, void>
    ): Promise<void> {
        try {
            const user = await this.userService.updateCredit(session_id, userId);
            
            // Redirect to success page with user credits
            const redirectUrl = user
                ? `http://localhost:3000/payment-success?credits=${user.credits}`
                : "http://localhost:3000/payment-failed";
                
            return redirect(302, undefined, { Location: redirectUrl });
        } catch (error) {
            console.error("Payment success handler error:", error);
            return redirect(302, undefined, { 
                Location: "http://localhost:3000/payment-failed" 
            });
        }
    }

    /**
     * Handle cancelled payment redirect from Stripe
     * @param userId - User ID
     * @returns Redirect to cancel page
     */
    @Get("/cancel")
    @httpGet("/cancel")
    @Hidden()
    public async responseSessionPaymentCancel(
        @Query() userId: number,
        @Res() redirect: TsoaResponse<302, void>
    ): Promise<void> {
        return redirect(302, undefined, { 
            Location: "http://localhost:3000/payment-cancel" 
        });
    }

    /**
     * Test endpoint to verify credit update logic
     * @param sessionId - Stripe session ID
     * @param userId - User ID
     * @returns Updated user with credits
     */
    @Post("/test-update-credit")
    @httpPost("/test-update-credit")
    public async testUpdateCredit(
        @Query() sessionId: string,
        @Query() userId: number
    ): Promise<GeneralResponse> {
        const result = await this.userService.updateCredit(sessionId, userId);
        return new GeneralResponse(SuccessCode.OPERATION_SUCCESS, result);
    }
}
```

---

### **PHASE 10: Update User Controller** ⏱️ 15 minutes

#### 10.1 Add recharge endpoint to user.controller.ts
```typescript
// File: src/controllers/user.controller.ts

import { PaymentSessionRequest } from "../business_objects/payment";
import { UserEmail } from "../entities/user";

@Route("users")
@Tags("User Management")
@controller("users")
export class UserController extends Controller {
    // ... existing methods
    
    /**
     * Recharge credits for current user
     * @param data - Payment session request
     * @param req - Request containing user email
     * @returns Stripe Checkout Session
     */
    @Post("/me/recharge")
    @httpPost("/me/recharge")
    @Security("jwt")
    public async selfRecharge(
        @Body() data: PaymentSessionRequest,
        @Request() req: { user: UserEmail }
    ): Promise<GeneralResponse> {
        return new GeneralResponse(
            SuccessCode.OPERATION_SUCCESS,
            await this.userService.recharge(data, req.user.email)
        );
    }

    /**
     * Admin: Recharge credits for any user
     * @param data - Payment session request
     * @param email - User email
     * @returns Stripe Checkout Session
     */
    @Post("/recharge")
    @httpPost("/recharge")
    @Security("jwt", ["ADMIN"])
    public async recharge(
        @Body() data: PaymentSessionRequest,
        @Query() email: string
    ): Promise<GeneralResponse> {
        return new GeneralResponse(
            SuccessCode.OPERATION_SUCCESS,
            await this.userService.recharge(data, email)
        );
    }
}
```

---

### **PHASE 11: Update Dependency Injection** ⏱️ 10 minutes

#### 11.1 Update dependency.injection.ts
```typescript
// File: src/dependency.injection.ts

import { TransactionRepository } from "./repositories/transaction.repository";
import { ITransactionRepository } from "./repositories/interfaces/itransaction.repository";

// Add this binding
container.bind<ITransactionRepository>("ITransactionRepository")
    .to(TransactionRepository)
    .inSingletonScope();
```

---

### **PHASE 12: Update Error Codes** ⏱️ 5 minutes

#### 12.1 Update enums.ts
```typescript
// File: src/utils/enums/enums.ts

export enum ErrorCode {
    // ... existing codes
    
    // Payment error codes
    STRIPE_PAYMENT_INCOMPLETE = "STRIPE_PAYMENT_INCOMPLETE",
    STRIPE_PAYMENT_COMPLETE = "STRIPE_PAYMENT_COMPLETE",
    INSUFFICIENT_CREDIT = "INSUFFICIENT_CREDIT",
    NOT_FOUND_TRANSACTION = "NOT_FOUND_TRANSACTION",
}
```

#### 12.2 Update error messages (EN)
```typescript
// File: src/utils/language/en/errors.ts

export const errors: Record<ErrorCode, string> = {
    // ... existing errors
    
    [ErrorCode.STRIPE_PAYMENT_INCOMPLETE]: "Payment is incomplete or failed",
    [ErrorCode.STRIPE_PAYMENT_COMPLETE]: "Payment has already been processed",
    [ErrorCode.INSUFFICIENT_CREDIT]: "Insufficient credits",
    [ErrorCode.NOT_FOUND_TRANSACTION]: "Transaction not found",
};
```

---

### **PHASE 13: Create Seed Data** ⏱️ 10 minutes

#### 13.1 Create seed-packages.ts
```typescript
// File: prisma/seed-packages.ts

import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

async function main() {
    console.log('Seeding credit packages...');
    
    const packages = [
        {
            name: 'Starter',
            credits: 50,
            bonusCredits: 0,
            priceUsd: 2,
            priceVnd: 50000,
            displayOrder: 1,
        },
        {
            name: 'Basic',
            credits: 125,
            bonusCredits: 25,
            priceUsd: 5,
            priceVnd: 125000,
            displayOrder: 2,
        },
        {
            name: 'Popular',
            credits: 275,
            bonusCredits: 75,
            priceUsd: 10,
            priceVnd: 250000,
            displayOrder: 3,
        },
        {
            name: 'Premium',
            credits: 625,
            bonusCredits: 125,
            priceUsd: 20,
            priceVnd: 500000,
            displayOrder: 4,
        },
    ];
    
    for (const pkg of packages) {
        await prisma.creditPackage.upsert({
            where: { name: pkg.name },
            update: pkg,
            create: pkg,
        });
        console.log(`✅ Created/Updated package: ${pkg.name}`);
    }
    
    console.log('✅ Seed completed!');
}

main()
    .catch((e) => {
        console.error('❌ Seed failed:', e);
        process.exit(1);
    })
    .finally(async () => {
        await prisma.$disconnect();
    });
```

---

## 📋 IMPLEMENTATION CHECKLIST

### **Pre-Implementation** ✅
- [x] Analyze badminton-academy-be structure
- [x] Compare with ai-physio-be structure
- [x] Create detailed implementation plan

### **Phase 1: Database** (30 min)
- [ ] Update `schema.prisma` - add credits to user
- [ ] Create Transaction model in schema
- [ ] Create CreditPackage model in schema (optional)
- [ ] Run migration: `npx prisma migrate dev`
- [ ] Generate Prisma client: `npx prisma generate`

### **Phase 2: Dependencies** (5 min)
- [ ] Install Stripe: `npm install stripe@^18.2.1`
- [ ] Verify installation in package.json

### **Phase 3: Environment** (10 min)
- [ ] Add Stripe keys to `.env`
- [ ] Update `environment.ts` with StripeConfig
- [ ] Add validation for Stripe config

### **Phase 4: Business Objects** (15 min)
- [ ] Create `src/business_objects/payment.ts`
- [ ] Define PaymentSessionRequest DTO
- [ ] Define StripeLineItem DTO

### **Phase 5: Entities** (20 min)
- [ ] Create `src/entities/transaction.ts`
- [ ] Update `src/entities/user.ts` - add credits field
- [ ] Export TransactionType enum

### **Phase 6: Repositories** (30 min)
- [ ] Create `src/repositories/interfaces/itransaction.repository.ts`
- [ ] Create `src/repositories/transaction.repository.ts`
- [ ] Implement CRUD methods

### **Phase 7: Stripe Utility** (20 min)
- [ ] Create `src/utils/payment/` directory
- [ ] Create `src/utils/payment/stripe.ts`
- [ ] Implement requestSessionPayment()
- [ ] Implement responseSessionPayment()

### **Phase 8: User Service** (30 min)
- [ ] Update `src/services/interfaces/iuser.service.ts`
- [ ] Update `src/services/user.service.ts`
- [ ] Implement recharge() method
- [ ] Implement updateCredit() method

### **Phase 9: Payment Controller** (25 min)
- [ ] Create `src/controllers/payment.controller.ts`
- [ ] Implement success handler
- [ ] Implement cancel handler
- [ ] Add test endpoint

### **Phase 10: User Controller** (15 min)
- [ ] Update `src/controllers/user.controller.ts`
- [ ] Add /me/recharge endpoint
- [ ] Add /recharge endpoint (admin)

### **Phase 11: Dependency Injection** (10 min)
- [ ] Update `src/dependency.injection.ts`
- [ ] Bind ITransactionRepository

### **Phase 12: Error Codes** (5 min)
- [ ] Update `src/utils/enums/enums.ts`
- [ ] Update `src/utils/language/en/errors.ts`
- [ ] Update `src/utils/language/vn/errors.ts` (if exists)

### **Phase 13: Seed Data** (10 min)
- [ ] Create `prisma/seed-packages.ts`
- [ ] Run seed: `npx ts-node prisma/seed-packages.ts`

### **Testing** (30 min)
- [ ] Test database migration
- [ ] Test API: POST /users/me/recharge
- [ ] Test Stripe Checkout flow
- [ ] Test success redirect
- [ ] Test cancel redirect
- [ ] Test duplicate payment prevention

---

## 🧪 TESTING GUIDE

### **1. Test Database Migration**
```bash
# Check database schema
npx prisma studio

# Verify tables exist:
# - user (with credits column)
# - Transaction
# - CreditPackage
```

### **2. Test Recharge API**

#### Request:
```bash
POST http://localhost:3000/users/me/recharge
Authorization: Bearer <JWT_TOKEN>
Content-Type: application/json

{
  "lineItems": [
    {
      "price_data": {
        "currency": "usd",
        "product_data": {
          "name": "150 Credits"
        },
        "unit_amount": 500
      },
      "quantity": 1
    }
  ],
  "mode": "payment"
}
```

#### Response:
```json
{
  "code": "OPERATION_SUCCESS",
  "message": "Success",
  "data": {
    "id": "cs_test_a1...",
    "url": "https://checkout.stripe.com/c/pay/cs_test_...",
    "amount_total": 500,
    "currency": "usd"
  }
}
```

### **3. Test Payment Flow**

1. **Get checkout URL** from API response
2. **Open URL** in browser
3. **Use Stripe test card**: `4242 4242 4242 4242`
4. **Complete payment**
5. **Verify redirect** to success URL
6. **Check database**:
   ```sql
   SELECT * FROM "user" WHERE id = 1;
   SELECT * FROM "Transaction" WHERE "userId" = 1 ORDER BY "createAt" DESC;
   ```

### **4. Test Duplicate Prevention**

```bash
# Try to process same session_id twice
POST http://localhost:3000/payment/test-update-credit?sessionId=cs_test_xxx&userId=1

# First call: Success
# Second call: Error "STRIPE_PAYMENT_COMPLETE"
```

---

## 📊 ESTIMATED TIMELINE

| Phase | Task | Time | Status |
|-------|------|------|--------|
| 1 | Database Schema | 30 min | ⏳ Pending |
| 2 | Install Dependencies | 5 min | ⏳ Pending |
| 3 | Environment Config | 10 min | ⏳ Pending |
| 4 | Business Objects | 15 min | ⏳ Pending |
| 5 | Entities | 20 min | ⏳ Pending |
| 6 | Repositories | 30 min | ⏳ Pending |
| 7 | Stripe Utility | 20 min | ⏳ Pending |
| 8 | User Service | 30 min | ⏳ Pending |
| 9 | Payment Controller | 25 min | ⏳ Pending |
| 10 | User Controller | 15 min | ⏳ Pending |
| 11 | Dependency Injection | 10 min | ⏳ Pending |
| 12 | Error Codes | 5 min | ⏳ Pending |
| 13 | Seed Data | 10 min | ⏳ Pending |
| **Testing** | **API & Integration Tests** | **30 min** | **⏳ Pending** |
| **TOTAL** | | **4 hours 15 minutes** | |

---

## 🎯 SUCCESS CRITERIA

### ✅ **Implementation Complete When:**

1. **Database**
   - [x] User table has `credits` column
   - [x] Transaction table created
   - [x] Migration runs successfully

2. **API Endpoints**
   - [x] POST `/users/me/recharge` returns Stripe URL
   - [x] GET `/payment/success` updates credits
   - [x] GET `/payment/cancel` redirects properly

3. **Business Logic**
   - [x] Credits added after successful payment
   - [x] Transaction record created
   - [x] Duplicate payment prevented
   - [x] Idempotency check works

4. **Error Handling**
   - [x] Invalid session ID returns error
   - [x] User not found returns error
   - [x] Already processed returns error

5. **Testing**
   - [x] Can complete payment with test card
   - [x] Credits reflect in database
   - [x] Transaction logged correctly

---

## 🔄 COMPARISON: Badminton vs AI-Physio

### **Similarities (Good!)**
- ✅ Same architecture (Inversify + TSOA + Prisma)
- ✅ Same Stripe pattern (Checkout Sessions)
- ✅ Same folder structure
- ✅ Same error handling approach

### **Differences (Handled)**
| Feature | Badminton | AI-Physio | Solution |
|---------|-----------|-----------|----------|
| Package version | stripe@18.2.1 | None | Install same version |
| Transaction model | Has | Missing | Create identical model |
| Payment controller | Has | Missing | Create identical |
| Stripe utility | Has | Missing | Copy and adapt |
| User credits | Float | Missing | Add to schema |

---

## 📝 NEXT STEPS AFTER COMPLETION

1. **Update Mobile App**
   - Implement payment UI
   - Add WebView for Stripe Checkout
   - Handle success/cancel redirects

2. **Add Chat Credit Deduction**
   - Update chat service to check credits
   - Deduct 1 credit per message
   - Add refund on AI failure

3. **Add Transaction History API**
   - GET `/users/me/transactions`
   - Filter by date range
   - Pagination support

4. **Production Deployment**
   - Switch to live Stripe keys
   - Update redirect URLs
   - Add webhook handler (optional)

---

**Document Version:** 1.0  
**Created:** 2025-11-07  
**Status:** 📋 Ready for Implementation  
**Estimated Time:** 4 hours 15 minutes
