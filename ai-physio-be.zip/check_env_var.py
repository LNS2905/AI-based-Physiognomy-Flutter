import paramiko

hostname = "160.250.180.132"
username = "root"
password = "Do@nhkiet262205"

def execute_ssh_command(command):
    try:
        client = paramiko.SSHClient()
        client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        client.connect(hostname, username=username, password=password)
        
        print(f"--- Executing: {command} ---")
        stdin, stdout, stderr = client.exec_command(command)
        
        output = stdout.read().decode().strip()
        error = stderr.read().decode().strip()
        
        if output:
            print(output)
        if error:
            print(f"Error/Stderr: {error}")
            
        client.close()
    except Exception as e:
        print(f"Connection failed: {e}")

if __name__ == "__main__":
    print("Inspecting container env vars...")
    execute_ssh_command('docker inspect glowlab_backend --format "{{range .Config.Env}}{{println .}}{{end}}" | grep STRIPE_SECRET_KEY')
