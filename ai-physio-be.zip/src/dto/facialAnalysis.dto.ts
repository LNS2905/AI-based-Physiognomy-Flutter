import {
  IsString,
  IsNumber,
  IsObject,
  IsArray,
  IsUrl,
  IsISO8601,
} from "class-validator";

export class FacialAnalysisDto {
  @IsString()
  userId!: string;

  @IsString()
  resultText!: string;

  @IsString()
  faceShape!: string;

  @IsNumber()
  harmonyScore!: number;

  @IsObject()
  probabilities!: Record<string, number>;

  @IsObject()
  harmonyDetails!: Record<string, number>;

  @IsArray()
  metrics!: Array<{
    label: string;
    pixels: number;
    percentage: number;
    orientation: string;
  }>;

  @IsUrl()
  annotatedImage!: string;

  @IsISO8601()
  processedAt!: string;
}
