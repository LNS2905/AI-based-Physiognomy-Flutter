import {
  IsArray,
  IsEnum,
  IsNumber,
  IsOptional,
  IsString,
  ValidateNested,
} from "class-validator";
import { Type } from "class-transformer";
import { LifeAspectType, LineType } from "@prisma/client";

export class InterpretationDto {
  @IsEnum(LineType)
  lineType!: LineType;

  @IsString()
  pattern!: string;

  @IsString()
  meaning!: string;

  @IsNumber()
  lengthPx!: number;

  @IsNumber()
  confidence!: number;
}

export class LifeAspectDto {
  @IsEnum(LifeAspectType)
  aspect!: LifeAspectType;

  @IsString()
  content!: string;
}

export class PalmAnalysisDto {
  @IsNumber()
  userId!: number;

  @IsString()
  annotatedImage!: string;

  @IsOptional()
  @IsNumber()
  palmLinesDetected?: number;

  @IsOptional()
  @IsNumber()
  detectedHeartLine?: number;

  @IsOptional()
  @IsNumber()
  detectedHeadLine?: number;

  @IsOptional()
  @IsNumber()
  detectedLifeLine?: number;

  @IsOptional()
  @IsNumber()
  detectedFateLine?: number;

  @IsString()
  targetLines!: string;

  @IsNumber()
  imageHeight!: number;

  @IsNumber()
  imageWidth!: number;

  @IsNumber()
  imageChannels!: number;

  @IsString()
  summaryText!: string;

  @ValidateNested({ each: true })
  @Type(() => InterpretationDto)
  @IsArray()
  interpretations!: InterpretationDto[];

  @ValidateNested({ each: true })
  @Type(() => LifeAspectDto)
  @IsArray()
  lifeAspects!: LifeAspectDto[];
}
