import { SendMailOptions } from "nodemailer";
import config, { Config } from "../environments/environment";

export class MailUtil {
    private static readonly config: Config = config;

    public static async SendMail(options: SendMailOptions) {
        if (!options.from) {
            options.from = this.config.mailerFrom;
        }
        this.config.mailer.sendMail(options);
    }
}