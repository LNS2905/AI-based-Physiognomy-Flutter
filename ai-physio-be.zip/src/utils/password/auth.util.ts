import { AuthResponse, User, UserData } from "../../entities/user";
import jwt from "jsonwebtoken";
import config, { AuthConfig } from "../environments/environment";
import * as crypto from "crypto";
import {
  ErrorResponse,
  ErrorResponseV2,
} from "../../business_objects/error.response";
import { ErrorCode } from "../enums/enums";

export class AuthUtil {
  private static readonly config: AuthConfig = config.auth;

  public static generateAuthToken(userData: UserData): AuthResponse {
    if (!userData.email || !userData.roles) {
      throw new ErrorResponseV2(ErrorCode.NOT_FOUND_USER);
    }
    return {
      accessToken: this.generateToken(
        userData,
        "access",
        this.config.accessTokenExpires
      ),
      refreshToken: this.generateToken(
        userData,
        "refresh",
        this.config.refreshTokenExpires
      ),
    };
  }

  public static generateResetPwdToken(userData: UserData): string {
    if (!userData.email || !userData.roles) {
      throw new ErrorResponse("User data is corrupted!");
    }
    return this.generateToken(
      userData,
      "pwdReset",
      this.config.pwdResetTokenExpires
    );
  }

  private static generateToken(
    userData: UserData,
    type: string,
    expiresIn: any
  ): string {
    const claims = {
      email: userData.email,
      role: userData.roles.map((role) => role.role.roleName.toUpperCase()),
      jti: crypto.randomUUID(),
      type: type,
    };

    const signOptions: jwt.SignOptions = {
      expiresIn,
    };
    return jwt.sign(claims, String(this.config.jwtSecret), signOptions);
  }
}
