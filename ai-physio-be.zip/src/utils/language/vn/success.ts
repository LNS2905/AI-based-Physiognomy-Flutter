﻿import { SuccessCode } from "../../enums/enums";

export const success = {
    [SuccessCode.OPERATION_SUCCESS]: "Tác vụ hoàn tất"
};