import dotenv from "dotenv";
import nodemailer, { Transporter } from "nodemailer";
import path from "path";

const environment = process.env.NODE_ENV || "development";

if (environment !== "production") {
  const envPath = path.resolve(process.cwd(), `.env`);
  const result = dotenv.config({ path: envPath });

  if (result.error && environment === "development") {
    console.warn("Warning: .env file not found, using environment variables from system");
  }
}

export interface DatabaseConfig {
  connectionString?: string;
  ssl: boolean;
}

export interface AuthConfig {
  saltRounds: number;
  accessTokenExpires: string;
  refreshTokenExpires: string;
  jwtSecret: string;
  pwdResetTokenExpires: string;
  googleWebClientId: string;
  googleWebClientSecret: string;
  googleAndroidClientId: string;
  googleRedirectUrl: string;
}

export interface StripeConfig {
  publishableKey: string;
  secretKey: string;
  baseUrl: string;
}

function createMailTransport(): Transporter {
  return nodemailer.createTransport({
    host: process.env.MAIL_HOST || "smtp.gmail.com",
    port: parseInt(process.env.MAIL_PORT || "587", 10),
    secure: process.env.MAIL_SECURE === "true",
    auth: {
      user: process.env.MAIL_USER || "",
      pass: process.env.MAIL_PASSWORD || "",
    },
  });
}

export interface Config {
  env: string;
  port: number;
  database: DatabaseConfig;
  auth: AuthConfig;
  mailerFrom: string;
  mailer: Transporter;
  language: string;
  stripe: StripeConfig;
}

function getDatabaseConfig(): DatabaseConfig {
  return {
    connectionString: process.env.DATABASE_URL,
    ssl: true,
  };
}

const config: Config = {
  env: process.env.NODE_ENV || "development",
  port: parseInt(process.env.PORT || "3000", 10),
  database: getDatabaseConfig(),
  auth: {
    jwtSecret: process.env.JWT_SECRET || "default_secret",
    saltRounds: parseInt(process.env.AUTH_SALT_ROUNDS || "10", 10),
    accessTokenExpires: process.env.AUTH_ACCESS_TOKEN_EXPIRES || "15m",
    refreshTokenExpires: process.env.AUTH_REFRESH_TOKEN_EXPIRES || "7d",
    pwdResetTokenExpires: process.env.AUTH_PWD_RESET_TOKEN_EXPIRES || "15m",
    googleWebClientId: process.env.GOOGLE_WEB_CLIENT_ID!,
    googleWebClientSecret: process.env.GOOGLE_WEB_CLIENT_SECRET!,
    googleAndroidClientId: process.env.GOOGLE_ANDROID_CLIENT_ID!,
    googleRedirectUrl: process.env.GOOGLE_REDIRECT_URL || "postmessage",
  },
  mailer: createMailTransport(),
  mailerFrom: process.env.MAIL_USER || "",
  language: process.env.LANG || "",
  stripe: {
    publishableKey: process.env.STRIPE_PUBLISHABLE_KEY || "",
    secretKey: process.env.STRIPE_SECRET_KEY || "",
    baseUrl: environment === 'development' 
      ? process.env.STRIPE_BASE_URL_LOCAL || ""
      : process.env.STRIPE_BASE_URL_PRODUCTION || "",
  },
};

function validateAuthConfig(auth: AuthConfig) {
  if (!auth.jwtSecret || auth.jwtSecret === "default_secret") {
    console.warn(
      "Warning: Using default JWT secret. This is not secure for production."
    );
  }
  if (auth.saltRounds < 10) {
    throw new Error("AUTH_SALT_ROUNDS must be at least 10");
  }
  const timeRegex = /^(\d+)(m|h|d)$/;
  if (!timeRegex.test(auth.accessTokenExpires)) {
    throw new Error(
      "Invalid AUTH_ACCESS_TOKEN_EXPIRES format. Use format: 15m, 1h, 7d"
    );
  }
  if (!timeRegex.test(auth.refreshTokenExpires)) {
    throw new Error(
      "Invalid AUTH_REFRESH_TOKEN_EXPIRES format. Use format: 15m, 1h, 7d"
    );
  }
  
  // Google OAuth is optional for local development
  if (
    !auth.googleWebClientId ||
    !auth.googleWebClientSecret ||
    !auth.googleAndroidClientId
  ) {
    if (environment === "production") {
      throw new Error(
        "GOOGLE_WEB_CLIENT_ID/SECRET and GOOGLE_ANDROID_CLIENT_ID are required in production"
      );
    } else {
      console.warn(
        "Warning: Google OAuth credentials not configured. Google login will not work."
      );
    }
  }
}

function validateConfig() {
  const { database } = config;
  if (!database.connectionString) {
    throw new Error("DATABASE_URL are required for local database");
  }
}

function validateStripeConfig() {
  if (!config.stripe.publishableKey) {
    console.warn("Warning: STRIPE_PUBLISHABLE_KEY not configured");
  }
  if (!config.stripe.secretKey) {
    console.warn("Warning: STRIPE_SECRET_KEY not configured");
  }
  if (!config.stripe.baseUrl) {
    console.warn("Warning: STRIPE_BASE_URL not configured");
  }
}

validateAuthConfig(config.auth);
validateConfig();
validateStripeConfig();

export default config;
