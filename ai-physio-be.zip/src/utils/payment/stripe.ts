import Stripe from "stripe";
import config, { StripeConfig } from "../environments/environment";
import {
    PaymentRequest,
    PaymentRequestResponse,
    PaymentSessionRequest
} from "../../business_objects/payment";

export class StripeUtil {
    private static readonly config: StripeConfig = config.stripe;

    private static readonly stripeInstance = new Stripe(this.config.secretKey, {
        appInfo: {
            name: "ai-physiognomy-payment",
            url: "https://github.com/ai-physiognomy",
            version: "1.0.0",
        },
        typescript: true,
    });

    /**
     * Create Stripe Checkout Session
     * @param data - Payment session request with line items
     * @param userId - User ID for success/cancel redirect
     * @returns Stripe Checkout Session object
     */
    public static async requestSessionPayment(
        data: PaymentSessionRequest,
        userId: number
    ): Promise<Stripe.Checkout.Session> {
        // Transform camelCase PaymentSessionRequest to snake_case for Stripe API
        const lineItems = data.lineItems.map(item => ({
            price_data: {
                currency: item.price_data.currency,
                product_data: {
                    name: item.price_data.product_data.name
                },
                unit_amount: item.price_data.unit_amount
            },
            quantity: item.quantity
        }));

        return await this.stripeInstance.checkout.sessions.create({
            line_items: lineItems,
            mode: data.mode,
            success_url: `${this.config.baseUrl}/payment/success?session_id={CHECKOUT_SESSION_ID}&userId=${userId}`,
            cancel_url: `${this.config.baseUrl}/payment/cancel?userId=${userId}`
        });
    }

    /**
     * Retrieve Stripe Session by ID
     * @param sessionId - Stripe session ID
     * @returns Stripe Checkout Session details
     */
    public static async responseSessionPayment(
        sessionId: string
    ): Promise<Stripe.Response<Stripe.Checkout.Session>> {
        return await this.stripeInstance.checkout.sessions.retrieve(sessionId);
    }

    /**
     * NOT RECOMMENDED - Use Checkout Sessions instead
     * Create Payment Intent (no backend callback)
     */
    public static async requestPayment(
        data: PaymentRequest
    ): Promise<PaymentRequestResponse> {
        const paymentIntent = await this.stripeInstance.paymentIntents.create({
            amount: data.amount * 100, // Stripe works in cents
            currency: data.currency,
            payment_method_types: data.paymentMethodType === 'link'
                ? ['link', 'card']
                : [data.paymentMethodType],
        });

        return {
            clientSecret: paymentIntent.client_secret,
            nextAction: paymentIntent.next_action,
        };
    }
    /**
     * Create Payment Sheet Parameters
     * @param amount - Amount in USD
     * @param currency - Currency code (e.g., 'usd')
     * @param email - User email (for creating new customer)
     * @param userId - User ID for metadata
     * @param customerId - Stripe Customer ID (optional)
     */
    public static async createPaymentSheetParams(
        amount: number,
        currency: string,
        email: string,
        userId: number,
        customerId?: string
    ): Promise<{ paymentIntent: string; ephemeralKey: string; customer: string; paymentIntentId: string }> {
        // 1. Get or Create Customer
        let customer = customerId;
        if (!customer) {
            const customers = await this.stripeInstance.customers.list({ email: email, limit: 1 });
            if (customers.data.length > 0) {
                customer = customers.data[0].id;
            } else {
                const newCustomer = await this.stripeInstance.customers.create({ email: email });
                customer = newCustomer.id;
            }
        }

        // 2. Create Ephemeral Key (required for Payment Sheet)
        const ephemeralKey = await this.stripeInstance.ephemeralKeys.create(
            { customer: customer },
            { apiVersion: '2024-06-20' }
        );

        // 3. Create Payment Intent
        const paymentIntent = await this.stripeInstance.paymentIntents.create({
            amount: Math.round(amount * 100), // Convert to cents
            currency: currency,
            customer: customer,
            automatic_payment_methods: {
                enabled: true,
            },
            metadata: {
                userId: userId.toString()
            }
        });

        if (!paymentIntent.client_secret) {
            throw new Error("Failed to create PaymentIntent");
        }

        if (!ephemeralKey.secret) {
            throw new Error("Failed to create Ephemeral Key");
        }

        return {
            paymentIntent: paymentIntent.client_secret,
            ephemeralKey: ephemeralKey.secret,
            customer: customer,
            paymentIntentId: paymentIntent.id
        };
    }

    /**
     * Retrieve Payment Intent by ID
     * @param paymentIntentId - Stripe Payment Intent ID
     */
    public static async retrievePaymentIntent(
        paymentIntentId: string
    ): Promise<Stripe.PaymentIntent> {
        return await this.stripeInstance.paymentIntents.retrieve(paymentIntentId);
    }
}
