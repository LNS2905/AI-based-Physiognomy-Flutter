import { BaseEntity } from "./base/base.entity";
import { Expose } from "class-transformer";
import { IsEnum, IsNumber, IsBoolean, IsString, IsOptional, Min, IsNotEmpty } from "class-validator";

export enum TransactionType {
    IN = 'IN', 
    OUT = 'OUT'
}

export class Transaction extends BaseEntity {
    @Expose()
    @IsEnum(TransactionType)
    transactionType!: string;
    
    @Expose()
    @IsNumber()
    @Min(0)
    creditAmount!: number;
    
    @Expose()
    @IsBoolean()
    transactionStatus!: boolean;
    
    @Expose()
    @IsString()
    @IsOptional()
    description?: string;
    
    @Expose()
    @IsString()
    @IsOptional()
    stripePaymentId?: string;
    
    @IsNumber()
    @IsNotEmpty()
    userId!: number;
}

export class BaseTransaction {
    @Expose()
    id!: number;
    
    @Expose()
    @IsEnum(TransactionType)
    transactionType!: TransactionType;
    
    @Expose()
    @IsNumber()
    @Min(0)
    creditAmount!: number;
    
    @Expose()
    @IsBoolean()
    transactionStatus!: boolean;
    
    @Expose()
    @IsString()
    @IsOptional()
    description?: string;
    
    @Expose()
    @IsString()
    @IsOptional()
    stripePaymentId?: string;
    
    @Expose()
    createAt!: Date;
    
    @Expose()
    updateAt!: Date;
}

export class CreateTransactionDto {
    @IsEnum(TransactionType)
    transactionType!: string;
    
    @IsNumber()
    @Min(0)
    creditAmount!: number;
    
    @IsBoolean()
    transactionStatus!: boolean;
    
    @IsString()
    @IsOptional()
    description?: string;
    
    @IsString()
    @IsOptional()
    stripePaymentId?: string;
    
    @IsNumber()
    @IsNotEmpty()
    userId!: number;
}
