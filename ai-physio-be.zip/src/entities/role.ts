import { Expose } from "class-transformer";
import { BaseEntity } from "./base/base.entity";
import { IsEnum } from "class-validator";

export class Role extends BaseEntity {
    @Expose()
    roleName!: string;
}

export class BaseRole {
    @Expose()
    roleName!: string;
}