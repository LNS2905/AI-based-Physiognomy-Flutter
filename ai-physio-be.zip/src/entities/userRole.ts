import { Expose, Type } from "class-transformer";
import { BaseEntity } from "./base/base.entity";
import { IsNumber, Min } from "class-validator";
import { BaseUser, User } from "./user";
import { BaseRole, Role } from "./role";

export class UserRole extends BaseEntity {
    @Expose()
    @IsNumber()
    @Min(1)
    userId!: number;

    @Expose()
    @IsNumber()
    @Min(1)
    roleId!: number;

    @Expose()
    user!: User;
    @Expose()
    role!: Role;
}

export class BaseUserRole {
    @Expose()
    @IsNumber()
    @Min(1)
    userId!: number;

    @Expose()
    @IsNumber()
    @Min(1)
    roleId!: number;

    @Expose()
    @Type(() => BaseUser)
    user!: BaseUser;
    @Expose()
    @Type(() => BaseRole)
    role!: BaseRole;
}