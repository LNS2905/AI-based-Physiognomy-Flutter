import { BaseEntity } from "./base/base.entity";
import {
  IsString,
  MinLength,
  IsNumber,
  IsEmail,
  IsPhoneNumber,
  IsEnum,
  IsOptional,
} from "class-validator";
import { IsPhoneOrEmail, Match } from "../utils/password/validate";
import { Gender } from "@prisma/client";
import { Exclude, Expose } from "class-transformer";
import { UserRole } from "./userRole";

export class User extends BaseEntity {
  @Expose()
  firstName!: string;
  @Expose()
  lastName!: string;
  @Expose()
  email!: string;
  @Expose()
  phone!: string | null;
  //phoneVerified: string; //Does not know how to do this
  @Expose()
  age!: number | null;
  @Expose()
  gender!: Gender | null;
  @Expose()
  avatar?: string | null; //Contain link to the image (Firebase, ...)
  @Expose()
  password!: string;
  @Exclude()
  resetPwdToken?: string | null;
  @Expose()
  @IsOptional()
  credits?: number | null;
}

//DAO
export class BaseUser {
  @Expose()
  id?: number;
  @IsString()
  @Expose()
  firstName!: string;
  @IsString()
  @Expose()
  lastName!: string;
  @Expose()
  @IsEmail()
  email!: string;
  @Expose()
  @IsPhoneNumber()
  phone!: string;
  @Expose()
  @IsNumber()
  age!: number;
  @Expose()
  @IsEnum(Gender)
  gender!: Gender;
  @Expose()
  @IsString()
  avatar?: string; //Contain link to the image (Firebase, ...)
  @Expose()
  @IsNumber()
  @IsOptional()
  credits?: number;
}

//Business Object
export interface UserEmail {
  email: string;
}

export class CreateUserDTO {
  @IsOptional()
  @IsPhoneOrEmail()
  username?: string | null;
  @IsString()
  @MinLength(7, { message: "Password must be at least 7 characters long" })
  password!: string;
  @IsOptional()
  @IsString()
  @MinLength(7, { message: "Password must be at least 7 characters long" })
  @Match("password")
  confirmPassword?: string;
  firstName!: string;
  lastName!: string;
  email!: string;
  phone!: string;
  age!: number;
  gender!: Gender;
  avatar?: string | null;
}

export class CreateGoogleUserDTO {
  email!: string;
  firstName!: string;
  lastName!: string;
  phone!: string | null;
  age!: number | null;
  gender?: Gender | null;
  avatar?: string | null;
  password?: string; // used for Google login
  googleId?: string;
}
export class AuthRequest {
  @IsPhoneOrEmail()
  username!: string;
  @IsString()
  @MinLength(7, { message: "Password must be at least 7 characters long" })
  password!: string;
}

export class RefreshTokenRequest {
  refreshToken!: string;
}

export class AuthResponse {
  accessToken!: string;
  refreshToken!: string;
}

export class UpdateUserDTO {
  @Expose()
  firstName!: string;
  @Expose()
  lastName!: string;
  @Expose()
  @IsEmail()
  email!: string;
  @Expose()
  @IsPhoneNumber()
  phone!: string;
  @Expose()
  @IsNumber()
  age!: number;
  @Expose()
  gender!: Gender;
  @Expose()
  avatar?: string; //Contain link to the image (Firebase, ...)
}

export class ChangePasswordDTO {
  @IsString()
  @MinLength(7, { message: "Password must be at least 7 characters long" })
  oldPassword!: string;
  @IsString()
  @MinLength(7, { message: "Password must be at least 7 characters long" })
  password!: string;
}
export class UserData {
  email!: string;
  roles!: UserRole[];
}

export class RequestResetPassword {
  @IsEmail()
  email!: string;
}

export class ResetPassword {
  @IsString()
  @MinLength(7, { message: "Password must be at least 7 characters long" })
  password!: string;
}
