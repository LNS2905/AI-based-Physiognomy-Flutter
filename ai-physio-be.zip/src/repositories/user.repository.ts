import { injectable } from "inversify";
import { CreateGoogleUserDTO, User } from "../entities/user";
import { GenericRepository } from "./generic.repository";
import { IUserRepository } from "./interfaces/iuser.repository";
import { PrismaClient } from "@prisma/client";
import { prismaManager } from "../utils/prisma";

@injectable()
export class UserRepository
  extends GenericRepository<User, "user">
  implements IUserRepository
{
  constructor() {
    super("user"); // Prisma table name
  }

  public async getByEmail(email: string): Promise<User | null> {
    return prismaManager.withConnection(async (client: PrismaClient) => {
      const user = await client.user.findUnique({
        where: { email, delFlag: false },
      });
      if (!user) return null;
      return {
        ...user,
        phone: user.phone || null,
        age: user.age || null,
      } as User;
    });
  }

  public async getByPhone(phone: string): Promise<User | null> {
    return prismaManager.withConnection(async (client: PrismaClient) => {
      return client.user.findUnique({
        where: { phone: phone, delFlag: false },
      });
    });
  }

  public async getByPhoneOrEmail(input: string): Promise<User | null> {
    return prismaManager.withConnection(async (client: PrismaClient) => {
      return client.user.findFirst({
        where: {
          delFlag: false,
          OR: [{ phone: input }, { email: input }],
        },
      });
    });
  }
  public async getByGoogleId(googleId: string): Promise<User | null> {
    return prismaManager.withConnection(async (client: PrismaClient) => {
      return client.user.findFirst({
        where: {
          googleId,
          delFlag: false,
        },
      });
    });
  }

  public async createGoogleUser(data: CreateGoogleUserDTO): Promise<User> {
    return prismaManager.withConnection(async (client: PrismaClient) => {
      const user: Omit<User, "id"> = {
        ...data,
        phone: data.phone || null,
        firstName: data.firstName || "null",
        lastName: data.lastName || "null",
        gender: data.gender !== undefined ? data.gender : null,
        password: data.password !== undefined ? data.password : "null",
      };
      return client.user.create({ data: user as any });
    });
  }
}
