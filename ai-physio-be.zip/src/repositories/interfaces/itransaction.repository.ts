import { BaseTransaction, CreateTransactionDto } from "../../entities/transaction";
import { Pagination, PaginationParameter } from "../../business_objects/pagination";

export interface ITransactionRepository {
    create(data: CreateTransactionDto): Promise<BaseTransaction | null>;
    getById(id: number): Promise<BaseTransaction | null>;
    getByUserId(userId: number, para: PaginationParameter): Promise<Pagination<BaseTransaction>>;
    getByStripeId(stripePaymentId: string): Promise<BaseTransaction | null>;
    getAll(para: PaginationParameter): Promise<Pagination<BaseTransaction>>;
}
