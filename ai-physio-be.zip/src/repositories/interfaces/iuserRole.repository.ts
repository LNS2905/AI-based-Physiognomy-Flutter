import { Pagination, PaginationParameter } from "../../business_objects/pagination";
import { UserRole } from "../../entities/userRole";
import { RoleName } from "../../utils/enums/enums";
import { IGenericRepository } from "./igeneric.repository";

export interface IUserRoleRepository extends IGenericRepository<UserRole> {
    createUserRole(userId: number, roleName: RoleName[]): Promise<UserRole>;
    updateUserRole(userId: number, roles: RoleName[]): Promise<UserRole[]>;
    getByRole(roleName: RoleName[], para: PaginationParameter): Promise<Pagination<UserRole>>;
    getByUser(userId: number, para: PaginationParameter): Promise<Pagination<UserRole>>;
    getAllByUser(userId: number): Promise<UserRole[]>;
    getAllByRole(roleName: RoleName[]): Promise<UserRole[]>;
}