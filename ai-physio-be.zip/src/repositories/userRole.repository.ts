import { PrismaClient } from "@prisma/client";
import {
  PaginationParameter,
  Pagination,
} from "../business_objects/pagination";
import { UserRole } from "../entities/userRole";
import { prismaManager } from "../utils/prisma";
import { GenericRepository } from "./generic.repository";
import { IUserRoleRepository } from "./interfaces/iuserRole.repository";
import { injectable } from "inversify";
import { RoleName } from "../utils/enums/enums";

@injectable()
export class UserRoleRepository
  extends GenericRepository<UserRole, "userRole">
  implements IUserRoleRepository {
  constructor() {
    super("userRole");
  }

  public async getAllByUser(userId: number): Promise<UserRole[]> {
    return prismaManager.withConnection(async (client: PrismaClient) => {
      const userRoles = await client.userRole.findMany({
        where: { userId: userId, delFlag: false },
        include: {
          user: true,
          role: true,
        },
      });
      return userRoles as UserRole[];
    });
  }

  public async getAllByRole(roleName: RoleName[]): Promise<UserRole[]> {
    return prismaManager.withConnection(async (client: PrismaClient) => {
      const userRoles = await client.userRole.findMany({
        where: {
          role: {
            roleName: {
              in: roleName.map((role) => role.toString().toLowerCase()),
            },
          },
          delFlag: false,
        },
        include: {
          user: true,
          role: true,
        },
      });
      return userRoles as UserRole[];
    });
  }

  public async createUserRole(
    userId: number,
    roleName: RoleName[]
  ): Promise<UserRole> {
    console.log(
      "Creating UserRole with userId:",
      userId,
      "and roleName:",
      roleName
    );
    return prismaManager.withConnection(async (client: PrismaClient) => {
      const userRole = await client.userRole.create({
        data: {
          user: { connect: { id: userId } },
          role: { connect: { roleName: roleName[0].toString().toLowerCase() } },
        },
        include: {
          user: true,
          role: true,
        },
      });
      return userRole as UserRole;
    });
  }

  public async updateUserRole(
    userId: number,
    roles: RoleName[]
  ): Promise<UserRole[]> {
    return prismaManager.withConnection(async (client: PrismaClient) => {
      // Step 1: Remove all current roles for the user
      await client.userRole.deleteMany({
        where: { userId: userId },
      });

      // Step 2: Add new roles
      const createdRoles = await Promise.all(
        roles.map((roleName) =>
          client.userRole.create({
            data: {
              user: { connect: { id: userId } },
              role: {
                connect: { roleName: roleName.toString().toLowerCase() },
              },
            },
            include: {
              user: true,
              role: true,
            },
          })
        )
      );

      return createdRoles as UserRole[];
    });
  }

  public async getByRole(
    roleName: RoleName[],
    para: PaginationParameter
  ): Promise<Pagination<UserRole>> {
    return prismaManager.withConnection(async (client: PrismaClient) => {
      const totalCount = await client.userRole.count({
        where: {
          role: {
            roleName: {
              in: roleName.map((role) => role.toString().toLowerCase()),
            },
          },
          delFlag: false,
        },
      });
      const items = await client.userRole.findMany({
        skip: (para.pageIndex - 1) * para.pageSize,
        take: para.pageSize,
        where: {
          role: {
            roleName: {
              in: roleName.map((role) => role.toString().toLowerCase()),
            },
          },
          delFlag: false,
        },
        include: {
          user: true,
          role: true,
        },
      });
      return new Pagination(
        items,
        totalCount,
        para.pageIndex,
        para.pageSize
      ) as Pagination<UserRole>;
    });
  }

  public async getByUser(
    userId: number,
    para: PaginationParameter
  ): Promise<Pagination<UserRole>> {
    return prismaManager.withConnection(async (client: PrismaClient) => {
      const totalCount = await client.userRole.count({
        where: { userId: userId, delFlag: false },
      });
      const items = await client.userRole.findMany({
        skip: (para.pageIndex - 1) * para.pageSize,
        take: para.pageSize,
        where: { userId: userId, delFlag: false },
        include: {
          user: true,
          role: true,
        },
      });
      return new Pagination(
        items,
        totalCount,
        para.pageIndex,
        para.pageSize
      ) as Pagination<UserRole>;
    });
  }
}
