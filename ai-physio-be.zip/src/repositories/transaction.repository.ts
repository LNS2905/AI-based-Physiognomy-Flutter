import { injectable } from "inversify";
import { ITransactionRepository } from "./interfaces/itransaction.repository";
import { BaseTransaction, CreateTransactionDto } from "../entities/transaction";
import { Pagination, PaginationParameter } from "../business_objects/pagination";
import { plainToClass } from "class-transformer";
import { prisma } from "../utils/prisma";

@injectable()
export class TransactionRepository implements ITransactionRepository {
    
    public async create(data: CreateTransactionDto): Promise<BaseTransaction | null> {
        const transaction = await prisma.transaction.create({
            data: {
                transactionType: data.transactionType as any,
                creditAmount: data.creditAmount,
                transactionStatus: data.transactionStatus,
                description: data.description,
                stripePaymentId: data.stripePaymentId,
                userId: data.userId,
            }
        });
        
        return plainToClass(BaseTransaction, transaction, { 
            excludeExtraneousValues: true 
        });
    }
    
    public async getById(id: number): Promise<BaseTransaction | null> {
        const transaction = await prisma.transaction.findUnique({
            where: { id }
        });
        
        if (!transaction) return null;
        
        return plainToClass(BaseTransaction, transaction, { 
            excludeExtraneousValues: true 
        });
    }
    
    public async getByUserId(
        userId: number, 
        para: PaginationParameter
    ): Promise<Pagination<BaseTransaction>> {
        const skip = (para.pageIndex - 1) * para.pageSize;
        
        const [items, total] = await Promise.all([
            prisma.transaction.findMany({
                where: { 
                    userId,
                    delFlag: false 
                },
                skip,
                take: para.pageSize,
                orderBy: { createAt: 'desc' }
            }),
            prisma.transaction.count({
                where: { 
                    userId,
                    delFlag: false 
                }
            })
        ]);
        
        const transactions = items.map((item: any) => 
            plainToClass(BaseTransaction, item, { 
                excludeExtraneousValues: true 
            })
        );
        
        return new Pagination<BaseTransaction>(
            transactions,
            total,
            para.pageIndex,
            para.pageSize
        );
    }
    
    public async getByStripeId(stripePaymentId: string): Promise<BaseTransaction | null> {
        const transaction = await prisma.transaction.findFirst({
            where: { 
                stripePaymentId,
                delFlag: false 
            }
        });
        
        if (!transaction) return null;
        
        return plainToClass(BaseTransaction, transaction, { 
            excludeExtraneousValues: true 
        });
    }
    
    public async getAll(para: PaginationParameter): Promise<Pagination<BaseTransaction>> {
        const skip = (para.pageIndex - 1) * para.pageSize;
        
        const [items, total] = await Promise.all([
            prisma.transaction.findMany({
                where: { delFlag: false },
                skip,
                take: para.pageSize,
                orderBy: { createAt: 'desc' }
            }),
            prisma.transaction.count({
                where: { delFlag: false }
            })
        ]);
        
        const transactions = items.map((item: any) => 
            plainToClass(BaseTransaction, item, { 
                excludeExtraneousValues: true 
            })
        );
        
        return new Pagination<BaseTransaction>(
            transactions,
            total,
            para.pageIndex,
            para.pageSize
        );
    }
}
