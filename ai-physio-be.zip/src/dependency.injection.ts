import { Container, decorate, injectable } from "inversify";
import { PalmAnalysisController } from "./controllers/palmAnalysis.controller";
import { FacialAnalysisController } from "./controllers/facialAnalysis.controller";
import { UserRoleController } from "./controllers/userRole.controller";
import { FacialAnalysisService } from "./services/facialAnalysis.service";
import { Controller } from "tsoa";
import { buildProviderModule } from "inversify-binding-decorators";
import { IUserService } from "./services/interfaces/iuser.service";
import { UserService } from "./services/user.service";
import { IUserRepository } from "./repositories/interfaces/iuser.repository";
import { UserRepository } from "./repositories/user.repository";
import { IGenericRepository } from "./repositories/interfaces/igeneric.repository";
import { GenericRepository } from "./repositories/generic.repository";
import { UserController } from "./controllers/user.controller";
import { IAuthService } from "./services/interfaces/iauth.service";
import { AuthService } from "./services/auth.service";
import { AuthController } from "./controllers/auth.controller";
import { Validator } from "class-validator";
import { IUserRoleService } from "./services/interfaces/iuserRole.service";
import { UserRoleService } from "./services/userRole.service";
import { IUserRoleRepository } from "./repositories/interfaces/iuserRole.repository";
import { UserRoleRepository } from "./repositories/userRole.repository";
import { IFacialAnalysisService } from "./services/interfaces/ifacialAnalysis.service";
import { IPalmAnalysisService } from "./services/interfaces/ipalmAnalysis.service";
import { PalmAnalysisService } from "./services/palmAnalysis.service";
import { ITransactionRepository } from "./repositories/interfaces/itransaction.repository";
import { TransactionRepository } from "./repositories/transaction.repository";
import { PaymentController } from "./controllers/payment.controller";
import { IChatService } from "./services/interfaces/ichat.service";
import { ChatService } from "./services/chat.service";
import { ChatController } from "./controllers/chat.controller";
import { CreditPackageController } from "./controllers/creditPackage.controller";

const iocContainer = new Container();
decorate(injectable(), Controller);
iocContainer.load(buildProviderModule());

iocContainer.bind<UserController>(UserController).toSelf();
iocContainer.bind<AuthController>(AuthController).toSelf();
iocContainer.bind<PalmAnalysisController>(PalmAnalysisController).toSelf();
iocContainer.bind<FacialAnalysisController>(FacialAnalysisController).toSelf();
iocContainer.bind<UserRoleController>(UserRoleController).toSelf();
iocContainer.bind<PaymentController>(PaymentController).toSelf();
iocContainer.bind<ChatController>(ChatController).toSelf();
iocContainer.bind<CreditPackageController>(CreditPackageController).toSelf();

iocContainer
  .bind<IUserService>("IUserService")
  .to(UserService)
  .inSingletonScope();

iocContainer
  .bind<IChatService>("IChatService")
  .to(ChatService)
  .inSingletonScope();
iocContainer
  .bind<IAuthService>("IAuthService")
  .to(AuthService)
  .inSingletonScope();
iocContainer
  .bind<IUserRoleService>("IUserRoleService")
  .to(UserRoleService)
  .inSingletonScope();
iocContainer
  .bind<IFacialAnalysisService>("IFacialAnalysisService")
  .to(FacialAnalysisService)
  .inSingletonScope();
iocContainer
  .bind<IPalmAnalysisService>("IPalmAnalysisService")
  .to(PalmAnalysisService)
  .inSingletonScope();

iocContainer
  .bind<IGenericRepository<any>>("IGenericRepository")
  .to(GenericRepository);
iocContainer.bind<IUserRepository>("IUserRepository").to(UserRepository);
iocContainer
  .bind<IUserRoleRepository>("IUserRoleRepository")
  .to(UserRoleRepository)
  .inSingletonScope();

iocContainer
  .bind<ITransactionRepository>("ITransactionRepository")
  .to(TransactionRepository)
  .inSingletonScope();

iocContainer.bind<Validator>(Validator).toSelf();

export { iocContainer };
