﻿import {
  controller,
  httpDelete,
  httpGet,
  httpPost,
  httpPut,
} from "inversify-express-utils";
import { inject } from "inversify";
import { IUserService } from "../services/interfaces/iuser.service";
import {
  Route,
  Get,
  Post,
  Tags,
  Query,
  Body,
  Controller,
  Put,
  Delete,
  Path,
  Security,
  Request,
} from "tsoa";
import { CreateUserDTO, UpdateUserDTO, UserEmail } from "../entities/user";
import { PaginationParameter } from "../business_objects/pagination";
import { GeneralResponse } from "../business_objects/general.response";
import { RoleName, SuccessCode } from "../utils/enums/enums";
import { validate } from "../utils/password/validate";
import { PaymentSessionRequest } from "../business_objects/payment";

@Route("/users")
@Tags("User Management")
@controller("/users")
export class UserController extends Controller {
  constructor(
    @inject("IUserService") private readonly userService: IUserService
  ) {
    super();
  }

  /**
   * Lấy thông tin người dùng theo ID.
   * @param id ID của người dùng.
   * @returns Thông tin người dùng.
   */
  @Get("/")
  @httpGet("/")
  @Security("jwt", ["ADMIN"])
  public async getUsers(@Query() id: number): Promise<GeneralResponse> {
    return new GeneralResponse(
      SuccessCode.OPERATION_SUCCESS,
      await this.userService.getUser(id)
    );
  }

  /**
   * Lấy thông tin người dùng theo email.
   * @param email Email của người dùng.
   * @returns Thông tin người dùng.
   */
  @Get("/email/{email}")
  @httpGet("/email/{email}")
  @Security("jwt", ["ADMIN"])
  public async getUsersByEmail(
    @Path() email: string
  ): Promise<GeneralResponse> {
    return new GeneralResponse(
      SuccessCode.OPERATION_SUCCESS,
      await this.userService.getUserByEmail(email)
    );
  }

  /**
   * Lấy danh sách tất cả người dùng với phân trang.
   * @param pageIndex Chỉ số trang.
   * @param pageSize Kích thước trang.
   * @returns Danh sách người dùng với phân trang.
   */
  @Get("/all")
  @httpGet("/all")
  @Security("jwt", ["ADMIN"])
  public async getAllUsers(
    @Query() pageIndex?: number,
    @Query() pageSize?: number
  ): Promise<GeneralResponse> {
    return new GeneralResponse(
      SuccessCode.OPERATION_SUCCESS,
      await this.userService.getAllUser(
        new PaginationParameter(pageIndex, pageSize)
      )
    );
  }

  /**
   * Đăng ký tài khoản mới (chỉ admin)
   * @param userData Dữ liệu người dùng cần tạo.
   * @returns Thông tin người dùng vừa tạo.
   */
  @Post("/signUpInternal")
  @httpPost("/signUpInternal")
  @Security("jwt", ["ADMIN"])
  public async createUserInternal(
    @Body() userData: CreateUserDTO,
    @Query() roleName: RoleName[]
  ): Promise<GeneralResponse> {
    await validate(CreateUserDTO, userData);
    return new GeneralResponse(
      SuccessCode.OPERATION_SUCCESS,
      await this.userService.createSpecialUser(userData, roleName)
    );
  }

  /**
   * Đăng ký tài khoản mới (auto role: user)
   * @param userData Dữ liệu người dùng cần tạo.
   * @returns Thông tin người dùng vừa tạo.
   */
  @Post("/signUp")
  @httpPost("/signUp")
  public async createUser(
    @Body() userData: CreateUserDTO
  ): Promise<GeneralResponse> {
    if (!userData.username) {
      userData.username = userData.email || userData.phone;
    }

    await validate(CreateUserDTO, userData);

    const createdUser = await this.userService.createUser(userData);
    return new GeneralResponse(SuccessCode.OPERATION_SUCCESS, createdUser);
  }

  /**
   * Cập nhật thông tin người dùng (chỉ Admin).
   * @param id ID của người dùng.
   * @param newData Dữ liệu mới cần cập nhật.
   * @returns Thông tin người dùng sau khi cập nhật.
   */
  @Put("/")
  @httpPut("/")
  @Security("jwt", ["ADMIN"])
  public async updateUser(
    @Query() id: number,
    @Body() newData: UpdateUserDTO
  ): Promise<GeneralResponse> {
    await validate(UpdateUserDTO, newData);
    return new GeneralResponse(
      SuccessCode.OPERATION_SUCCESS,
      await this.userService.updateUsers(id, newData)
    );
  }

  /**
   * Cập nhật thông tin của bản thân.
   * @param req Request chứa thông tin người dùng.
   * @param newData Dữ liệu mới cần cập nhật.
   * @returns Thông tin người dùng sau khi cập nhật.
   */
  @Put("/me")
  @httpPut("/me")
  @Security("jwt")
  public async updateCurrentUser(
    @Request() req: { user: UserEmail },
    @Body() newData: UpdateUserDTO
  ): Promise<GeneralResponse> {
    await validate(UpdateUserDTO, newData);
    return new GeneralResponse(
      SuccessCode.OPERATION_SUCCESS,
      await this.userService.updateCurrentUsers(req.user.email, newData)
    );
  }

  /**
   * Xóa người dùng theo ID (chỉ Admin).
   * @param id ID của người dùng cần xóa.
   * @returns Kết quả xóa người dùng.
   */
  @Delete("/")
  @httpDelete("/")
  @Security("jwt", ["ADMIN"])
  public async deleteUser(@Query() id: number): Promise<GeneralResponse> {
    return new GeneralResponse(
      SuccessCode.OPERATION_SUCCESS,
      await this.userService.deleteUsers(id)
    );
  }

  /**
   * Recharge credits for current user
   * @param data - Payment session request
   * @param req - Request containing user email
   * @returns Stripe Checkout Session
   */
  @Post("/me/recharge")
  @httpPost("/me/recharge")
  @Security("jwt")
  public async selfRecharge(
    @Body() data: PaymentSessionRequest,
    @Request() req: { user: UserEmail }
  ): Promise<GeneralResponse> {
    return new GeneralResponse(
      SuccessCode.OPERATION_SUCCESS,
      await this.userService.recharge(data, req.user.email)
    );
  }

  /**
   * Admin: Recharge credits for any user
   * @param data - Payment session request
   * @param email - User email
   * @returns Stripe Checkout Session
   */
  @Post("/recharge")
  @httpPost("/recharge")
  @Security("jwt", ["ADMIN"])
  public async recharge(
    @Body() data: PaymentSessionRequest,
    @Query() email: string
  ): Promise<GeneralResponse> {
    return new GeneralResponse(
      SuccessCode.OPERATION_SUCCESS,
      await this.userService.recharge(data, email)
    );
  }
}
