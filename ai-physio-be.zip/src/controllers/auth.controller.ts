﻿import { controller, httpGet, httpPost } from "inversify-express-utils";
import { inject } from "inversify";
import { IUserService } from "../services/interfaces/iuser.service";
import {
  Route,
  Get,
  Post,
  Tags,
  Body,
  Controller,
  Security,
  Request,
  Query,
} from "tsoa";
import {
  AuthRequest,
  ChangePasswordDTO,
  RefreshTokenRequest,
  RequestResetPassword,
  ResetPassword,
  UserEmail,
} from "../entities/user";
import { IAuthService } from "../services/interfaces/iauth.service";
import { GeneralResponse } from "../business_objects/general.response";
import { SuccessCode } from "../utils/enums/enums";
import { validate } from "../utils/password/validate";

@Route("/auth")
@Tags("Authentication")
@controller("/auth")
export class AuthController extends Controller {
  constructor(
    @inject("IAuthService") private readonly authService: IAuthService,
    @inject("IUserService") private readonly userService: IUserService
  ) {
    super();
  }

  @Post("/user")
  @httpPost("/user")
  public async login(@Body() loginData: AuthRequest): Promise<GeneralResponse> {
    await validate(AuthRequest, loginData);
    return new GeneralResponse(
      SuccessCode.OPERATION_SUCCESS,
      await this.authService.login(loginData)
    );
  }

  @Get("/me")
  @httpGet("/me")
  @Security("jwt")
  public async getCurrentLogin(
    @Request() req: { user: UserEmail }
  ): Promise<GeneralResponse> {
    return new GeneralResponse(
      SuccessCode.OPERATION_SUCCESS,
      await this.userService.getUserByEmail(req.user.email)
    );
  }

  @Post("/me/change-password")
  @httpPost("/me/change-password")
  @Security("jwt")
  public async changePassword(
    @Request() req: { user: UserEmail },
    @Body() data: ChangePasswordDTO
  ): Promise<GeneralResponse> {
    await validate(ChangePasswordDTO, data);
    return new GeneralResponse(
      SuccessCode.OPERATION_SUCCESS,
      await this.authService.changePassword(req.user.email, data)
    );
  }

  @Post("/request-forgot-pass")
  @httpPost("/request-forgot-pass")
  public async requestForgotPassword(
    @Body() data: RequestResetPassword
  ): Promise<GeneralResponse> {
    await validate(RequestResetPassword, data);
    await this.authService.requestResetPassword(data);
    return new GeneralResponse(SuccessCode.OPERATION_SUCCESS, true);
  }

  @Post("/reset-pass")
  @httpPost("/reset-pass")
  public async resetPassword(
    @Query() token: string,
    @Body() data: ResetPassword
  ): Promise<GeneralResponse> {
    await validate(ResetPassword, data);
    return new GeneralResponse(
      SuccessCode.OPERATION_SUCCESS,
      await this.authService.resetPassword(token, data)
    );
  }

  @Post("/refresh-token")
  @httpPost("/refresh-token")
  public async refreshToken(
    @Body() data: RefreshTokenRequest
  ): Promise<GeneralResponse> {
    return new GeneralResponse(
      SuccessCode.OPERATION_SUCCESS,
      await this.authService.refreshToken(data)
    );
  }

  @Post("/google/mobile")
  @httpPost("/google/mobile")
  public async loginWithGoogleMobile(
    @Body() body: { token: string }
  ): Promise<GeneralResponse> {
    return new GeneralResponse(
      SuccessCode.OPERATION_SUCCESS,
      await this.authService.loginWithGoogleIdToken(body.token)
    );
  }

  @Post("/google/web")
  @httpPost("/google/web")
  public async loginWithGoogleWeb(
    @Body() body: { code: string }
  ): Promise<GeneralResponse> {
    return new GeneralResponse(
      SuccessCode.OPERATION_SUCCESS,
      await this.authService.loginWithGoogleCode(body.code)
    );
  }
}
