import { controller, httpGet } from "inversify-express-utils";
import {
    Route,
    Get,
    Tags,
    Controller,
} from "tsoa";
import { GeneralResponse } from "../business_objects/general.response";
import { SuccessCode } from "../utils/enums/enums";
import { prismaManager } from "../utils/prisma";
import { PrismaClient } from "@prisma/client";

@Route("/credit-packages")
@Tags("Credit Packages")
@controller("/credit-packages")
export class CreditPackageController extends Controller {
    /**
     * Get all active credit packages
     * @returns List of active credit packages ordered by display order
     */
    @Get("/")
    @httpGet("/")
    public async getAllCreditPackages(): Promise<GeneralResponse> {
        const packages = await prismaManager.withConnection(
            async (client: PrismaClient) =>
                client.creditPackage.findMany({
                    where: { isActive: true },
                    orderBy: { displayOrder: "asc" },
                    select: {
                        id: true,
                        name: true,
                        credits: true,
                        bonusCredits: true,
                        priceUsd: true,
                        priceVnd: true,
                        stripePriceId: true,
                        isActive: true,
                        displayOrder: true,
                    },
                })
        );

        return new GeneralResponse(SuccessCode.OPERATION_SUCCESS, packages);
    }
}
