import { controller, httpGet, httpPost } from "inversify-express-utils";
import {
  Controller,
  Get,
  Hidden,
  Post,
  Query,
  Res,
  Route,
  Tags,
  TsoaResponse,
} from "tsoa";
import { inject } from "inversify";
import { IUserService } from "../services/interfaces/iuser.service";
import { GeneralResponse } from "../business_objects/general.response";
import { SuccessCode } from "../utils/enums/enums";

@Route("payment")
@Tags("Payment")
@controller("payment")
export class PaymentController extends Controller {
  constructor(
    @inject("IUserService") private readonly userService: IUserService
  ) {
    super();
  }

  /**
   * Handle successful payment redirect from Stripe
   * @param session_id - Stripe session ID
   * @param userId - User ID
   * @returns Redirect to success page
   */
  @Hidden()
  @Get("/success")
  @httpGet("/success")
  public async responseSessionPaymentSuccess(
    @Query() session_id: string,
    @Query() userId: number,
    @Res() redirect: TsoaResponse<302, void>
  ): Promise<void> {
    try {
      const user = await this.userService.updateCredit(session_id, userId);

      // Redirect to success page with user credits
      // Using Deep Link: physioapp://app/payment-success
      const redirectUrl = user
        ? `physioapp://app/payment-success?credits=${user.credits}`
        : "physioapp://app/payment-failed";

      return redirect(302, undefined, { Location: redirectUrl });
    } catch (error) {
      console.error("Payment success handler error:", error);
      return redirect(302, undefined, {
        Location: "physioapp://app/payment-failed",
      });
    }
  }

  /**
   * Handle cancelled payment redirect from Stripe
   * @param userId - User ID
   * @returns Redirect to cancel page
   */
  @Get("/cancel")
  @httpGet("/cancel")
  @Hidden()
  public async responseSessionPaymentCancel(
    @Query() userId: number,
    @Res() redirect: TsoaResponse<302, void>
  ): Promise<void> {
    return redirect(302, undefined, {
      Location: "physioapp://app/payment-cancel",
    });
  }

  /**
   * Test endpoint to verify credit update logic
   * @param sessionId - Stripe session ID
   * @param userId - User ID
   * @returns Updated user with credits
   */
  @Post("/test-update-credit")
  @httpPost("/test-update-credit")
  public async testUpdateCredit(
    @Query() sessionId: string,
    @Query() userId: number
  ): Promise<GeneralResponse> {
    const result = await this.userService.updateCredit(sessionId, userId);
    return new GeneralResponse(SuccessCode.OPERATION_SUCCESS, result);
  }
  /**
   * Create Payment Sheet for mobile app
   * @param amount - Amount in USD
   * @param email - User email (injected from token usually, but passed here for simplicity or extracted from request)
   */
  @Post("/payment-sheet")
  @httpPost("/payment-sheet")
  public async createPaymentSheet(
    @Query() amount: number,
    @Query() email: string
  ): Promise<GeneralResponse> {
    const result = await this.userService.createPaymentSheet(amount, email);
    return new GeneralResponse(SuccessCode.OPERATION_SUCCESS, result);
  }
  /**
   * Confirm Payment Sheet transaction
   * @param paymentIntentId - Stripe Payment Intent ID
   * @param userId - User ID (from auth token or query)
   */
  @Post("/confirm-payment-sheet")
  @httpPost("/confirm-payment-sheet")
  public async confirmPaymentSheet(
    @Query() paymentIntentId: string,
    @Query() userId: number
  ): Promise<GeneralResponse> {
    const result = await this.userService.confirmPaymentSheet(
      paymentIntentId,
      userId
    );
    return new GeneralResponse(SuccessCode.OPERATION_SUCCESS, result);
  }
}
