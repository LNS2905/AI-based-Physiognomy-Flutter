import {
  Body,
  Controller,
  Delete,
  Get,
  Path,
  Post,
  Put,
  Route,
  Security,
  Tags,
} from "tsoa";
import { plainToInstance } from "class-transformer";
import { PalmAnalysisDto } from "../dto/palmAnalysis.dto";
import { validate } from "class-validator";
import { PalmAnalysisService } from "../services/palmAnalysis.service";

@Route("palm-analysis")
@Tags("Palm Analysis")
export class PalmAnalysisController extends Controller {
  private palmAnalysisService: PalmAnalysisService;

  constructor() {
    super();
    this.palmAnalysisService = new PalmAnalysisService();
  }

  @Post("/")
  @Security("jwt")
  public async savePalmAnalysis(
    @Body() requestBody: PalmAnalysisDto
  ): Promise<any> {
    const dto = plainToInstance(PalmAnalysisDto, requestBody);
    const errors = await validate(dto);

    if (errors.length > 0) {
      return { success: false, errors };
    }

    return this.palmAnalysisService.savePalmAnalysis(requestBody);
  }

  @Get("/user/{userId}")
  @Security("jwt")
  public async getPalmAnalysisByUser(@Path() userId: number): Promise<any> {
    return this.palmAnalysisService.getPalmAnalysisByUser(userId);
  }
  @Get("/all")
  @Security("jwt", ["ADMIN"])
  public async getAllPalmAnalyses(): Promise<any> {
    return this.palmAnalysisService.getAllPalmAnalyses();
  }
  @Delete("/{id}")
  @Security("jwt")
  public async deletePalmAnalysis(@Path() id: number): Promise<any> {
    return this.palmAnalysisService.deletePalmAnalysis(id);
  }

  @Put("/{id}")
  @Security("jwt")
  public async updatePalmAnalysis(
    @Path() id: number,
    @Body() palmAnalysisDto: PalmAnalysisDto
  ): Promise<any> {
    return this.palmAnalysisService.updatePalmAnalysis(id, palmAnalysisDto);
  }
}
