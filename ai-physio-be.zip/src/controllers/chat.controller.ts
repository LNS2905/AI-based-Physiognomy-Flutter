import { Body, Controller, Post, Route, Tags, Security, Request } from "tsoa";
import { inject, injectable } from "inversify";
import { IChatService } from "../services/interfaces/ichat.service";
import { ChatRequest } from "../business_objects/chat";
import { GeneralResponse } from "../business_objects/general.response";
import { SuccessCode } from "../utils/enums/enums";

/**
 * Mock Chat Controller - Only for testing payment/credit system
 * Real AI chatbot will be in separate backend service
 */
@injectable()
@Route("/api/chat")
@Tags("Chat & AI Conversation (Mock)")
export class ChatController extends Controller {
  constructor(@inject("IChatService") private chatService: IChatService) {
    super();
  }

  /**
   * Send a message to AI chatbot (MOCK)
   * Deducts 1 credit and returns mock response
   */
  @Post("/send")
  @Security("jwt")
  public async sendMessage(
    @Body() body: ChatRequest,
    @Request() request: any
  ): Promise<GeneralResponse> {
    const userId = request.user?.userId;
    
    const response = await this.chatService.sendMessage(
      userId,
      body.message
    );

    return new GeneralResponse(SuccessCode.OPERATION_SUCCESS, response);
  }
}
