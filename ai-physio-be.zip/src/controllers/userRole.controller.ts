import { inject } from "inversify";
import { controller, httpGet, httpPut } from "inversify-express-utils";
import { Body, Controller, Get, Put, Query, Route, Security, Tags } from "tsoa";
import { IUserRoleService } from "../services/interfaces/iuserRole.service";
import { SuccessCode, RoleName } from "../utils/enums/enums";
import { BaseUserRole } from "../entities/userRole";
import { Pagination, PaginationParameter } from "../business_objects/pagination";
import { GeneralResponse } from "../business_objects/general.response";

@Route("/user-role")
@Tags("User Role Management")
@controller("/user-role")
export class UserRoleController extends Controller {
    constructor(@inject("IUserRoleService") private readonly userRoleService: IUserRoleService) {
        super();
    }

    /**
     * Lấy danh sách người dùng theo vai trò.
     * @param roleName Danh sách tên vai trò.
     * @param pageIndex Chỉ số trang.
     * @param pageSize Kích thước trang.
     * @returns Danh sách người dùng với phân trang.
     */
    @Get("/users")
    @httpGet("/users")
    @Security("jwt", ["ADMIN"])
    public async getUserByRole(@Query() roleName: RoleName[],
        @Query() pageIndex?: number, @Query() pageSize?: number): Promise<GeneralResponse> {
        return new GeneralResponse(SuccessCode.OPERATION_SUCCESS,
            await this.userRoleService.getUserByRole(roleName, new PaginationParameter(pageIndex, pageSize)));
    }

    /**
     * Lấy danh sách vai trò của một người dùng.
     * @param userId ID của người dùng.
     * @param pageIndex Chỉ số trang.
     * @param pageSize Kích thước trang.
     * @returns Danh sách vai trò với phân trang.
     */
    @Get("/roles")
    @httpGet("/roles")
    @Security("jwt", ["ADMIN"])
    public async getRoleByUser(@Query() userId: number,
        @Query() pageIndex?: number, @Query() pageSize?: number): Promise<GeneralResponse> {
        return new GeneralResponse(SuccessCode.OPERATION_SUCCESS,
            await this.userRoleService.getRoleByUser(userId, new PaginationParameter(pageIndex, pageSize)));
    }

    /**
     * Cập nhật vai trò của người dùng.
     * @param userId ID của người dùng.
     * @param roleName Danh sách tên vai trò mới.
     * @returns Kết quả cập nhật vai trò.
     */
    @Put("/")
    @httpPut("/")
    @Security("jwt", ["ADMIN"])
    public async updateUserRole(@Query() userId: number, @Body() roleName: RoleName[]): Promise<GeneralResponse> {
        return new GeneralResponse(SuccessCode.OPERATION_SUCCESS,
            await this.userRoleService.updateUserRole(userId, roleName));
    }
}