import { FacialAnalysisService } from "../services/facialAnalysis.service";
import { FacialAnalysisDto } from "../dto/facialAnalysis.dto";

import {
  Route,
  Post,
  Tags,
  Body,
  Controller,
  Security,
  Get,
  Path,
  Delete,
  Put,
} from "tsoa";
import { GeneralResponse } from "../business_objects/general.response";
import { SuccessCode } from "../utils/enums/enums";

@Route("/facial-analysis")
@Tags("Facial Analysis")
export class FacialAnalysisController extends Controller {
  private facialAnalysisService: FacialAnalysisService =
    new FacialAnalysisService();

  @Post("/")
  @Security("jwt")
  public async saveFacialAnalysis(
    @Body() facialAnalysisDto: FacialAnalysisDto
  ): Promise<GeneralResponse> {
    const data = await this.facialAnalysisService.saveFacialAnalysis(
      facialAnalysisDto
    );
    return new GeneralResponse(SuccessCode.OPERATION_SUCCESS, data);
  }
  @Get("/user/{userId}")
  @Security("jwt")
  public async getFacialAnalysesByUser(
    @Path() userId: number
  ): Promise<GeneralResponse> {
    const data = await this.facialAnalysisService.getFacialAnalysesByUser(
      userId
    );
    return new GeneralResponse(SuccessCode.OPERATION_SUCCESS, data);
  }
  @Get("/all")
  @Security("jwt", ["ADMIN"])
  public async getAllFacialAnalyses(): Promise<GeneralResponse> {
    const data = await this.facialAnalysisService.getAllFacialAnalyses();
    return new GeneralResponse(SuccessCode.OPERATION_SUCCESS, data);
  }

  @Delete("/{id}")
  @Security("jwt")
  public async deleteFacialAnalysis(
    @Path() id: number
  ): Promise<GeneralResponse> {
    const data = await this.facialAnalysisService.deleteFacialAnalysis(id);
    return new GeneralResponse(SuccessCode.OPERATION_SUCCESS, data);
  }

  @Put("/{id}")
  @Security("jwt")
  public async updateFacialAnalysis(
    @Path() id: number,
    @Body() facialAnalysisDto: FacialAnalysisDto
  ): Promise<GeneralResponse> {
    const data = await this.facialAnalysisService.updateFacialAnalysis(
      id,
      facialAnalysisDto
    );
    return new GeneralResponse(SuccessCode.OPERATION_SUCCESS, data);
  }
}
