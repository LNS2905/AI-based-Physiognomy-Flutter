import { Request, Response, NextFunction } from "express";
import * as crypto from "crypto";

const normalize = (v: unknown): string =>
  (Array.isArray(v) ? v[0] : v ?? "").toString().trim();

export function verifyPingKey(req: Request, res: Response, next: NextFunction) {
  // Ưu tiên header, fallback query
  const provided = normalize(req.headers["x-cron-key"] ?? req.query.key);
  const expected = normalize(process.env.PING_KEY);

  if (!expected) {
    return res.status(500).json({ error: "PING_KEY not set" });
  }

  const a = Buffer.from(provided);
  const b = Buffer.from(expected);

  if (a.length !== b.length) return res.sendStatus(403);
  if (!crypto.timingSafeEqual(a, b)) return res.sendStatus(403);

  return next();
}

export function healthHandler(_req: Request, res: Response) {
  res.status(200).json({ status: "ok", service: "backend", ts: Date.now() });
}
