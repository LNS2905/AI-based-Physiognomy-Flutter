export class ChatRequest {
  message!: string;
}

export class ChatResponse {
  id: string;
  message: string;
  creditsUsed: number;
  remainingCredits: number;

  constructor(id: string, message: string, creditsUsed: number, remainingCredits: number) {
    this.id = id;
    this.message = message;
    this.creditsUsed = creditsUsed;
    this.remainingCredits = remainingCredits;
  }
}
