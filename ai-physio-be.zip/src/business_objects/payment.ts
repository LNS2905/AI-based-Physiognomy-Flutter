import { IsEnum, IsObject, IsArray, IsNumber, IsString, IsNotEmpty, ValidateNested } from 'class-validator';
import { Type } from 'class-transformer';
import Stripe from 'stripe';

export class PaymentRequest {
    @IsNumber()
    amount!: number;
    
    @IsString()
    @IsNotEmpty()
    currency!: string;
    
    @IsString()
    @IsNotEmpty()
    paymentMethodType!: string;
}

export class PaymentRequestResponse {
    clientSecret!: string | null;
    nextAction!: Stripe.PaymentIntent.NextAction | null;
}

export class StripeProductData {
    @IsString()
    @IsNotEmpty()
    name!: string;
}

export class StripePriceData {
    @IsString()
    @IsNotEmpty()
    currency!: string;
    
    @ValidateNested()
    @Type(() => StripeProductData)
    @IsObject()
    product_data!: StripeProductData;
    
    @IsNumber()
    unit_amount!: number;
}

export class StripeLineItem {
    @ValidateNested()
    @Type(() => StripePriceData)
    @IsObject()
    price_data!: StripePriceData;
    
    @IsNumber()
    quantity!: number;
}

export class PaymentSessionRequest {
    @IsArray()
    @ValidateNested({ each: true })
    @Type(() => StripeLineItem)
    lineItems!: StripeLineItem[];
    
    @IsEnum(['payment', 'setup', 'subscription'])
    mode!: Stripe.Checkout.Session.Mode;
}
