import { inject, injectable } from "inversify";
import { IUserService } from "./interfaces/iuser.service";
import { IUserRepository } from "../repositories/interfaces/iuser.repository";
import { CreateUserDTO, BaseUser, User, UpdateUserDTO } from "../entities/user";
import { PasswordUtil } from "../utils/password/password.util";
import { plainToClass, plainToInstance } from "class-transformer";
import { ErrorResponseV2 } from "../business_objects/error.response";
import {
  Pagination,
  PaginationParameter,
} from "../business_objects/pagination";
import { ErrorCode, RoleName } from "../utils/enums/enums";
import { isEmail, isPhoneNumber } from "class-validator";
import { IUserRoleRepository } from "../repositories/interfaces/iuserRole.repository";
import Stripe from "stripe";
import { PaymentSessionRequest } from "../business_objects/payment";
import { StripeUtil } from "../utils/payment/stripe";
import { ITransactionRepository } from "../repositories/interfaces/itransaction.repository";
import { TransactionType } from "../entities/transaction";

@injectable()
export class UserService implements IUserService {
  constructor(
    @inject("IUserRepository") private userRepository: IUserRepository,
    @inject("IUserRoleRepository")
    private userRoleRepository: IUserRoleRepository,
    @inject("ITransactionRepository")
    private transactionRepository: ITransactionRepository
  ) { }

  public async createUser(userData: CreateUserDTO): Promise<BaseUser> {
    delete userData.confirmPassword;

    const user = plainToClass(User, userData, {
      excludeExtraneousValues: true,
    });

    const username = userData.username ?? "";

    if (isEmail(username)) {
      user.email = username;
    } else if (isPhoneNumber(username)) {
      user.phone = username;
    } else {
      throw new ErrorResponseV2(ErrorCode.INVALID_USERNAME);
    }

    user.password = await PasswordUtil.hashPassword(user.password);

    try {
      const created = await this.userRepository.create(user);

      if (!created || !created.id) {
        throw new ErrorResponseV2(ErrorCode.NOT_FOUND_USER);
      }

      await this.userRoleRepository.createUserRole(created.id, [RoleName.USER]);
      return plainToClass(BaseUser, created, { excludeExtraneousValues: true });
    } catch (error: any) {
      if (error.code === 'P2002') {
        throw new ErrorResponseV2(ErrorCode.DUPLICATE_USER);
      }
      throw error;
    }
  }

  public async createSpecialUser(
    userData: CreateUserDTO,
    roleName: RoleName[]
  ): Promise<BaseUser> {
    delete userData.confirmPassword;

    const user = plainToClass(User, userData, {
      excludeExtraneousValues: true,
    });

    const username = userData.username ?? "";

    if (isEmail(username)) {
      user.email = username;
    } else if (isPhoneNumber(username)) {
      user.phone = username;
    } else {
      throw new ErrorResponseV2(ErrorCode.INVALID_USERNAME);
    }

    user.password = await PasswordUtil.hashPassword(user.password);

    const created = await this.userRepository.create(user);

    if (!created || !created.id) {
      throw new ErrorResponseV2(ErrorCode.NOT_FOUND_USER);
    }

    await this.userRoleRepository.createUserRole(created.id, roleName);
    return plainToClass(BaseUser, created, { excludeExtraneousValues: true });
  }

  public async getUser(id: number): Promise<BaseUser | null> {
    return plainToClass(BaseUser, await this.userRepository.getById(id), {
      excludeExtraneousValues: true,
    });
  }

  public async getUserByEmail(email: string): Promise<BaseUser | null> {
    return plainToClass(BaseUser, await this.userRepository.getByEmail(email), {
      excludeExtraneousValues: true,
    });
  }

  public async getAllUser(
    para: PaginationParameter
  ): Promise<Pagination<BaseUser>> {
    const source = await this.userRepository.getAll(para);
    const items = plainToInstance(BaseUser, source.items, {
      excludeExtraneousValues: true,
    });
    return new Pagination<BaseUser>(
      items,
      source.totalCount,
      source.currentPage,
      source.pageSize
    );
  }

  public async updateUsers(
    id: number,
    newData: UpdateUserDTO
  ): Promise<BaseUser> {
    var user = await this.userRepository.getById(id);
    if (!user) {
      throw new ErrorResponseV2(ErrorCode.NOT_FOUND_USER);
    }
    return plainToClass(
      BaseUser,
      await this.userRepository.update(id, newData),
      { excludeExtraneousValues: true }
    );
  }

  public async updateCurrentUsers(
    email: string,
    newData: UpdateUserDTO
  ): Promise<BaseUser> {
    var user = await this.userRepository.getByEmail(email);
    if (!user || !user.id) {
      throw new ErrorResponseV2(ErrorCode.NOT_FOUND_USER);
    }
    return plainToClass(
      BaseUser,
      await this.userRepository.update(user.id, newData),
      { excludeExtraneousValues: true }
    );
  }

  public async deleteUsers(id: number): Promise<BaseUser> {
    return plainToClass(BaseUser, await this.userRepository.delete(id), {
      excludeExtraneousValues: true,
    });
  }

  /**
   * Create Stripe Checkout Session for user recharge
   * @param data - Payment session request
   * @param email - User email (from JWT)
   * @returns Stripe Checkout Session
   */
  public async recharge(
    data: PaymentSessionRequest,
    email: string
  ): Promise<Stripe.Checkout.Session> {
    const user = await this.userRepository.getByEmail(email);
    if (!user || !user.id) {
      throw new ErrorResponseV2(ErrorCode.NOT_FOUND_USER);
    }

    return StripeUtil.requestSessionPayment(data, user.id);
  }

  /**
   * Update user credits after successful payment
   * @param sessionId - Stripe session ID
   * @param userId - User ID
   * @returns Updated user object
   */
  public async updateCredit(
    sessionId: string,
    userId: number
  ): Promise<BaseUser> {
    // 1. Retrieve payment info from Stripe
    const paymentInfo = await StripeUtil.responseSessionPayment(sessionId);

    if (!paymentInfo || !paymentInfo.amount_total) {
      throw new ErrorResponseV2(ErrorCode.STRIPE_PAYMENT_INCOMPLETE);
    }

    // 2. Get user from database
    const user = await this.userRepository.getById(userId);
    if (!user || !user.id) {
      throw new ErrorResponseV2(ErrorCode.STRIPE_PAYMENT_INCOMPLETE);
    }

    // 3. Check if transaction already processed (idempotency)
    const existingTransaction = await this.transactionRepository.getByStripeId(
      paymentInfo.id
    );
    if (existingTransaction) {
      throw new ErrorResponseV2(ErrorCode.STRIPE_PAYMENT_COMPLETE);
    }

    // 4. Initialize credits if null
    if (!user.credits) {
      user.credits = 0;
    }

    // 5. Convert from cents to credits
    // Formula: $1 USD = 10 credits
    // Example: 500 cents = $5 = 50 credits
    const creditAmount = Math.floor((paymentInfo.amount_total / 100) * 10);
    user.credits += creditAmount;

    // 6. Create transaction record (IN type)
    await this.transactionRepository.create({
      transactionType: TransactionType.IN.toString(),
      transactionStatus: true,
      creditAmount: creditAmount,
      description: `Top-up via Stripe: $${paymentInfo.amount_total / 100}`,
      stripePaymentId: paymentInfo.id,
      userId: user.id,
    });

    // 7. Update user credits in database
    return plainToClass(
      BaseUser,
      await this.userRepository.update(user.id, { credits: user.credits }),
      { excludeExtraneousValues: true }
    );
  }
  /**
   * Create Payment Sheet for mobile app
   * @param amount - Amount in USD
   * @param email - User email
   * @returns Payment Sheet parameters
   */
  public async createPaymentSheet(
    amount: number,
    email: string
  ): Promise<{ paymentIntent: string; ephemeralKey: string; customer: string; paymentIntentId: string }> {
    const user = await this.userRepository.getByEmail(email);
    if (!user || !user.id) {
      throw new ErrorResponseV2(ErrorCode.NOT_FOUND_USER);
    }

    // Note: We should ideally store the Stripe Customer ID in the user table
    // For now, we'll let StripeUtil find/create it based on email
    return StripeUtil.createPaymentSheetParams(amount, 'usd', email, user.id);
  }

  /**
   * Confirm Payment Sheet transaction and update credits
   * @param paymentIntentId - Stripe Payment Intent ID
   * @param userId - User ID
   */
  public async confirmPaymentSheet(
    paymentIntentId: string,
    userId: number
  ): Promise<BaseUser> {
    // 1. Retrieve Payment Intent from Stripe
    const paymentIntent = await StripeUtil.retrievePaymentIntent(paymentIntentId);

    if (!paymentIntent) {
      throw new ErrorResponseV2(ErrorCode.STRIPE_PAYMENT_INCOMPLETE);
    }

    // 2. Verify Status
    if (paymentIntent.status !== 'succeeded') {
      throw new ErrorResponseV2(ErrorCode.STRIPE_PAYMENT_INCOMPLETE);
    }

    // 3. Verify Ownership (Metadata check)
    if (paymentIntent.metadata.userId !== userId.toString()) {
      throw new ErrorResponseV2(ErrorCode.PERMISSION_DENIED);
    }

    // 4. Check Idempotency
    const existingTransaction = await this.transactionRepository.getByStripeId(
      paymentIntent.id
    );
    if (existingTransaction) {
      throw new ErrorResponseV2(ErrorCode.STRIPE_PAYMENT_COMPLETE);
    }

    // 5. Get User
    const user = await this.userRepository.getById(userId);
    if (!user || !user.id) {
      throw new ErrorResponseV2(ErrorCode.NOT_FOUND_USER);
    }

    // 6. Calculate Credits
    if (!user.credits) {
      user.credits = 0;
    }
    const creditAmount = Math.floor((paymentIntent.amount / 100) * 10);
    user.credits += creditAmount;

    // 7. Record Transaction
    await this.transactionRepository.create({
      transactionType: TransactionType.IN.toString(),
      transactionStatus: true,
      creditAmount: creditAmount,
      description: `Payment Sheet Top-up: $${paymentIntent.amount / 100}`,
      stripePaymentId: paymentIntent.id,
      userId: user.id,
    });

    // 8. Update User
    return plainToClass(
      BaseUser,
      await this.userRepository.update(user.id, { credits: user.credits }),
      { excludeExtraneousValues: true }
    );
  }
}
