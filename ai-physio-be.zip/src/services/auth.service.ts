import { inject, injectable } from "inversify";
import {
  AuthRequest,
  AuthResponse,
  BaseUser,
  ChangePasswordDTO,
  RefreshTokenRequest,
  RequestResetPassword,
  ResetPassword,
  UserData,
  User,
} from "../entities/user";
import { IUserRepository } from "../repositories/interfaces/iuser.repository";
import { IAuthService } from "./interfaces/iauth.service";
import { PasswordUtil } from "../utils/password/password.util";
import { ErrorResponseV2 } from "../business_objects/error.response";
import { AuthUtil } from "../utils/password/auth.util";
import { ErrorCode } from "../utils/enums/enums";
import config from "../utils/environments/environment";
import * as jwt from "jsonwebtoken";
import { IUserRoleRepository } from "../repositories/interfaces/iuserRole.repository";
import { OAuth2Client } from "google-auth-library";
import { prismaManager } from "../utils/prisma";
import { PrismaClient } from "@prisma/client";
import { MailUtil } from "../utils/mail/mail.util";
import { plainToClass } from "class-transformer";

const androidClient = new OAuth2Client(config.auth.googleAndroidClientId);
const webClient = new OAuth2Client(config.auth.googleWebClientId);

@injectable()
export class AuthService implements IAuthService {
  constructor(
    @inject("IUserRepository") private userRepository: IUserRepository,
    @inject("IUserRoleRepository")
    private userRoleRepository: IUserRoleRepository
  ) { }

  public async login(loginData: AuthRequest): Promise<AuthResponse> {
    const user = await this.userRepository.getByPhoneOrEmail(
      loginData.username
    );
    if (!user || !user.id)
      throw new ErrorResponseV2(ErrorCode.INVALID_CREDENTIALS);
    if (user.delFlag) throw new ErrorResponseV2(ErrorCode.DELETED_USER);
    const isValidPassword = await PasswordUtil.comparePassword(
      loginData.password,
      user.password
    );
    if (!isValidPassword)
      throw new ErrorResponseV2(ErrorCode.INVALID_CREDENTIALS);
    const userData: UserData = {
      email: user.email,
      roles: await this.userRoleRepository.getAllByUser(user.id),
    };
    return AuthUtil.generateAuthToken(userData);
  }

  public async changePassword(
    email: string,
    data: ChangePasswordDTO
  ): Promise<BaseUser> {
    const user = await this.userRepository.getByEmail(email);
    if (!user || !user.id) throw new ErrorResponseV2(ErrorCode.NOT_FOUND_USER);
    if (await PasswordUtil.comparePassword(data.oldPassword, user.password)) {
      return plainToClass(
        BaseUser,
        await this.userRepository.update(user.id, {
          password: await PasswordUtil.hashPassword(data.password),
        }),
        { excludeExtraneousValues: true }
      );
    }
    throw new ErrorResponseV2(ErrorCode.INVALID_CREDENTIALS);
  }

  public async requestResetPassword(data: RequestResetPassword): Promise<void> {
    const user = await this.userRepository.getByEmail(data.email);
    if (user && user.id) {
      const userData: UserData = {
        email: user.email,
        roles: await this.userRoleRepository.getAllByUser(user.id),
      };
      const token = AuthUtil.generateResetPwdToken(userData);
      await this.userRepository.update(user.id, { resetPwdToken: token });
      MailUtil.SendMail({
        to: user.email,
        subject: `[AIPhysiognomy] Request Reset Password`,
        text: `${token}`,
      });
    }
  }

  public async resetPassword(
    token: string,
    data: ResetPassword
  ): Promise<boolean> {
    try {
      const tokenData = jwt.verify(token, config.auth.jwtSecret) as {
        email: string;
      };
      const user = await this.userRepository.getByEmail(tokenData.email);
      if (user && user.id && user.resetPwdToken == token) {
        user.password = await PasswordUtil.hashPassword(data.password);
        await this.userRepository.update(user.id, {
          password: user.password,
          resetPwdToken: "",
        });
        return true;
      }
      throw new ErrorResponseV2(ErrorCode.INVALID_REQUEST);
    } catch (error) {
      if (error instanceof jwt.TokenExpiredError)
        throw new ErrorResponseV2(ErrorCode.EXPIRED_TOKEN);
      throw new ErrorResponseV2(ErrorCode.INVALID_REQUEST);
    }
  }

  public async refreshToken(
    refreshData: RefreshTokenRequest
  ): Promise<AuthResponse> {
    try {
      const tokenData = jwt.verify(
        refreshData.refreshToken,
        config.auth.jwtSecret
      ) as { email: string; type: string };
      if (tokenData.email && tokenData.type === "refresh") {
        const user = await this.userRepository.getByEmail(tokenData.email);
        if (!user || !user.id)
          throw new ErrorResponseV2(ErrorCode.INVALID_TOKEN_CLAIM);
        const userData: UserData = {
          email: user.email,
          roles: await this.userRoleRepository.getAllByUser(user.id),
        };
        return AuthUtil.generateAuthToken(userData);
      }
      throw new ErrorResponseV2(ErrorCode.INVALID_TOKEN_TYPE);
    } catch (error) {
      if (error instanceof jwt.TokenExpiredError)
        throw new ErrorResponseV2(ErrorCode.EXPIRED_TOKEN);
      throw new ErrorResponseV2(ErrorCode.INVALID_REQUEST);
    }
  }

  public async loginWithGoogleIdToken(idToken: string): Promise<AuthResponse> {
    try {
      // Try verifying with Web Client ID first (common for cross-platform apps using serverClientId)
      const ticket = await webClient.verifyIdToken({
        idToken,
        audience: config.auth.googleWebClientId,
      });
      const payload = ticket.getPayload();
      if (payload?.email) {
        return this.upsertAndIssue(payload);
      }
    } catch (e) {
      // If web client verification fails, try Android client
      try {
        const ticket = await androidClient.verifyIdToken({
          idToken,
          audience: config.auth.googleAndroidClientId,
        });
        const payload = ticket.getPayload();
        if (payload?.email) {
          return this.upsertAndIssue(payload);
        }
      } catch (e2) {
        throw new ErrorResponseV2(ErrorCode.INVALID_GOOGLE_TOKEN);
      }
    }
    throw new ErrorResponseV2(ErrorCode.INVALID_GOOGLE_TOKEN);
  }

  public async loginWithGoogleCode(code: string): Promise<AuthResponse> {
    const res = await fetch("https://oauth2.googleapis.com/token", {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: new URLSearchParams({
        code,
        client_id: config.auth.googleWebClientId,
        client_secret: config.auth.googleWebClientSecret,
        grant_type: "authorization_code",
        redirect_uri: config.auth.googleRedirectUrl || "postmessage",
      }),
    });
    const text = await res.text();
    if (!res.ok)
      throw new ErrorResponseV2(
        ErrorCode.INVALID_REQUEST,
        `GOOGLE_EXCHANGE_FAILED: ${text}`
      );
    const tok = JSON.parse(text) as {
      id_token?: string;
      access_token?: string;
    };

    let payload: any | undefined;
    if (tok.id_token) {
      const ticket = await webClient.verifyIdToken({
        idToken: tok.id_token,
        audience: config.auth.googleWebClientId,
      });
      payload = ticket.getPayload();
    }
    if (!payload?.email && tok.access_token) {
      const u = await fetch(
        "https://openidconnect.googleapis.com/v1/userinfo",
        {
          headers: { Authorization: `Bearer ${tok.access_token}` },
        }
      );
      if (u.ok) payload = await u.json();
    }
    if (!payload?.email)
      throw new ErrorResponseV2(ErrorCode.INVALID_GOOGLE_TOKEN);
    return this.upsertAndIssue(payload);
  }

  public async loginWithGoogle(tokenOrCode: string): Promise<AuthResponse> {
    const looksLikeJwt = tokenOrCode.split(".").length === 3;
    if (looksLikeJwt) return this.loginWithGoogleIdToken(tokenOrCode);
    return this.loginWithGoogleCode(tokenOrCode);
  }

  private async upsertAndIssue(payload: any): Promise<AuthResponse> {
    const googleId = payload.sub as string;
    const email = payload.email as string;
    const firstName = payload.given_name || "";
    const lastName = payload.family_name || "";
    const avatar = payload.picture || null;

    let user = await this.userRepository.getByGoogleId(googleId);
    if (!user) {
      user = await this.userRepository.getByEmail(email);
      if (user) {
        user = (await prismaManager.withConnection(
          async (client: PrismaClient) =>
            client.user.update({
              where: { id: user!.id },
              data: {
                googleId,
                resetPwdToken: user?.resetPwdToken || undefined,
              },
            })
        )) as unknown as User;
      } else {
        user = await this.userRepository.createGoogleUser({
          email,
          firstName,
          lastName,
          phone: null,
          age: null,
          gender: null,
          avatar,
          googleId,
        });
      }
    }
    if (!user) throw new ErrorResponseV2(ErrorCode.NOT_FOUND_USER);
    const roles = await this.userRoleRepository.getAllByUser(user.id!);
    const userData: UserData = { email: user.email, roles };
    return AuthUtil.generateAuthToken(userData);
  }
}
