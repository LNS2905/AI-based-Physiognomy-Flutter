import { inject, injectable } from "inversify";
import { IChatService } from "./interfaces/ichat.service";
import { IUserRepository } from "../repositories/interfaces/iuser.repository";
import { ITransactionRepository } from "../repositories/interfaces/itransaction.repository";
import { ChatResponse } from "../business_objects/chat";
import { ErrorResponseV2 } from "../business_objects/error.response";
import { ErrorCode } from "../utils/enums/enums";
import { TransactionType } from "../entities/transaction";

@injectable()
export class ChatService implements IChatService {
  constructor(
    @inject("IUserRepository") private userRepository: IUserRepository,
    @inject("ITransactionRepository")
    private transactionRepository: ITransactionRepository
  ) {}

  /**
   * Mock chat service - only handles credit deduction
   * Real AI chatbot will be in separate backend service
   */
  public async sendMessage(
    userId: number,
    message: string
  ): Promise<ChatResponse> {
    // 1. Check if user has enough credits
    const user = await this.userRepository.getById(userId);
    if (!user) {
      throw new ErrorResponseV2(ErrorCode.NOT_FOUND_USER);
    }

    const currentCredits = user.credits ?? 0;
    if (currentCredits < 1) {
      throw new ErrorResponseV2(ErrorCode.INSUFFICIENT_CREDIT);
    }

    // 2. Deduct 1 credit
    const newCredits = currentCredits - 1;
    await this.userRepository.update(userId, { credits: newCredits } as any);

    // 3. Create transaction record (OUT type)
    await this.transactionRepository.create({
      transactionType: TransactionType.OUT,
      creditAmount: 1,
      transactionStatus: true,
      description: `AI Chatbot: "${message.substring(0, 50)}..."`,
      userId: userId,
    });

    // 4. Return mock AI response
    const mockResponse = this.generateMockResponse(message);

    return new ChatResponse(
      this.generateId(),
      mockResponse,
      1, // credits used
      newCredits // remaining credits
    );
  }

  private generateMockResponse(userMessage: string): string {
    // Simple mock responses based on message content
    const lowerMessage = userMessage.toLowerCase();
    
    if (lowerMessage.includes("hello") || lowerMessage.includes("hi")) {
      return "Hello! I'm your AI assistant. This is a mock response. The real AI chatbot will be integrated later from a separate backend service.";
    }
    
    if (lowerMessage.includes("credit")) {
      return "I see you're asking about credits. Each message costs 1 credit. You can buy more credits in the payment section.";
    }
    
    if (lowerMessage.includes("help")) {
      return "This is a mock AI chatbot for testing the payment system. Real AI responses will come from a separate microservice later.";
    }
    
    // Default response
    return `Mock AI Response: I received your message "${userMessage}". The actual AI chatbot backend will be integrated later. This endpoint only handles credit deduction for now.`;
  }

  private generateId(): string {
    return `msg_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  }
}
