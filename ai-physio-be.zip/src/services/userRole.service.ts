import { inject, injectable } from "inversify";
import { BaseUserRole } from "../entities/userRole";
import { IUserRoleService } from "./interfaces/iuserRole.service";
import { IUserRoleRepository } from "../repositories/interfaces/iuserRole.repository";
import { plainToClass, plainToInstance } from "class-transformer";
import { Pagination, PaginationParameter } from "../business_objects/pagination";
import { RoleName } from "../utils/enums/enums";

@injectable()
export class UserRoleService implements IUserRoleService {
    constructor(
        @inject("IUserRoleRepository") private userRoleRepository: IUserRoleRepository,
    ) { }

    public async getUserByRole(roleName: RoleName[], para: PaginationParameter): Promise<Pagination<BaseUserRole>> {
        const source = await this.userRoleRepository.getByRole(roleName, para);
        const items = plainToInstance(BaseUserRole, source.items, { excludeExtraneousValues: true });
        return new Pagination<BaseUserRole>(items, source.totalCount, source.currentPage, source.pageSize);
    }

    public async getRoleByUser(userId: number, para: PaginationParameter): Promise<Pagination<BaseUserRole>> {
        const source = await this.userRoleRepository.getByUser(userId, para);
        const items = plainToInstance(BaseUserRole, source.items, { excludeExtraneousValues: true });
        return new Pagination<BaseUserRole>(items, source.totalCount, source.currentPage, source.pageSize);
    }

    public async updateUserRole(userId: number, roleName: RoleName[]): Promise<BaseUserRole[]> {
        return plainToClass(BaseUserRole, await this.userRoleRepository.updateUserRole(userId, roleName), { excludeExtraneousValues: true, enableImplicitConversion: true });
    }
}