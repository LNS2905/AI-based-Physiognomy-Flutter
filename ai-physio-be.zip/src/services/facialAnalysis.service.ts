import { PrismaClient } from "@prisma/client";
import { FacialAnalysisDto } from "../dto/facialAnalysis.dto";

const prisma = new PrismaClient();

export class FacialAnalysisService {
  async saveFacialAnalysis(data: FacialAnalysisDto) {
    const {
      userId,
      resultText,
      faceShape,
      harmonyScore,
      probabilities,
      harmonyDetails,
      metrics,
      annotatedImage,
      processedAt,
    } = data;

    const savedData = await prisma.facialAnalysis.create({
      // Ensure the correct type and model name are used
      data: {
        userId: parseInt(userId, 10),
        resultText,
        faceShape,
        harmonyScore,
        probabilities,
        harmonyDetails,
        metrics,
        annotatedImage,
        processedAt: new Date(processedAt),
      },
    });

    return savedData;
  }

  async getFacialAnalysesByUser(userId: number) {
    const results = await prisma.facialAnalysis.findMany({
      where: { userId },
      orderBy: { processedAt: "desc" },
    });

    return results;
  }
  async getAllFacialAnalyses() {
    const results = await prisma.facialAnalysis.findMany({
      orderBy: { processedAt: "desc" },
    });

    return results;
  }
  async deleteFacialAnalysis(id: number) {
    const deletedData = await prisma.facialAnalysis.delete({
      where: { id },
    });

    return deletedData;
  }
  async updateFacialAnalysis(id: number, data: FacialAnalysisDto) {
    const {
      userId,
      resultText,
      faceShape,
      harmonyScore,
      probabilities,
      harmonyDetails,
      metrics,
      annotatedImage,
      processedAt,
    } = data;

    const updatedData = await prisma.facialAnalysis.update({
      where: { id },
      data: {
        userId: parseInt(userId, 10),
        resultText,
        faceShape,
        harmonyScore,
        probabilities,
        harmonyDetails,
        metrics,
        annotatedImage,
        processedAt: new Date(processedAt),
      },
    });

    return updatedData;
  }
}
