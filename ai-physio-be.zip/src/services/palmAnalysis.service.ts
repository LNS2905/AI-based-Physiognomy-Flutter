import { LifeAspectType, LineType } from "@prisma/client";
import { PalmAnalysisDto } from "../dto/palmAnalysis.dto";
import { prismaManager } from "../utils/prisma";
import { IPalmAnalysisService } from "./interfaces/ipalmAnalysis.service";

export class PalmAnalysisService implements IPalmAnalysisService {
  async savePalmAnalysis(data: PalmAnalysisDto) {
    const {
      userId,
      annotatedImage,
      palmLinesDetected,
      detectedHeartLine,
      detectedHeadLine,
      detectedLifeLine,
      detectedFateLine,
      targetLines,
      imageHeight,
      imageWidth,
      imageChannels,
      summaryText,
      interpretations,
      lifeAspects,
    } = data;

    const saved = await prismaManager.withConnection((prisma) =>
      prisma.palmAnalysis.create({
        data: {
          userId,
          annotatedImage: annotatedImage ?? "",
          palmLinesDetected: palmLinesDetected ?? 0,
          detectedHeartLine: detectedHeartLine ?? 0,
          detectedHeadLine: detectedHeadLine ?? 0,
          detectedLifeLine: detectedLifeLine ?? 0,
          detectedFateLine: detectedFateLine ?? 0,
          targetLines: targetLines ?? "[]",
          imageHeight: imageHeight ?? 0,
          imageWidth: imageWidth ?? 0,
          imageChannels: imageChannels ?? 0,
          summaryText: summaryText ?? "",

          interpretations: {
            create: (interpretations ?? []).map((item) => ({
              lineType: (item.lineType ?? "unknown") as LineType,
              pattern: item.pattern ?? "",
              meaning: item.meaning ?? "",
              lengthPx: item.lengthPx ?? 0,
              confidence: item.confidence ?? 0,
            })),
          },

          lifeAspects: {
            create: (lifeAspects ?? []).map((aspect) => ({
              aspect: (aspect.aspect ?? "personality") as LifeAspectType,
              content: aspect.content ?? "",
            })),
          },
        },
        include: {
          interpretations: true,
          lifeAspects: true,
        },
      })
    );

    return { success: true, data: saved };
  }

  async getPalmAnalysisByUser(userId: number) {
    const result = await prismaManager.withConnection((prisma) =>
      prisma.palmAnalysis.findMany({
        where: { userId },
        orderBy: { createdAt: "desc" },
        include: {
          interpretations: true,
          lifeAspects: true,
        },
      })
    );

    return { success: true, data: result };
  }
  async getAllPalmAnalyses(): Promise<any> {
    const result = await prismaManager.withConnection((prisma) =>
      prisma.palmAnalysis.findMany({
        orderBy: { createdAt: "desc" },
        include: {
          interpretations: true,
          lifeAspects: true,
        },
      })
    );

    return { success: true, data: result };
  }

  async deletePalmAnalysis(id: number) {
    const deleted = await prismaManager.withConnection((prisma) =>
      prisma.palmAnalysis.delete({
        where: { id },
      })
    );

    return { success: true, data: deleted };
  }

  async updatePalmAnalysis(id: number, data: PalmAnalysisDto) {
    const {
      userId,
      annotatedImage,
      palmLinesDetected,
      detectedHeartLine,
      detectedHeadLine,
      detectedLifeLine,
      detectedFateLine,
      targetLines,
      imageHeight,
      imageWidth,
      imageChannels,
      summaryText,
      interpretations,
      lifeAspects,
    } = data;

    const updated = await prismaManager.withConnection((prisma) =>
      prisma.palmAnalysis.update({
        where: { id },
        data: {
          userId,
          annotatedImage: annotatedImage ?? "",
          palmLinesDetected: palmLinesDetected ?? 0,
          detectedHeartLine: detectedHeartLine ?? 0,
          detectedHeadLine: detectedHeadLine ?? 0,
          detectedLifeLine: detectedLifeLine ?? 0,
          detectedFateLine: detectedFateLine ?? 0,
          targetLines: targetLines ?? "[]",
          imageHeight: imageHeight ?? 0,
          imageWidth: imageWidth ?? 0,
          imageChannels: imageChannels ?? 0,
          summaryText: summaryText ?? "",

          interpretations: {
            deleteMany: {},
            create: (interpretations ?? []).map((item) => ({
              lineType: (item.lineType ?? "unknown") as LineType,
              pattern: item.pattern ?? "",
              meaning: item.meaning ?? "",
              lengthPx: item.lengthPx ?? 0,
              confidence: item.confidence ?? 0,
            })),
          },

          lifeAspects: {
            deleteMany: {},
            create: (lifeAspects ?? []).map((aspect) => ({
              aspect: (aspect.aspect ?? "personality") as LifeAspectType,
              content: aspect.content ?? "",
            })),
          },
        },
        include: {
          interpretations: true,
          lifeAspects: true,
        },
      })
    );

    return { success: true, data: updated };
  }
}
