import { Pagination, PaginationParameter } from "../../business_objects/pagination";
import { BaseUserRole } from "../../entities/userRole";
import { RoleName } from "../../utils/enums/enums";

export interface IUserRoleService {
    getUserByRole(roleName: RoleName[], para: PaginationParameter): Promise<Pagination<BaseUserRole>>;
    getRoleByUser(userId: number, para: PaginationParameter): Promise<Pagination<BaseUserRole>>;
    updateUserRole(userId: number, roleName: RoleName[]): Promise<BaseUserRole[]>;
}