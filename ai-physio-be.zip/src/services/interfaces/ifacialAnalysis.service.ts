export interface IFacialAnalysisService {
  saveFacialAnalysis(data: any): Promise<any>;
  getFacialAnalysesByUser(userId: number): Promise<any>;
  getAllFacialAnalyses(): Promise<any>;
}
