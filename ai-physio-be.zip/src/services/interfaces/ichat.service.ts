import { ChatResponse } from "../../business_objects/chat";

export interface IChatService {
  sendMessage(userId: number, message: string): Promise<ChatResponse>;
}
