export interface IPalmAnalysisService {
  savePalmAnalysis(data: any): Promise<any>;
}
