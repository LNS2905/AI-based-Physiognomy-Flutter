import {
  AuthRequest,
  AuthResponse,
  BaseUser,
  ChangePasswordDTO,
  RefreshTokenRequest,
  RequestResetPassword,
  ResetPassword,
} from "../../entities/user";

export interface IAuthService {
  login(loginData: AuthRequest): Promise<AuthResponse>;
  refreshToken(refreshData: RefreshTokenRequest): Promise<AuthResponse>;
  changePassword(email: string, data: ChangePasswordDTO): Promise<BaseUser>;
  requestResetPassword(data: RequestResetPassword): Promise<void>;
  resetPassword(token: string, data: ResetPassword): Promise<boolean>;
  loginWithGoogleIdToken(idToken: string): Promise<AuthResponse>;
  loginWithGoogleCode(code: string): Promise<AuthResponse>;
  loginWithGoogle(tokenOrCode: string): Promise<AuthResponse>;
}
