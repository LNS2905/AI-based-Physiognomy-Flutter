/* tslint:disable */
/* eslint-disable */
// WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa
import type { TsoaRoute } from '@tsoa/runtime';
import { fetchMiddlewares, ExpressTemplateService } from '@tsoa/runtime';
// WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa
import { UserRoleController } from './../controllers/userRole.controller';
// WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa
import { UserController } from './../controllers/user.controller';
// WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa
import { PaymentController } from './../controllers/payment.controller';
// WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa
import { PalmAnalysisController } from './../controllers/palmAnalysis.controller';
// WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa
import { FacialAnalysisController } from './../controllers/facialAnalysis.controller';
// WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa
import { ChatController } from './../controllers/chat.controller';
// WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa
import { AuthController } from './../controllers/auth.controller';
import { expressAuthentication } from './authentication';
// @ts-ignore - no great way to install types from subpackage
import { iocContainer } from './../dependency.injection';
import type { IocContainer, IocContainerFactory } from '@tsoa/runtime';
import type { Request as ExRequest, Response as ExResponse, RequestHandler, Router } from 'express';

const expressAuthenticationRecasted = expressAuthentication as (req: ExRequest, securityName: string, scopes?: string[], res?: ExResponse) => Promise<any>;


// WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa

const models: TsoaRoute.Models = {
    "SuccessCode": {
        "dataType": "refEnum",
        "enums": ["OPERATION_SUCCESS"],
    },
    // WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa
    "GeneralResponse": {
        "dataType": "refAlias",
        "type": { "dataType": "nestedObjectLiteral", "nestedProperties": { "data": { "dataType": "any", "required": true }, "code": { "ref": "SuccessCode", "required": true }, "message": { "dataType": "string", "required": true } }, "validators": {} },
    },
    // WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa
    "RoleName": {
        "dataType": "refEnum",
        "enums": ["admin", "user"],
    },
    // WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa
    "_36_Enums.Gender": {
        "dataType": "refAlias",
        "type": { "dataType": "union", "subSchemas": [{ "dataType": "enum", "enums": ["male"] }, { "dataType": "enum", "enums": ["female"] }], "validators": {} },
    },
    // WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa
    "Gender": {
        "dataType": "refAlias",
        "type": { "ref": "_36_Enums.Gender", "validators": {} },
    },
    // WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa
    "CreateUserDTO": {
        "dataType": "refObject",
        "properties": {
            "username": { "dataType": "union", "subSchemas": [{ "dataType": "string" }, { "dataType": "enum", "enums": [null] }] },
            "password": { "dataType": "string", "required": true },
            "confirmPassword": { "dataType": "string" },
            "firstName": { "dataType": "string", "required": true },
            "lastName": { "dataType": "string", "required": true },
            "email": { "dataType": "string", "required": true },
            "phone": { "dataType": "string", "required": true },
            "age": { "dataType": "double", "required": true },
            "gender": { "ref": "Gender", "required": true },
            "avatar": { "dataType": "union", "subSchemas": [{ "dataType": "string" }, { "dataType": "enum", "enums": [null] }] },
        },
        "additionalProperties": false,
    },
    // WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa
    "UpdateUserDTO": {
        "dataType": "refObject",
        "properties": {
            "firstName": { "dataType": "string", "required": true },
            "lastName": { "dataType": "string", "required": true },
            "email": { "dataType": "string", "required": true },
            "phone": { "dataType": "string", "required": true },
            "age": { "dataType": "double", "required": true },
            "gender": { "ref": "Gender", "required": true },
            "avatar": { "dataType": "string" },
        },
        "additionalProperties": false,
    },
    // WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa
    "StripeProductData": {
        "dataType": "refObject",
        "properties": {
            "name": { "dataType": "string", "required": true },
        },
        "additionalProperties": false,
    },
    // WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa
    "StripePriceData": {
        "dataType": "refObject",
        "properties": {
            "currency": { "dataType": "string", "required": true },
            "product_data": { "ref": "StripeProductData", "required": true },
            "unit_amount": { "dataType": "double", "required": true },
        },
        "additionalProperties": false,
    },
    // WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa
    "StripeLineItem": {
        "dataType": "refObject",
        "properties": {
            "price_data": { "ref": "StripePriceData", "required": true },
            "quantity": { "dataType": "double", "required": true },
        },
        "additionalProperties": false,
    },
    // WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa
    "stripe.Stripe.Checkout.Session.Mode": {
        "dataType": "refAlias",
        "type": { "dataType": "union", "subSchemas": [{ "dataType": "enum", "enums": ["payment"] }, { "dataType": "enum", "enums": ["setup"] }, { "dataType": "enum", "enums": ["subscription"] }], "validators": {} },
    },
    // WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa
    "PaymentSessionRequest": {
        "dataType": "refObject",
        "properties": {
            "lineItems": { "dataType": "array", "array": { "dataType": "refObject", "ref": "StripeLineItem" }, "required": true },
            "mode": { "ref": "stripe.Stripe.Checkout.Session.Mode", "required": true },
        },
        "additionalProperties": false,
    },
    // WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa
    "_36_Enums.LineType": {
        "dataType": "refAlias",
        "type": { "dataType": "union", "subSchemas": [{ "dataType": "enum", "enums": ["heart"] }, { "dataType": "enum", "enums": ["head"] }, { "dataType": "enum", "enums": ["life"] }, { "dataType": "enum", "enums": ["fate"] }, { "dataType": "enum", "enums": ["sun"] }, { "dataType": "enum", "enums": ["unknown"] }], "validators": {} },
    },
    // WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa
    "LineType": {
        "dataType": "refAlias",
        "type": { "ref": "_36_Enums.LineType", "validators": {} },
    },
    // WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa
    "InterpretationDto": {
        "dataType": "refObject",
        "properties": {
            "lineType": { "ref": "LineType", "required": true },
            "pattern": { "dataType": "string", "required": true },
            "meaning": { "dataType": "string", "required": true },
            "lengthPx": { "dataType": "double", "required": true },
            "confidence": { "dataType": "double", "required": true },
        },
        "additionalProperties": false,
    },
    // WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa
    "_36_Enums.LifeAspectType": {
        "dataType": "refAlias",
        "type": { "dataType": "union", "subSchemas": [{ "dataType": "enum", "enums": ["health"] }, { "dataType": "enum", "enums": ["career"] }, { "dataType": "enum", "enums": ["relationships"] }, { "dataType": "enum", "enums": ["personality"] }], "validators": {} },
    },
    // WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa
    "LifeAspectType": {
        "dataType": "refAlias",
        "type": { "ref": "_36_Enums.LifeAspectType", "validators": {} },
    },
    // WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa
    "LifeAspectDto": {
        "dataType": "refObject",
        "properties": {
            "aspect": { "ref": "LifeAspectType", "required": true },
            "content": { "dataType": "string", "required": true },
        },
        "additionalProperties": false,
    },
    // WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa
    "PalmAnalysisDto": {
        "dataType": "refObject",
        "properties": {
            "userId": { "dataType": "double", "required": true },
            "annotatedImage": { "dataType": "string", "required": true },
            "palmLinesDetected": { "dataType": "double" },
            "detectedHeartLine": { "dataType": "double" },
            "detectedHeadLine": { "dataType": "double" },
            "detectedLifeLine": { "dataType": "double" },
            "detectedFateLine": { "dataType": "double" },
            "targetLines": { "dataType": "string", "required": true },
            "imageHeight": { "dataType": "double", "required": true },
            "imageWidth": { "dataType": "double", "required": true },
            "imageChannels": { "dataType": "double", "required": true },
            "summaryText": { "dataType": "string", "required": true },
            "interpretations": { "dataType": "array", "array": { "dataType": "refObject", "ref": "InterpretationDto" }, "required": true },
            "lifeAspects": { "dataType": "array", "array": { "dataType": "refObject", "ref": "LifeAspectDto" }, "required": true },
        },
        "additionalProperties": false,
    },
    // WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa
    "Record_string.number_": {
        "dataType": "refAlias",
        "type": { "dataType": "nestedObjectLiteral", "nestedProperties": {}, "additionalProperties": { "dataType": "double" }, "validators": {} },
    },
    // WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa
    "FacialAnalysisDto": {
        "dataType": "refObject",
        "properties": {
            "userId": { "dataType": "string", "required": true },
            "resultText": { "dataType": "string", "required": true },
            "faceShape": { "dataType": "string", "required": true },
            "harmonyScore": { "dataType": "double", "required": true },
            "probabilities": { "ref": "Record_string.number_", "required": true },
            "harmonyDetails": { "ref": "Record_string.number_", "required": true },
            "metrics": { "dataType": "array", "array": { "dataType": "nestedObjectLiteral", "nestedProperties": { "orientation": { "dataType": "string", "required": true }, "percentage": { "dataType": "double", "required": true }, "pixels": { "dataType": "double", "required": true }, "label": { "dataType": "string", "required": true } } }, "required": true },
            "annotatedImage": { "dataType": "string", "required": true },
            "processedAt": { "dataType": "string", "required": true },
        },
        "additionalProperties": false,
    },
    // WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa
    "ChatRequest": {
        "dataType": "refObject",
        "properties": {
            "message": { "dataType": "string", "required": true },
        },
        "additionalProperties": false,
    },
    // WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa
    "AuthRequest": {
        "dataType": "refObject",
        "properties": {
            "username": { "dataType": "string", "required": true },
            "password": { "dataType": "string", "required": true },
        },
        "additionalProperties": false,
    },
    // WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa
    "ChangePasswordDTO": {
        "dataType": "refObject",
        "properties": {
            "oldPassword": { "dataType": "string", "required": true },
            "password": { "dataType": "string", "required": true },
        },
        "additionalProperties": false,
    },
    // WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa
    "RequestResetPassword": {
        "dataType": "refObject",
        "properties": {
            "email": { "dataType": "string", "required": true },
        },
        "additionalProperties": false,
    },
    // WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa
    "ResetPassword": {
        "dataType": "refObject",
        "properties": {
            "password": { "dataType": "string", "required": true },
        },
        "additionalProperties": false,
    },
    // WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa
    "RefreshTokenRequest": {
        "dataType": "refObject",
        "properties": {
            "refreshToken": { "dataType": "string", "required": true },
        },
        "additionalProperties": false,
    },
    // WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa
};
const templateService = new ExpressTemplateService(models, { "noImplicitAdditionalProperties": "silently-remove-extras", "bodyCoercion": true });

// WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa




export function RegisterRoutes(app: Router) {

    // ###########################################################################################################
    //  NOTE: If you do not see routes for all of your controllers in this file, then you might not have informed tsoa of where to look
    //      Please look into the "controllerPathGlobs" config option described in the readme: https://github.com/lukeautry/tsoa
    // ###########################################################################################################



    const argsUserRoleController_getUserByRole: Record<string, TsoaRoute.ParameterSchema> = {
        roleName: { "in": "query", "name": "roleName", "required": true, "dataType": "array", "array": { "dataType": "refEnum", "ref": "RoleName" } },
        pageIndex: { "in": "query", "name": "pageIndex", "dataType": "double" },
        pageSize: { "in": "query", "name": "pageSize", "dataType": "double" },
    };
    app.get('/user-role/users',
        authenticateMiddleware([{ "jwt": ["ADMIN"] }]),
        ...(fetchMiddlewares<RequestHandler>(UserRoleController)),
        ...(fetchMiddlewares<RequestHandler>(UserRoleController.prototype.getUserByRole)),

        async function UserRoleController_getUserByRole(request: ExRequest, response: ExResponse, next: any) {

            // WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa

            let validatedArgs: any[] = [];
            try {
                validatedArgs = templateService.getValidatedArgs({ args: argsUserRoleController_getUserByRole, request, response });

                const container: IocContainer = typeof iocContainer === 'function' ? (iocContainer as IocContainerFactory)(request) : iocContainer;

                const controller: any = await container.get<UserRoleController>(UserRoleController);
                if (typeof controller['setStatus'] === 'function') {
                    controller.setStatus(undefined);
                }

                await templateService.apiHandler({
                    methodName: 'getUserByRole',
                    controller,
                    response,
                    next,
                    validatedArgs,
                    successStatus: undefined,
                });
            } catch (err) {
                return next(err);
            }
        });
    // WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa
    const argsUserRoleController_getRoleByUser: Record<string, TsoaRoute.ParameterSchema> = {
        userId: { "in": "query", "name": "userId", "required": true, "dataType": "double" },
        pageIndex: { "in": "query", "name": "pageIndex", "dataType": "double" },
        pageSize: { "in": "query", "name": "pageSize", "dataType": "double" },
    };
    app.get('/user-role/roles',
        authenticateMiddleware([{ "jwt": ["ADMIN"] }]),
        ...(fetchMiddlewares<RequestHandler>(UserRoleController)),
        ...(fetchMiddlewares<RequestHandler>(UserRoleController.prototype.getRoleByUser)),

        async function UserRoleController_getRoleByUser(request: ExRequest, response: ExResponse, next: any) {

            // WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa

            let validatedArgs: any[] = [];
            try {
                validatedArgs = templateService.getValidatedArgs({ args: argsUserRoleController_getRoleByUser, request, response });

                const container: IocContainer = typeof iocContainer === 'function' ? (iocContainer as IocContainerFactory)(request) : iocContainer;

                const controller: any = await container.get<UserRoleController>(UserRoleController);
                if (typeof controller['setStatus'] === 'function') {
                    controller.setStatus(undefined);
                }

                await templateService.apiHandler({
                    methodName: 'getRoleByUser',
                    controller,
                    response,
                    next,
                    validatedArgs,
                    successStatus: undefined,
                });
            } catch (err) {
                return next(err);
            }
        });
    // WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa
    const argsUserRoleController_updateUserRole: Record<string, TsoaRoute.ParameterSchema> = {
        userId: { "in": "query", "name": "userId", "required": true, "dataType": "double" },
        roleName: { "in": "body", "name": "roleName", "required": true, "dataType": "array", "array": { "dataType": "refEnum", "ref": "RoleName" } },
    };
    app.put('/user-role',
        authenticateMiddleware([{ "jwt": ["ADMIN"] }]),
        ...(fetchMiddlewares<RequestHandler>(UserRoleController)),
        ...(fetchMiddlewares<RequestHandler>(UserRoleController.prototype.updateUserRole)),

        async function UserRoleController_updateUserRole(request: ExRequest, response: ExResponse, next: any) {

            // WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa

            let validatedArgs: any[] = [];
            try {
                validatedArgs = templateService.getValidatedArgs({ args: argsUserRoleController_updateUserRole, request, response });

                const container: IocContainer = typeof iocContainer === 'function' ? (iocContainer as IocContainerFactory)(request) : iocContainer;

                const controller: any = await container.get<UserRoleController>(UserRoleController);
                if (typeof controller['setStatus'] === 'function') {
                    controller.setStatus(undefined);
                }

                await templateService.apiHandler({
                    methodName: 'updateUserRole',
                    controller,
                    response,
                    next,
                    validatedArgs,
                    successStatus: undefined,
                });
            } catch (err) {
                return next(err);
            }
        });
    // WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa
    const argsUserController_getUsers: Record<string, TsoaRoute.ParameterSchema> = {
        id: { "in": "query", "name": "id", "required": true, "dataType": "double" },
    };
    app.get('/users',
        authenticateMiddleware([{ "jwt": ["ADMIN"] }]),
        ...(fetchMiddlewares<RequestHandler>(UserController)),
        ...(fetchMiddlewares<RequestHandler>(UserController.prototype.getUsers)),

        async function UserController_getUsers(request: ExRequest, response: ExResponse, next: any) {

            // WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa

            let validatedArgs: any[] = [];
            try {
                validatedArgs = templateService.getValidatedArgs({ args: argsUserController_getUsers, request, response });

                const container: IocContainer = typeof iocContainer === 'function' ? (iocContainer as IocContainerFactory)(request) : iocContainer;

                const controller: any = await container.get<UserController>(UserController);
                if (typeof controller['setStatus'] === 'function') {
                    controller.setStatus(undefined);
                }

                await templateService.apiHandler({
                    methodName: 'getUsers',
                    controller,
                    response,
                    next,
                    validatedArgs,
                    successStatus: undefined,
                });
            } catch (err) {
                return next(err);
            }
        });
    // WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa
    const argsUserController_getUsersByEmail: Record<string, TsoaRoute.ParameterSchema> = {
        email: { "in": "path", "name": "email", "required": true, "dataType": "string" },
    };
    app.get('/users/email/:email',
        authenticateMiddleware([{ "jwt": ["ADMIN"] }]),
        ...(fetchMiddlewares<RequestHandler>(UserController)),
        ...(fetchMiddlewares<RequestHandler>(UserController.prototype.getUsersByEmail)),

        async function UserController_getUsersByEmail(request: ExRequest, response: ExResponse, next: any) {

            // WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa

            let validatedArgs: any[] = [];
            try {
                validatedArgs = templateService.getValidatedArgs({ args: argsUserController_getUsersByEmail, request, response });

                const container: IocContainer = typeof iocContainer === 'function' ? (iocContainer as IocContainerFactory)(request) : iocContainer;

                const controller: any = await container.get<UserController>(UserController);
                if (typeof controller['setStatus'] === 'function') {
                    controller.setStatus(undefined);
                }

                await templateService.apiHandler({
                    methodName: 'getUsersByEmail',
                    controller,
                    response,
                    next,
                    validatedArgs,
                    successStatus: undefined,
                });
            } catch (err) {
                return next(err);
            }
        });
    // WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa
    const argsUserController_getAllUsers: Record<string, TsoaRoute.ParameterSchema> = {
        pageIndex: { "in": "query", "name": "pageIndex", "dataType": "double" },
        pageSize: { "in": "query", "name": "pageSize", "dataType": "double" },
    };
    app.get('/users/all',
        authenticateMiddleware([{ "jwt": ["ADMIN"] }]),
        ...(fetchMiddlewares<RequestHandler>(UserController)),
        ...(fetchMiddlewares<RequestHandler>(UserController.prototype.getAllUsers)),

        async function UserController_getAllUsers(request: ExRequest, response: ExResponse, next: any) {

            // WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa

            let validatedArgs: any[] = [];
            try {
                validatedArgs = templateService.getValidatedArgs({ args: argsUserController_getAllUsers, request, response });

                const container: IocContainer = typeof iocContainer === 'function' ? (iocContainer as IocContainerFactory)(request) : iocContainer;

                const controller: any = await container.get<UserController>(UserController);
                if (typeof controller['setStatus'] === 'function') {
                    controller.setStatus(undefined);
                }

                await templateService.apiHandler({
                    methodName: 'getAllUsers',
                    controller,
                    response,
                    next,
                    validatedArgs,
                    successStatus: undefined,
                });
            } catch (err) {
                return next(err);
            }
        });
    // WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa
    const argsUserController_createUserInternal: Record<string, TsoaRoute.ParameterSchema> = {
        userData: { "in": "body", "name": "userData", "required": true, "ref": "CreateUserDTO" },
        roleName: { "in": "query", "name": "roleName", "required": true, "dataType": "array", "array": { "dataType": "refEnum", "ref": "RoleName" } },
    };
    app.post('/users/signUpInternal',
        authenticateMiddleware([{ "jwt": ["ADMIN"] }]),
        ...(fetchMiddlewares<RequestHandler>(UserController)),
        ...(fetchMiddlewares<RequestHandler>(UserController.prototype.createUserInternal)),

        async function UserController_createUserInternal(request: ExRequest, response: ExResponse, next: any) {

            // WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa

            let validatedArgs: any[] = [];
            try {
                validatedArgs = templateService.getValidatedArgs({ args: argsUserController_createUserInternal, request, response });

                const container: IocContainer = typeof iocContainer === 'function' ? (iocContainer as IocContainerFactory)(request) : iocContainer;

                const controller: any = await container.get<UserController>(UserController);
                if (typeof controller['setStatus'] === 'function') {
                    controller.setStatus(undefined);
                }

                await templateService.apiHandler({
                    methodName: 'createUserInternal',
                    controller,
                    response,
                    next,
                    validatedArgs,
                    successStatus: undefined,
                });
            } catch (err) {
                return next(err);
            }
        });
    // WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa
    const argsUserController_createUser: Record<string, TsoaRoute.ParameterSchema> = {
        userData: { "in": "body", "name": "userData", "required": true, "ref": "CreateUserDTO" },
    };
    app.post('/users/signUp',
        ...(fetchMiddlewares<RequestHandler>(UserController)),
        ...(fetchMiddlewares<RequestHandler>(UserController.prototype.createUser)),

        async function UserController_createUser(request: ExRequest, response: ExResponse, next: any) {

            // WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa

            let validatedArgs: any[] = [];
            try {
                validatedArgs = templateService.getValidatedArgs({ args: argsUserController_createUser, request, response });

                const container: IocContainer = typeof iocContainer === 'function' ? (iocContainer as IocContainerFactory)(request) : iocContainer;

                const controller: any = await container.get<UserController>(UserController);
                if (typeof controller['setStatus'] === 'function') {
                    controller.setStatus(undefined);
                }

                await templateService.apiHandler({
                    methodName: 'createUser',
                    controller,
                    response,
                    next,
                    validatedArgs,
                    successStatus: undefined,
                });
            } catch (err) {
                return next(err);
            }
        });
    // WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa
    const argsUserController_updateUser: Record<string, TsoaRoute.ParameterSchema> = {
        id: { "in": "query", "name": "id", "required": true, "dataType": "double" },
        newData: { "in": "body", "name": "newData", "required": true, "ref": "UpdateUserDTO" },
    };
    app.put('/users',
        authenticateMiddleware([{ "jwt": ["ADMIN"] }]),
        ...(fetchMiddlewares<RequestHandler>(UserController)),
        ...(fetchMiddlewares<RequestHandler>(UserController.prototype.updateUser)),

        async function UserController_updateUser(request: ExRequest, response: ExResponse, next: any) {

            // WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa

            let validatedArgs: any[] = [];
            try {
                validatedArgs = templateService.getValidatedArgs({ args: argsUserController_updateUser, request, response });

                const container: IocContainer = typeof iocContainer === 'function' ? (iocContainer as IocContainerFactory)(request) : iocContainer;

                const controller: any = await container.get<UserController>(UserController);
                if (typeof controller['setStatus'] === 'function') {
                    controller.setStatus(undefined);
                }

                await templateService.apiHandler({
                    methodName: 'updateUser',
                    controller,
                    response,
                    next,
                    validatedArgs,
                    successStatus: undefined,
                });
            } catch (err) {
                return next(err);
            }
        });
    // WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa
    const argsUserController_updateCurrentUser: Record<string, TsoaRoute.ParameterSchema> = {
        req: { "in": "request", "name": "req", "required": true, "dataType": "object" },
        newData: { "in": "body", "name": "newData", "required": true, "ref": "UpdateUserDTO" },
    };
    app.put('/users/me',
        authenticateMiddleware([{ "jwt": [] }]),
        ...(fetchMiddlewares<RequestHandler>(UserController)),
        ...(fetchMiddlewares<RequestHandler>(UserController.prototype.updateCurrentUser)),

        async function UserController_updateCurrentUser(request: ExRequest, response: ExResponse, next: any) {

            // WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa

            let validatedArgs: any[] = [];
            try {
                validatedArgs = templateService.getValidatedArgs({ args: argsUserController_updateCurrentUser, request, response });

                const container: IocContainer = typeof iocContainer === 'function' ? (iocContainer as IocContainerFactory)(request) : iocContainer;

                const controller: any = await container.get<UserController>(UserController);
                if (typeof controller['setStatus'] === 'function') {
                    controller.setStatus(undefined);
                }

                await templateService.apiHandler({
                    methodName: 'updateCurrentUser',
                    controller,
                    response,
                    next,
                    validatedArgs,
                    successStatus: undefined,
                });
            } catch (err) {
                return next(err);
            }
        });
    // WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa
    const argsUserController_deleteUser: Record<string, TsoaRoute.ParameterSchema> = {
        id: { "in": "query", "name": "id", "required": true, "dataType": "double" },
    };
    app.delete('/users',
        authenticateMiddleware([{ "jwt": ["ADMIN"] }]),
        ...(fetchMiddlewares<RequestHandler>(UserController)),
        ...(fetchMiddlewares<RequestHandler>(UserController.prototype.deleteUser)),

        async function UserController_deleteUser(request: ExRequest, response: ExResponse, next: any) {

            // WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa

            let validatedArgs: any[] = [];
            try {
                validatedArgs = templateService.getValidatedArgs({ args: argsUserController_deleteUser, request, response });

                const container: IocContainer = typeof iocContainer === 'function' ? (iocContainer as IocContainerFactory)(request) : iocContainer;

                const controller: any = await container.get<UserController>(UserController);
                if (typeof controller['setStatus'] === 'function') {
                    controller.setStatus(undefined);
                }

                await templateService.apiHandler({
                    methodName: 'deleteUser',
                    controller,
                    response,
                    next,
                    validatedArgs,
                    successStatus: undefined,
                });
            } catch (err) {
                return next(err);
            }
        });
    // WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa
    const argsUserController_selfRecharge: Record<string, TsoaRoute.ParameterSchema> = {
        data: { "in": "body", "name": "data", "required": true, "ref": "PaymentSessionRequest" },
        req: { "in": "request", "name": "req", "required": true, "dataType": "object" },
    };
    app.post('/users/me/recharge',
        authenticateMiddleware([{ "jwt": [] }]),
        ...(fetchMiddlewares<RequestHandler>(UserController)),
        ...(fetchMiddlewares<RequestHandler>(UserController.prototype.selfRecharge)),

        async function UserController_selfRecharge(request: ExRequest, response: ExResponse, next: any) {

            // WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa

            let validatedArgs: any[] = [];
            try {
                validatedArgs = templateService.getValidatedArgs({ args: argsUserController_selfRecharge, request, response });

                const container: IocContainer = typeof iocContainer === 'function' ? (iocContainer as IocContainerFactory)(request) : iocContainer;

                const controller: any = await container.get<UserController>(UserController);
                if (typeof controller['setStatus'] === 'function') {
                    controller.setStatus(undefined);
                }

                await templateService.apiHandler({
                    methodName: 'selfRecharge',
                    controller,
                    response,
                    next,
                    validatedArgs,
                    successStatus: undefined,
                });
            } catch (err) {
                return next(err);
            }
        });
    // WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa
    const argsUserController_recharge: Record<string, TsoaRoute.ParameterSchema> = {
        data: { "in": "body", "name": "data", "required": true, "ref": "PaymentSessionRequest" },
        email: { "in": "query", "name": "email", "required": true, "dataType": "string" },
    };
    app.post('/users/recharge',
        authenticateMiddleware([{ "jwt": ["ADMIN"] }]),
        ...(fetchMiddlewares<RequestHandler>(UserController)),
        ...(fetchMiddlewares<RequestHandler>(UserController.prototype.recharge)),

        async function UserController_recharge(request: ExRequest, response: ExResponse, next: any) {

            // WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa

            let validatedArgs: any[] = [];
            try {
                validatedArgs = templateService.getValidatedArgs({ args: argsUserController_recharge, request, response });

                const container: IocContainer = typeof iocContainer === 'function' ? (iocContainer as IocContainerFactory)(request) : iocContainer;

                const controller: any = await container.get<UserController>(UserController);
                if (typeof controller['setStatus'] === 'function') {
                    controller.setStatus(undefined);
                }

                await templateService.apiHandler({
                    methodName: 'recharge',
                    controller,
                    response,
                    next,
                    validatedArgs,
                    successStatus: undefined,
                });
            } catch (err) {
                return next(err);
            }
        });
    // WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa
    const argsPaymentController_responseSessionPaymentSuccess: Record<string, TsoaRoute.ParameterSchema> = {
        session_id: { "in": "query", "name": "session_id", "required": true, "dataType": "string" },
        userId: { "in": "query", "name": "userId", "required": true, "dataType": "double" },
        redirect: { "in": "res", "name": "302", "required": true, "dataType": "void" },
    };
    app.get('/payment/success',
        ...(fetchMiddlewares<RequestHandler>(PaymentController)),
        ...(fetchMiddlewares<RequestHandler>(PaymentController.prototype.responseSessionPaymentSuccess)),

        async function PaymentController_responseSessionPaymentSuccess(request: ExRequest, response: ExResponse, next: any) {

            // WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa

            let validatedArgs: any[] = [];
            try {
                validatedArgs = templateService.getValidatedArgs({ args: argsPaymentController_responseSessionPaymentSuccess, request, response });

                const container: IocContainer = typeof iocContainer === 'function' ? (iocContainer as IocContainerFactory)(request) : iocContainer;

                const controller: any = await container.get<PaymentController>(PaymentController);
                if (typeof controller['setStatus'] === 'function') {
                    controller.setStatus(undefined);
                }

                await templateService.apiHandler({
                    methodName: 'responseSessionPaymentSuccess',
                    controller,
                    response,
                    next,
                    validatedArgs,
                    successStatus: undefined,
                });
            } catch (err) {
                return next(err);
            }
        });
    // WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa
    const argsPaymentController_responseSessionPaymentCancel: Record<string, TsoaRoute.ParameterSchema> = {
        userId: { "in": "query", "name": "userId", "required": true, "dataType": "double" },
        redirect: { "in": "res", "name": "302", "required": true, "dataType": "void" },
    };
    app.get('/payment/cancel',
        ...(fetchMiddlewares<RequestHandler>(PaymentController)),
        ...(fetchMiddlewares<RequestHandler>(PaymentController.prototype.responseSessionPaymentCancel)),

        async function PaymentController_responseSessionPaymentCancel(request: ExRequest, response: ExResponse, next: any) {

            // WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa

            let validatedArgs: any[] = [];
            try {
                validatedArgs = templateService.getValidatedArgs({ args: argsPaymentController_responseSessionPaymentCancel, request, response });

                const container: IocContainer = typeof iocContainer === 'function' ? (iocContainer as IocContainerFactory)(request) : iocContainer;

                const controller: any = await container.get<PaymentController>(PaymentController);
                if (typeof controller['setStatus'] === 'function') {
                    controller.setStatus(undefined);
                }

                await templateService.apiHandler({
                    methodName: 'responseSessionPaymentCancel',
                    controller,
                    response,
                    next,
                    validatedArgs,
                    successStatus: undefined,
                });
            } catch (err) {
                return next(err);
            }
        });
    // WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa
    const argsPaymentController_testUpdateCredit: Record<string, TsoaRoute.ParameterSchema> = {
        sessionId: { "in": "query", "name": "sessionId", "required": true, "dataType": "string" },
        userId: { "in": "query", "name": "userId", "required": true, "dataType": "double" },
    };
    app.post('/payment/test-update-credit',
        ...(fetchMiddlewares<RequestHandler>(PaymentController)),
        ...(fetchMiddlewares<RequestHandler>(PaymentController.prototype.testUpdateCredit)),

        async function PaymentController_testUpdateCredit(request: ExRequest, response: ExResponse, next: any) {

            // WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa

            let validatedArgs: any[] = [];
            try {
                validatedArgs = templateService.getValidatedArgs({ args: argsPaymentController_testUpdateCredit, request, response });

                const container: IocContainer = typeof iocContainer === 'function' ? (iocContainer as IocContainerFactory)(request) : iocContainer;

                const controller: any = await container.get<PaymentController>(PaymentController);
                if (typeof controller['setStatus'] === 'function') {
                    controller.setStatus(undefined);
                }

                await templateService.apiHandler({
                    methodName: 'testUpdateCredit',
                    controller,
                    response,
                    next,
                    validatedArgs,
                    successStatus: undefined,
                });
            } catch (err) {
                return next(err);
            }
        });
    // WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa
    const argsPalmAnalysisController_savePalmAnalysis: Record<string, TsoaRoute.ParameterSchema> = {
        requestBody: { "in": "body", "name": "requestBody", "required": true, "ref": "PalmAnalysisDto" },
    };
    app.post('/palm-analysis',
        authenticateMiddleware([{ "jwt": [] }]),
        ...(fetchMiddlewares<RequestHandler>(PalmAnalysisController)),
        ...(fetchMiddlewares<RequestHandler>(PalmAnalysisController.prototype.savePalmAnalysis)),

        async function PalmAnalysisController_savePalmAnalysis(request: ExRequest, response: ExResponse, next: any) {

            // WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa

            let validatedArgs: any[] = [];
            try {
                validatedArgs = templateService.getValidatedArgs({ args: argsPalmAnalysisController_savePalmAnalysis, request, response });

                const container: IocContainer = typeof iocContainer === 'function' ? (iocContainer as IocContainerFactory)(request) : iocContainer;

                const controller: any = await container.get<PalmAnalysisController>(PalmAnalysisController);
                if (typeof controller['setStatus'] === 'function') {
                    controller.setStatus(undefined);
                }

                await templateService.apiHandler({
                    methodName: 'savePalmAnalysis',
                    controller,
                    response,
                    next,
                    validatedArgs,
                    successStatus: undefined,
                });
            } catch (err) {
                return next(err);
            }
        });
    // WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa
    const argsPalmAnalysisController_getPalmAnalysisByUser: Record<string, TsoaRoute.ParameterSchema> = {
        userId: { "in": "path", "name": "userId", "required": true, "dataType": "double" },
    };
    app.get('/palm-analysis/user/:userId',
        authenticateMiddleware([{ "jwt": [] }]),
        ...(fetchMiddlewares<RequestHandler>(PalmAnalysisController)),
        ...(fetchMiddlewares<RequestHandler>(PalmAnalysisController.prototype.getPalmAnalysisByUser)),

        async function PalmAnalysisController_getPalmAnalysisByUser(request: ExRequest, response: ExResponse, next: any) {

            // WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa

            let validatedArgs: any[] = [];
            try {
                validatedArgs = templateService.getValidatedArgs({ args: argsPalmAnalysisController_getPalmAnalysisByUser, request, response });

                const container: IocContainer = typeof iocContainer === 'function' ? (iocContainer as IocContainerFactory)(request) : iocContainer;

                const controller: any = await container.get<PalmAnalysisController>(PalmAnalysisController);
                if (typeof controller['setStatus'] === 'function') {
                    controller.setStatus(undefined);
                }

                await templateService.apiHandler({
                    methodName: 'getPalmAnalysisByUser',
                    controller,
                    response,
                    next,
                    validatedArgs,
                    successStatus: undefined,
                });
            } catch (err) {
                return next(err);
            }
        });
    // WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa
    const argsPalmAnalysisController_getAllPalmAnalyses: Record<string, TsoaRoute.ParameterSchema> = {
    };
    app.get('/palm-analysis/all',
        authenticateMiddleware([{ "jwt": ["ADMIN"] }]),
        ...(fetchMiddlewares<RequestHandler>(PalmAnalysisController)),
        ...(fetchMiddlewares<RequestHandler>(PalmAnalysisController.prototype.getAllPalmAnalyses)),

        async function PalmAnalysisController_getAllPalmAnalyses(request: ExRequest, response: ExResponse, next: any) {

            // WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa

            let validatedArgs: any[] = [];
            try {
                validatedArgs = templateService.getValidatedArgs({ args: argsPalmAnalysisController_getAllPalmAnalyses, request, response });

                const container: IocContainer = typeof iocContainer === 'function' ? (iocContainer as IocContainerFactory)(request) : iocContainer;

                const controller: any = await container.get<PalmAnalysisController>(PalmAnalysisController);
                if (typeof controller['setStatus'] === 'function') {
                    controller.setStatus(undefined);
                }

                await templateService.apiHandler({
                    methodName: 'getAllPalmAnalyses',
                    controller,
                    response,
                    next,
                    validatedArgs,
                    successStatus: undefined,
                });
            } catch (err) {
                return next(err);
            }
        });
    // WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa
    const argsPalmAnalysisController_deletePalmAnalysis: Record<string, TsoaRoute.ParameterSchema> = {
        id: { "in": "path", "name": "id", "required": true, "dataType": "double" },
    };
    app.delete('/palm-analysis/:id',
        authenticateMiddleware([{ "jwt": [] }]),
        ...(fetchMiddlewares<RequestHandler>(PalmAnalysisController)),
        ...(fetchMiddlewares<RequestHandler>(PalmAnalysisController.prototype.deletePalmAnalysis)),

        async function PalmAnalysisController_deletePalmAnalysis(request: ExRequest, response: ExResponse, next: any) {

            // WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa

            let validatedArgs: any[] = [];
            try {
                validatedArgs = templateService.getValidatedArgs({ args: argsPalmAnalysisController_deletePalmAnalysis, request, response });

                const container: IocContainer = typeof iocContainer === 'function' ? (iocContainer as IocContainerFactory)(request) : iocContainer;

                const controller: any = await container.get<PalmAnalysisController>(PalmAnalysisController);
                if (typeof controller['setStatus'] === 'function') {
                    controller.setStatus(undefined);
                }

                await templateService.apiHandler({
                    methodName: 'deletePalmAnalysis',
                    controller,
                    response,
                    next,
                    validatedArgs,
                    successStatus: undefined,
                });
            } catch (err) {
                return next(err);
            }
        });
    // WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa
    const argsPalmAnalysisController_updatePalmAnalysis: Record<string, TsoaRoute.ParameterSchema> = {
        id: { "in": "path", "name": "id", "required": true, "dataType": "double" },
        palmAnalysisDto: { "in": "body", "name": "palmAnalysisDto", "required": true, "ref": "PalmAnalysisDto" },
    };
    app.put('/palm-analysis/:id',
        authenticateMiddleware([{ "jwt": [] }]),
        ...(fetchMiddlewares<RequestHandler>(PalmAnalysisController)),
        ...(fetchMiddlewares<RequestHandler>(PalmAnalysisController.prototype.updatePalmAnalysis)),

        async function PalmAnalysisController_updatePalmAnalysis(request: ExRequest, response: ExResponse, next: any) {

            // WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa

            let validatedArgs: any[] = [];
            try {
                validatedArgs = templateService.getValidatedArgs({ args: argsPalmAnalysisController_updatePalmAnalysis, request, response });

                const container: IocContainer = typeof iocContainer === 'function' ? (iocContainer as IocContainerFactory)(request) : iocContainer;

                const controller: any = await container.get<PalmAnalysisController>(PalmAnalysisController);
                if (typeof controller['setStatus'] === 'function') {
                    controller.setStatus(undefined);
                }

                await templateService.apiHandler({
                    methodName: 'updatePalmAnalysis',
                    controller,
                    response,
                    next,
                    validatedArgs,
                    successStatus: undefined,
                });
            } catch (err) {
                return next(err);
            }
        });
    // WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa
    const argsFacialAnalysisController_saveFacialAnalysis: Record<string, TsoaRoute.ParameterSchema> = {
        facialAnalysisDto: { "in": "body", "name": "facialAnalysisDto", "required": true, "ref": "FacialAnalysisDto" },
    };
    app.post('/facial-analysis',
        authenticateMiddleware([{ "jwt": [] }]),
        ...(fetchMiddlewares<RequestHandler>(FacialAnalysisController)),
        ...(fetchMiddlewares<RequestHandler>(FacialAnalysisController.prototype.saveFacialAnalysis)),

        async function FacialAnalysisController_saveFacialAnalysis(request: ExRequest, response: ExResponse, next: any) {

            // WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa

            let validatedArgs: any[] = [];
            try {
                validatedArgs = templateService.getValidatedArgs({ args: argsFacialAnalysisController_saveFacialAnalysis, request, response });

                const container: IocContainer = typeof iocContainer === 'function' ? (iocContainer as IocContainerFactory)(request) : iocContainer;

                const controller: any = await container.get<FacialAnalysisController>(FacialAnalysisController);
                if (typeof controller['setStatus'] === 'function') {
                    controller.setStatus(undefined);
                }

                await templateService.apiHandler({
                    methodName: 'saveFacialAnalysis',
                    controller,
                    response,
                    next,
                    validatedArgs,
                    successStatus: undefined,
                });
            } catch (err) {
                return next(err);
            }
        });
    // WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa
    const argsFacialAnalysisController_getFacialAnalysesByUser: Record<string, TsoaRoute.ParameterSchema> = {
        userId: { "in": "path", "name": "userId", "required": true, "dataType": "double" },
    };
    app.get('/facial-analysis/user/:userId',
        authenticateMiddleware([{ "jwt": [] }]),
        ...(fetchMiddlewares<RequestHandler>(FacialAnalysisController)),
        ...(fetchMiddlewares<RequestHandler>(FacialAnalysisController.prototype.getFacialAnalysesByUser)),

        async function FacialAnalysisController_getFacialAnalysesByUser(request: ExRequest, response: ExResponse, next: any) {

            // WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa

            let validatedArgs: any[] = [];
            try {
                validatedArgs = templateService.getValidatedArgs({ args: argsFacialAnalysisController_getFacialAnalysesByUser, request, response });

                const container: IocContainer = typeof iocContainer === 'function' ? (iocContainer as IocContainerFactory)(request) : iocContainer;

                const controller: any = await container.get<FacialAnalysisController>(FacialAnalysisController);
                if (typeof controller['setStatus'] === 'function') {
                    controller.setStatus(undefined);
                }

                await templateService.apiHandler({
                    methodName: 'getFacialAnalysesByUser',
                    controller,
                    response,
                    next,
                    validatedArgs,
                    successStatus: undefined,
                });
            } catch (err) {
                return next(err);
            }
        });
    // WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa
    const argsFacialAnalysisController_getAllFacialAnalyses: Record<string, TsoaRoute.ParameterSchema> = {
    };
    app.get('/facial-analysis/all',
        authenticateMiddleware([{ "jwt": ["ADMIN"] }]),
        ...(fetchMiddlewares<RequestHandler>(FacialAnalysisController)),
        ...(fetchMiddlewares<RequestHandler>(FacialAnalysisController.prototype.getAllFacialAnalyses)),

        async function FacialAnalysisController_getAllFacialAnalyses(request: ExRequest, response: ExResponse, next: any) {

            // WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa

            let validatedArgs: any[] = [];
            try {
                validatedArgs = templateService.getValidatedArgs({ args: argsFacialAnalysisController_getAllFacialAnalyses, request, response });

                const container: IocContainer = typeof iocContainer === 'function' ? (iocContainer as IocContainerFactory)(request) : iocContainer;

                const controller: any = await container.get<FacialAnalysisController>(FacialAnalysisController);
                if (typeof controller['setStatus'] === 'function') {
                    controller.setStatus(undefined);
                }

                await templateService.apiHandler({
                    methodName: 'getAllFacialAnalyses',
                    controller,
                    response,
                    next,
                    validatedArgs,
                    successStatus: undefined,
                });
            } catch (err) {
                return next(err);
            }
        });
    // WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa
    const argsFacialAnalysisController_deleteFacialAnalysis: Record<string, TsoaRoute.ParameterSchema> = {
        id: { "in": "path", "name": "id", "required": true, "dataType": "double" },
    };
    app.delete('/facial-analysis/:id',
        authenticateMiddleware([{ "jwt": [] }]),
        ...(fetchMiddlewares<RequestHandler>(FacialAnalysisController)),
        ...(fetchMiddlewares<RequestHandler>(FacialAnalysisController.prototype.deleteFacialAnalysis)),

        async function FacialAnalysisController_deleteFacialAnalysis(request: ExRequest, response: ExResponse, next: any) {

            // WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa

            let validatedArgs: any[] = [];
            try {
                validatedArgs = templateService.getValidatedArgs({ args: argsFacialAnalysisController_deleteFacialAnalysis, request, response });

                const container: IocContainer = typeof iocContainer === 'function' ? (iocContainer as IocContainerFactory)(request) : iocContainer;

                const controller: any = await container.get<FacialAnalysisController>(FacialAnalysisController);
                if (typeof controller['setStatus'] === 'function') {
                    controller.setStatus(undefined);
                }

                await templateService.apiHandler({
                    methodName: 'deleteFacialAnalysis',
                    controller,
                    response,
                    next,
                    validatedArgs,
                    successStatus: undefined,
                });
            } catch (err) {
                return next(err);
            }
        });
    // WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa
    const argsFacialAnalysisController_updateFacialAnalysis: Record<string, TsoaRoute.ParameterSchema> = {
        id: { "in": "path", "name": "id", "required": true, "dataType": "double" },
        facialAnalysisDto: { "in": "body", "name": "facialAnalysisDto", "required": true, "ref": "FacialAnalysisDto" },
    };
    app.put('/facial-analysis/:id',
        authenticateMiddleware([{ "jwt": [] }]),
        ...(fetchMiddlewares<RequestHandler>(FacialAnalysisController)),
        ...(fetchMiddlewares<RequestHandler>(FacialAnalysisController.prototype.updateFacialAnalysis)),

        async function FacialAnalysisController_updateFacialAnalysis(request: ExRequest, response: ExResponse, next: any) {

            // WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa

            let validatedArgs: any[] = [];
            try {
                validatedArgs = templateService.getValidatedArgs({ args: argsFacialAnalysisController_updateFacialAnalysis, request, response });

                const container: IocContainer = typeof iocContainer === 'function' ? (iocContainer as IocContainerFactory)(request) : iocContainer;

                const controller: any = await container.get<FacialAnalysisController>(FacialAnalysisController);
                if (typeof controller['setStatus'] === 'function') {
                    controller.setStatus(undefined);
                }

                await templateService.apiHandler({
                    methodName: 'updateFacialAnalysis',
                    controller,
                    response,
                    next,
                    validatedArgs,
                    successStatus: undefined,
                });
            } catch (err) {
                return next(err);
            }
        });
    // WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa
    const argsChatController_sendMessage: Record<string, TsoaRoute.ParameterSchema> = {
        body: { "in": "body", "name": "body", "required": true, "ref": "ChatRequest" },
        request: { "in": "request", "name": "request", "required": true, "dataType": "object" },
    };
    app.post('/api/chat/send',
        authenticateMiddleware([{ "jwt": [] }]),
        ...(fetchMiddlewares<RequestHandler>(ChatController)),
        ...(fetchMiddlewares<RequestHandler>(ChatController.prototype.sendMessage)),

        async function ChatController_sendMessage(request: ExRequest, response: ExResponse, next: any) {

            // WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa

            let validatedArgs: any[] = [];
            try {
                validatedArgs = templateService.getValidatedArgs({ args: argsChatController_sendMessage, request, response });

                const container: IocContainer = typeof iocContainer === 'function' ? (iocContainer as IocContainerFactory)(request) : iocContainer;

                const controller: any = await container.get<ChatController>(ChatController);
                if (typeof controller['setStatus'] === 'function') {
                    controller.setStatus(undefined);
                }

                await templateService.apiHandler({
                    methodName: 'sendMessage',
                    controller,
                    response,
                    next,
                    validatedArgs,
                    successStatus: undefined,
                });
            } catch (err) {
                return next(err);
            }
        });
    // WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa
    const argsAuthController_login: Record<string, TsoaRoute.ParameterSchema> = {
        loginData: { "in": "body", "name": "loginData", "required": true, "ref": "AuthRequest" },
    };
    app.post('/auth/user',
        ...(fetchMiddlewares<RequestHandler>(AuthController)),
        ...(fetchMiddlewares<RequestHandler>(AuthController.prototype.login)),

        async function AuthController_login(request: ExRequest, response: ExResponse, next: any) {

            // WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa

            let validatedArgs: any[] = [];
            try {
                validatedArgs = templateService.getValidatedArgs({ args: argsAuthController_login, request, response });

                const container: IocContainer = typeof iocContainer === 'function' ? (iocContainer as IocContainerFactory)(request) : iocContainer;

                const controller: any = await container.get<AuthController>(AuthController);
                if (typeof controller['setStatus'] === 'function') {
                    controller.setStatus(undefined);
                }

                await templateService.apiHandler({
                    methodName: 'login',
                    controller,
                    response,
                    next,
                    validatedArgs,
                    successStatus: undefined,
                });
            } catch (err) {
                return next(err);
            }
        });
    // WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa
    const argsAuthController_getCurrentLogin: Record<string, TsoaRoute.ParameterSchema> = {
        req: { "in": "request", "name": "req", "required": true, "dataType": "object" },
    };
    app.get('/auth/me',
        authenticateMiddleware([{ "jwt": [] }]),
        ...(fetchMiddlewares<RequestHandler>(AuthController)),
        ...(fetchMiddlewares<RequestHandler>(AuthController.prototype.getCurrentLogin)),

        async function AuthController_getCurrentLogin(request: ExRequest, response: ExResponse, next: any) {

            // WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa

            let validatedArgs: any[] = [];
            try {
                validatedArgs = templateService.getValidatedArgs({ args: argsAuthController_getCurrentLogin, request, response });

                const container: IocContainer = typeof iocContainer === 'function' ? (iocContainer as IocContainerFactory)(request) : iocContainer;

                const controller: any = await container.get<AuthController>(AuthController);
                if (typeof controller['setStatus'] === 'function') {
                    controller.setStatus(undefined);
                }

                await templateService.apiHandler({
                    methodName: 'getCurrentLogin',
                    controller,
                    response,
                    next,
                    validatedArgs,
                    successStatus: undefined,
                });
            } catch (err) {
                return next(err);
            }
        });
    // WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa
    const argsAuthController_changePassword: Record<string, TsoaRoute.ParameterSchema> = {
        req: { "in": "request", "name": "req", "required": true, "dataType": "object" },
        data: { "in": "body", "name": "data", "required": true, "ref": "ChangePasswordDTO" },
    };
    app.post('/auth/me/change-password',
        authenticateMiddleware([{ "jwt": [] }]),
        ...(fetchMiddlewares<RequestHandler>(AuthController)),
        ...(fetchMiddlewares<RequestHandler>(AuthController.prototype.changePassword)),

        async function AuthController_changePassword(request: ExRequest, response: ExResponse, next: any) {

            // WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa

            let validatedArgs: any[] = [];
            try {
                validatedArgs = templateService.getValidatedArgs({ args: argsAuthController_changePassword, request, response });

                const container: IocContainer = typeof iocContainer === 'function' ? (iocContainer as IocContainerFactory)(request) : iocContainer;

                const controller: any = await container.get<AuthController>(AuthController);
                if (typeof controller['setStatus'] === 'function') {
                    controller.setStatus(undefined);
                }

                await templateService.apiHandler({
                    methodName: 'changePassword',
                    controller,
                    response,
                    next,
                    validatedArgs,
                    successStatus: undefined,
                });
            } catch (err) {
                return next(err);
            }
        });
    // WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa
    const argsAuthController_requestForgotPassword: Record<string, TsoaRoute.ParameterSchema> = {
        data: { "in": "body", "name": "data", "required": true, "ref": "RequestResetPassword" },
    };
    app.post('/auth/request-forgot-pass',
        ...(fetchMiddlewares<RequestHandler>(AuthController)),
        ...(fetchMiddlewares<RequestHandler>(AuthController.prototype.requestForgotPassword)),

        async function AuthController_requestForgotPassword(request: ExRequest, response: ExResponse, next: any) {

            // WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa

            let validatedArgs: any[] = [];
            try {
                validatedArgs = templateService.getValidatedArgs({ args: argsAuthController_requestForgotPassword, request, response });

                const container: IocContainer = typeof iocContainer === 'function' ? (iocContainer as IocContainerFactory)(request) : iocContainer;

                const controller: any = await container.get<AuthController>(AuthController);
                if (typeof controller['setStatus'] === 'function') {
                    controller.setStatus(undefined);
                }

                await templateService.apiHandler({
                    methodName: 'requestForgotPassword',
                    controller,
                    response,
                    next,
                    validatedArgs,
                    successStatus: undefined,
                });
            } catch (err) {
                return next(err);
            }
        });
    // WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa
    const argsAuthController_resetPassword: Record<string, TsoaRoute.ParameterSchema> = {
        token: { "in": "query", "name": "token", "required": true, "dataType": "string" },
        data: { "in": "body", "name": "data", "required": true, "ref": "ResetPassword" },
    };
    app.post('/auth/reset-pass',
        ...(fetchMiddlewares<RequestHandler>(AuthController)),
        ...(fetchMiddlewares<RequestHandler>(AuthController.prototype.resetPassword)),

        async function AuthController_resetPassword(request: ExRequest, response: ExResponse, next: any) {

            // WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa

            let validatedArgs: any[] = [];
            try {
                validatedArgs = templateService.getValidatedArgs({ args: argsAuthController_resetPassword, request, response });

                const container: IocContainer = typeof iocContainer === 'function' ? (iocContainer as IocContainerFactory)(request) : iocContainer;

                const controller: any = await container.get<AuthController>(AuthController);
                if (typeof controller['setStatus'] === 'function') {
                    controller.setStatus(undefined);
                }

                await templateService.apiHandler({
                    methodName: 'resetPassword',
                    controller,
                    response,
                    next,
                    validatedArgs,
                    successStatus: undefined,
                });
            } catch (err) {
                return next(err);
            }
        });
    // WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa
    const argsAuthController_refreshToken: Record<string, TsoaRoute.ParameterSchema> = {
        data: { "in": "body", "name": "data", "required": true, "ref": "RefreshTokenRequest" },
    };
    app.post('/auth/refresh-token',
        ...(fetchMiddlewares<RequestHandler>(AuthController)),
        ...(fetchMiddlewares<RequestHandler>(AuthController.prototype.refreshToken)),

        async function AuthController_refreshToken(request: ExRequest, response: ExResponse, next: any) {

            // WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa

            let validatedArgs: any[] = [];
            try {
                validatedArgs = templateService.getValidatedArgs({ args: argsAuthController_refreshToken, request, response });

                const container: IocContainer = typeof iocContainer === 'function' ? (iocContainer as IocContainerFactory)(request) : iocContainer;

                const controller: any = await container.get<AuthController>(AuthController);
                if (typeof controller['setStatus'] === 'function') {
                    controller.setStatus(undefined);
                }

                await templateService.apiHandler({
                    methodName: 'refreshToken',
                    controller,
                    response,
                    next,
                    validatedArgs,
                    successStatus: undefined,
                });
            } catch (err) {
                return next(err);
            }
        });
    // WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa
    const argsAuthController_loginWithGoogleMobile: Record<string, TsoaRoute.ParameterSchema> = {
        body: { "in": "body", "name": "body", "required": true, "dataType": "nestedObjectLiteral", "nestedProperties": { "token": { "dataType": "string", "required": true } } },
    };
    app.post('/auth/google/mobile',
        ...(fetchMiddlewares<RequestHandler>(AuthController)),
        ...(fetchMiddlewares<RequestHandler>(AuthController.prototype.loginWithGoogleMobile)),

        async function AuthController_loginWithGoogleMobile(request: ExRequest, response: ExResponse, next: any) {

            // WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa

            let validatedArgs: any[] = [];
            try {
                validatedArgs = templateService.getValidatedArgs({ args: argsAuthController_loginWithGoogleMobile, request, response });

                const container: IocContainer = typeof iocContainer === 'function' ? (iocContainer as IocContainerFactory)(request) : iocContainer;

                const controller: any = await container.get<AuthController>(AuthController);
                if (typeof controller['setStatus'] === 'function') {
                    controller.setStatus(undefined);
                }

                await templateService.apiHandler({
                    methodName: 'loginWithGoogleMobile',
                    controller,
                    response,
                    next,
                    validatedArgs,
                    successStatus: undefined,
                });
            } catch (err) {
                return next(err);
            }
        });
    // WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa
    const argsAuthController_loginWithGoogleWeb: Record<string, TsoaRoute.ParameterSchema> = {
        body: { "in": "body", "name": "body", "required": true, "dataType": "nestedObjectLiteral", "nestedProperties": { "code": { "dataType": "string", "required": true } } },
    };
    app.post('/auth/google/web',
        ...(fetchMiddlewares<RequestHandler>(AuthController)),
        ...(fetchMiddlewares<RequestHandler>(AuthController.prototype.loginWithGoogleWeb)),

        async function AuthController_loginWithGoogleWeb(request: ExRequest, response: ExResponse, next: any) {

            // WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa

            let validatedArgs: any[] = [];
            try {
                validatedArgs = templateService.getValidatedArgs({ args: argsAuthController_loginWithGoogleWeb, request, response });

                const container: IocContainer = typeof iocContainer === 'function' ? (iocContainer as IocContainerFactory)(request) : iocContainer;

                const controller: any = await container.get<AuthController>(AuthController);
                if (typeof controller['setStatus'] === 'function') {
                    controller.setStatus(undefined);
                }

                await templateService.apiHandler({
                    methodName: 'loginWithGoogleWeb',
                    controller,
                    response,
                    next,
                    validatedArgs,
                    successStatus: undefined,
                });
            } catch (err) {
                return next(err);
            }
        });
    // WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa

    // WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa


    // WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa

    function authenticateMiddleware(security: TsoaRoute.Security[] = []) {
        return async function runAuthenticationMiddleware(request: any, response: any, next: any) {

            // WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa

            // keep track of failed auth attempts so we can hand back the most
            // recent one.  This behavior was previously existing so preserving it
            // here
            const failedAttempts: any[] = [];
            const pushAndRethrow = (error: any) => {
                failedAttempts.push(error);
                throw error;
            };

            const secMethodOrPromises: Promise<any>[] = [];
            for (const secMethod of security) {
                if (Object.keys(secMethod).length > 1) {
                    const secMethodAndPromises: Promise<any>[] = [];

                    for (const name in secMethod) {
                        secMethodAndPromises.push(
                            expressAuthenticationRecasted(request, name, secMethod[name], response)
                                .catch(pushAndRethrow)
                        );
                    }

                    // WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa

                    secMethodOrPromises.push(Promise.all(secMethodAndPromises)
                        .then(users => { return users[0]; }));
                } else {
                    for (const name in secMethod) {
                        secMethodOrPromises.push(
                            expressAuthenticationRecasted(request, name, secMethod[name], response)
                                .catch(pushAndRethrow)
                        );
                    }
                }
            }

            // WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa

            try {
                request['user'] = await Promise.any(secMethodOrPromises);

                // Response was sent in middleware, abort
                if (response.writableEnded) {
                    return;
                }

                next();
            }
            catch (err) {
                // Show most recent error as response
                const error = failedAttempts.pop();
                error.status = error.status || 401;

                // Response was sent in middleware, abort
                if (response.writableEnded) {
                    return;
                }
                next(error);
            }

            // WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa
        }
    }

    // WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa
}

// WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa
