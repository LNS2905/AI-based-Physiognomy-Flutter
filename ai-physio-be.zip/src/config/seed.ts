import { Gender, PrismaClient } from "@prisma/client";
import { PasswordUtil } from "../utils/password/password.util";
import { RoleName } from "../utils/enums/enums";

const prisma = new PrismaClient();

async function main() {
  const roles = Object.values(RoleName);
  for (const role of roles) {
    await prisma.role.upsert({
      where: { roleName: role },
      update: {},
      create: { roleName: role },
    });
  }
  const user = await prisma.user.upsert({
    where: { phone: "0123456789" },
    update: { password: await PasswordUtil.hashPassword("Abc@12345") }, //Reset Master Password in case of forgot
    create: {
      firstName: "Master",
      lastName: "Admin",
      phone: "0123456789",
      age: 20,
      gender: Gender.male,
      email: "master@master.com",
      password: await PasswordUtil.hashPassword("Abc@12345"),
    },
  });

  await prisma.userRole.upsert({
    where: {
      userId_roleId: {
        userId: user.id,
        roleId: (
          await prisma.role.findFirstOrThrow({
            where: { roleName: RoleName.ADMIN.toString().toLowerCase() },
          })
        )?.id,
      },
    },
    update: {},
    create: {
      user: { connect: { id: user.id } },
      role: { connect: { roleName: RoleName.ADMIN.toString().toLowerCase() } },
    },
  });
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
