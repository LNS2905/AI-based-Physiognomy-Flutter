"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function (o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = { enumerable: true, get: function () { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function (o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function (o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function (o, v) {
    o["default"] = v;
});
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function (o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AuthService = void 0;
const inversify_1 = require("inversify");
const user_1 = require("../entities/user");
const password_util_1 = require("../utils/password/password.util");
const error_response_1 = require("../business_objects/error.response");
const auth_util_1 = require("../utils/password/auth.util");
const enums_1 = require("../utils/enums/enums");
const environment_1 = __importDefault(require("../utils/environments/environment"));
const jwt = __importStar(require("jsonwebtoken"));
const google_auth_library_1 = require("google-auth-library");
const prisma_1 = require("../utils/prisma");
const mail_util_1 = require("../utils/mail/mail.util");
const class_transformer_1 = require("class-transformer");
const androidClient = new google_auth_library_1.OAuth2Client(environment_1.default.auth.googleAndroidClientId);
const webClient = new google_auth_library_1.OAuth2Client(environment_1.default.auth.googleWebClientId);
let AuthService = class AuthService {
    constructor(userRepository, userRoleRepository) {
        this.userRepository = userRepository;
        this.userRoleRepository = userRoleRepository;
    }
    async login(loginData) {
        const user = await this.userRepository.getByPhoneOrEmail(loginData.username);
        if (!user || !user.id)
            throw new error_response_1.ErrorResponseV2(enums_1.ErrorCode.INVALID_CREDENTIALS);
        if (user.delFlag)
            throw new error_response_1.ErrorResponseV2(enums_1.ErrorCode.DELETED_USER);
        const isValidPassword = await password_util_1.PasswordUtil.comparePassword(loginData.password, user.password);
        if (!isValidPassword)
            throw new error_response_1.ErrorResponseV2(enums_1.ErrorCode.INVALID_CREDENTIALS);
        const userData = {
            email: user.email,
            roles: await this.userRoleRepository.getAllByUser(user.id),
        };
        return auth_util_1.AuthUtil.generateAuthToken(userData);
    }
    async changePassword(email, data) {
        const user = await this.userRepository.getByEmail(email);
        if (!user || !user.id)
            throw new error_response_1.ErrorResponseV2(enums_1.ErrorCode.NOT_FOUND_USER);
        if (await password_util_1.PasswordUtil.comparePassword(data.oldPassword, user.password)) {
            return (0, class_transformer_1.plainToClass)(user_1.BaseUser, await this.userRepository.update(user.id, {
                password: await password_util_1.PasswordUtil.hashPassword(data.password),
            }), { excludeExtraneousValues: true });
        }
        throw new error_response_1.ErrorResponseV2(enums_1.ErrorCode.INVALID_CREDENTIALS);
    }
    async requestResetPassword(data) {
        const user = await this.userRepository.getByEmail(data.email);
        if (user && user.id) {
            const userData = {
                email: user.email,
                roles: await this.userRoleRepository.getAllByUser(user.id),
            };
            const token = auth_util_1.AuthUtil.generateResetPwdToken(userData);
            await this.userRepository.update(user.id, { resetPwdToken: token });
            mail_util_1.MailUtil.SendMail({
                to: user.email,
                subject: `[AIPhysiognomy] Request Reset Password`,
                text: `${token}`,
            });
        }
    }
    async resetPassword(token, data) {
        try {
            const tokenData = jwt.verify(token, environment_1.default.auth.jwtSecret);
            const user = await this.userRepository.getByEmail(tokenData.email);
            if (user && user.id && user.resetPwdToken == token) {
                user.password = await password_util_1.PasswordUtil.hashPassword(data.password);
                await this.userRepository.update(user.id, {
                    password: user.password,
                    resetPwdToken: "",
                });
                return true;
            }
            throw new error_response_1.ErrorResponseV2(enums_1.ErrorCode.INVALID_REQUEST);
        }
        catch (error) {
            if (error instanceof jwt.TokenExpiredError)
                throw new error_response_1.ErrorResponseV2(enums_1.ErrorCode.EXPIRED_TOKEN);
            throw new error_response_1.ErrorResponseV2(enums_1.ErrorCode.INVALID_REQUEST);
        }
    }
    async refreshToken(refreshData) {
        try {
            const tokenData = jwt.verify(refreshData.refreshToken, environment_1.default.auth.jwtSecret);
            if (tokenData.email && tokenData.type === "refresh") {
                const user = await this.userRepository.getByEmail(tokenData.email);
                if (!user || !user.id)
                    throw new error_response_1.ErrorResponseV2(enums_1.ErrorCode.INVALID_TOKEN_CLAIM);
                const userData = {
                    email: user.email,
                    roles: await this.userRoleRepository.getAllByUser(user.id),
                };
                return auth_util_1.AuthUtil.generateAuthToken(userData);
            }
            throw new error_response_1.ErrorResponseV2(enums_1.ErrorCode.INVALID_TOKEN_TYPE);
        }
        catch (error) {
            if (error instanceof jwt.TokenExpiredError)
                throw new error_response_1.ErrorResponseV2(enums_1.ErrorCode.EXPIRED_TOKEN);
            throw new error_response_1.ErrorResponseV2(enums_1.ErrorCode.INVALID_REQUEST);
        }
    }
    async loginWithGoogleIdToken(idToken) {
        try {
            // Try verifying with Web Client ID first (common for cross-platform apps using serverClientId)
            const ticket = await webClient.verifyIdToken({
                idToken,
                audience: environment_1.default.auth.googleWebClientId,
            });
            const payload = ticket.getPayload();
            if (payload?.email) {
                return this.upsertAndIssue(payload);
            }
        }
        catch (e) {
            // If web client verification fails, try Android client
            try {
                const ticket = await androidClient.verifyIdToken({
                    idToken,
                    audience: environment_1.default.auth.googleAndroidClientId,
                });
                const payload = ticket.getPayload();
                if (payload?.email) {
                    return this.upsertAndIssue(payload);
                }
            }
            catch (e2) {
                throw new error_response_1.ErrorResponseV2(enums_1.ErrorCode.INVALID_GOOGLE_TOKEN);
            }
        }
        throw new error_response_1.ErrorResponseV2(enums_1.ErrorCode.INVALID_GOOGLE_TOKEN);
    }
    async loginWithGoogleCode(code) {
        const res = await fetch("https://oauth2.googleapis.com/token", {
            method: "POST",
            headers: { "Content-Type": "application/x-www-form-urlencoded" },
            body: new URLSearchParams({
                code,
                client_id: environment_1.default.auth.googleWebClientId,
                client_secret: environment_1.default.auth.googleWebClientSecret,
                grant_type: "authorization_code",
                redirect_uri: environment_1.default.auth.googleRedirectUrl || "postmessage",
            }),
        });
        const text = await res.text();
        if (!res.ok)
            throw new error_response_1.ErrorResponseV2(enums_1.ErrorCode.INVALID_REQUEST, `GOOGLE_EXCHANGE_FAILED: ${text}`);
        const tok = JSON.parse(text);
        let payload;
        if (tok.id_token) {
            const ticket = await webClient.verifyIdToken({
                idToken: tok.id_token,
                audience: environment_1.default.auth.googleWebClientId,
            });
            payload = ticket.getPayload();
        }
        if (!payload?.email && tok.access_token) {
            const u = await fetch("https://openidconnect.googleapis.com/v1/userinfo", {
                headers: { Authorization: `Bearer ${tok.access_token}` },
            });
            if (u.ok)
                payload = await u.json();
        }
        if (!payload?.email)
            throw new error_response_1.ErrorResponseV2(enums_1.ErrorCode.INVALID_GOOGLE_TOKEN);
        return this.upsertAndIssue(payload);
    }
    async loginWithGoogle(tokenOrCode) {
        const looksLikeJwt = tokenOrCode.split(".").length === 3;
        if (looksLikeJwt)
            return this.loginWithGoogleIdToken(tokenOrCode);
        return this.loginWithGoogleCode(tokenOrCode);
    }
    async upsertAndIssue(payload) {
        const googleId = payload.sub;
        const email = payload.email;
        const firstName = payload.given_name || "";
        const lastName = payload.family_name || "";
        const avatar = payload.picture || null;
        let user = await this.userRepository.getByGoogleId(googleId);
        if (!user) {
            user = await this.userRepository.getByEmail(email);
            if (user) {
                user = (await prisma_1.prismaManager.withConnection(async (client) => client.user.update({
                    where: { id: user.id },
                    data: {
                        googleId,
                        resetPwdToken: user?.resetPwdToken || undefined,
                    },
                })));
            }
            else {
                user = await this.userRepository.createGoogleUser({
                    email,
                    firstName,
                    lastName,
                    phone: null,
                    age: null,
                    gender: null,
                    avatar,
                    googleId,
                });
            }
        }
        if (!user)
            throw new error_response_1.ErrorResponseV2(enums_1.ErrorCode.NOT_FOUND_USER);
        const roles = await this.userRoleRepository.getAllByUser(user.id);
        const userData = { email: user.email, roles };
        return auth_util_1.AuthUtil.generateAuthToken(userData);
    }
};
exports.AuthService = AuthService;
exports.AuthService = AuthService = __decorate([
    (0, inversify_1.injectable)(),
    __param(0, (0, inversify_1.inject)("IUserRepository")),
    __param(1, (0, inversify_1.inject)("IUserRoleRepository")),
    __metadata("design:paramtypes", [Object, Object])
], AuthService);
//# sourceMappingURL=auth.service.js.map
