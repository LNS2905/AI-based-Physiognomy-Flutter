# Payment Flow Issues - Analysis Report

## 🔍 Current Status

### Mobile App (Flutter)
**Location**: `lib/features/payment/data/services/payment_api_service.dart`

**Endpoints Being Called**:
1. `GET /credit-packages` - Get list of credit packages
2. `POST /users/me/recharge` - Create Stripe checkout session
3. `GET /users/me` - Get current user credits

### Backend (Node.js)
**Payment Controller**: `src/controllers/payment.controller.ts`
- ✅ `GET /payment/success` - Handle Stripe success redirect
- ✅ `GET /payment/cancel` - Handle Stripe cancel redirect
- ✅ `POST /payment/test-update-credit` - Test credit update

**User Controller**: `src/controllers/user.controller.ts`
- ✅ `POST /users/me/recharge` - Create recharge session (EXISTS)

**Database Schema**: `prisma/schema.prisma`
- ✅ `CreditPackage` model exists with fields:
  - id, name, credits, bonusCredits
  - priceUsd, priceVnd, stripePriceId
  - isActive, displayOrder

## ❌ CRITICAL ISSUES

### Issue #1: Missing Credit Packages API Endpoint
**Problem**: Mobile app calls `GET /credit-packages` but backend has NO controller for this.

**Impact**: 
- Users cannot see available credit packages
- Payment flow cannot start

**Solution Needed**: Create `CreditPackageController` with:
```typescript
@Get("/")
public async getAllCreditPackages(): Promise<GeneralResponse> {
  // Return all active credit packages ordered by displayOrder
}
```

### Issue #2: Deep Link Configuration
**Problem**: Payment success/cancel redirects use deep links:
- `physioapp://payment-success?credits={credits}`
- `physioapp://payment-cancel`
- `physioapp://payment-failed`

**Status**: Need to verify if these deep links are configured in:
- `android/app/src/main/AndroidManifest.xml`
- Flutter route handling

### Issue #3: Stripe Configuration
**Problem**: Need to verify Stripe keys are configured:
- `STRIPE_PUBLISHABLE_KEY`
- `STRIPE_SECRET_KEY`
- `STRIPE_BASE_URL_LOCAL` / `STRIPE_BASE_URL_PRODUCTION`

**Check**: `src/utils/environments/environment.ts`

### Issue #4: Credit Deduction for Chat
**Problem**: Need to verify chat service deducts credits when user sends messages.

**Check**: Chat controller/service implementation

## 📋 Payment Flow (Expected)

```
1. User opens Payment Packages Page
   ↓
2. App calls GET /credit-packages
   ↓
3. Display packages to user
   ↓
4. User selects package
   ↓
5. App calls POST /users/me/recharge
   ↓
6. Backend creates Stripe Checkout Session
   ↓
7. App opens Stripe checkout URL in browser
   ↓
8. User completes payment on Stripe
   ↓
9. Stripe redirects to /payment/success?session_id=xxx&userId=yyy
   ↓
10. Backend updates user credits
    ↓
11. Backend redirects to physioapp://payment-success?credits=zzz
    ↓
12. App handles deep link and shows success
```

## 🔧 Required Fixes

### Priority 1: Create Credit Package Controller
File: `src/controllers/creditPackage.controller.ts`

```typescript
import { controller, httpGet } from "inversify-express-utils";
import { inject } from "inversify";
import { Route, Get, Tags, Controller } from "tsoa";
import { GeneralResponse } from "../business_objects/general.response";
import { SuccessCode } from "../utils/enums/enums";
import { prismaManager } from "../utils/prisma";

@Route("/credit-packages")
@Tags("Credit Packages")
@controller("/credit-packages")
export class CreditPackageController extends Controller {
  
  @Get("/")
  @httpGet("/")
  public async getAllCreditPackages(): Promise<GeneralResponse> {
    const packages = await prismaManager.withConnection(async (client) =>
      client.creditPackage.findMany({
        where: { isActive: true },
        orderBy: { displayOrder: 'asc' },
      })
    );
    
    return new GeneralResponse(SuccessCode.OPERATION_SUCCESS, packages);
  }
}
```

### Priority 2: Configure Deep Links
File: `android/app/src/main/AndroidManifest.xml`

Add intent filter for payment deep links:
```xml
<intent-filter>
    <action android:name="android.intent.action.VIEW" />
    <category android:name="android.intent.category.DEFAULT" />
    <category android:name="android.intent.category.BROWSABLE" />
    <data android:scheme="physioapp" android:host="payment-success" />
    <data android:scheme="physioapp" android:host="payment-cancel" />
    <data android:scheme="physioapp" android:host="payment-failed" />
</intent-filter>
```

### Priority 3: Verify Stripe Keys
Check `.env` file on VPS or local environment variables.

### Priority 4: Test Credit Deduction
Verify chat service deducts credits per message.

## 📊 Database Seed Data

From `comprehensive_seed_v2.js`, credit packages should exist:
- Starter: 50 credits, $2
- Basic: 125 credits (100+25 bonus), $5
- Popular: 275 credits (200+75 bonus), $10
- Premium: 625 credits (500+125 bonus), $20

## 🧪 Testing Steps

1. **Test Credit Packages API**:
   ```bash
   curl http://160.250.180.132:3000/credit-packages
   ```

2. **Test Recharge Session Creation**:
   ```bash
   curl -X POST http://160.250.180.132:3000/users/me/recharge \
     -H "Authorization: Bearer {token}" \
     -H "Content-Type: application/json" \
     -d '{...}'
   ```

3. **Test Deep Link Handling**:
   ```bash
   adb shell am start -W -a android.intent.action.VIEW \
     -d "physioapp://payment-success?credits=100"
   ```

## 🎯 Next Steps

1. Create `CreditPackageController`
2. Deploy to VPS
3. Configure deep links in AndroidManifest
4. Test end-to-end payment flow
5. Verify credit deduction in chat

Date: 2025-11-20
Time: 22:00 (GMT+7)
