-- Verify CreditPackage
SELECT * FROM "CreditPackage";

-- Verify User credits column  
SELECT id, email, credits FROM "user" LIMIT 5;
