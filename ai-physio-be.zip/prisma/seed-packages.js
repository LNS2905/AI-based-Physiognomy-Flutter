"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const client_1 = require("@prisma/client");
const prisma = new client_1.PrismaClient();
async function main() {
    console.log('🌱 Seeding credit packages...');
    const packages = [
        {
            name: 'Starter',
            credits: 50,
            bonusCredits: 0,
            priceUsd: 2,
            priceVnd: 50000,
            displayOrder: 1,
        },
        {
            name: 'Basic',
            credits: 125,
            bonusCredits: 25,
            priceUsd: 5,
            priceVnd: 125000,
            displayOrder: 2,
        },
        {
            name: 'Popular',
            credits: 275,
            bonusCredits: 75,
            priceUsd: 10,
            priceVnd: 250000,
            displayOrder: 3,
        },
        {
            name: 'Premium',
            credits: 625,
            bonusCredits: 125,
            priceUsd: 20,
            priceVnd: 500000,
            displayOrder: 4,
        },
    ];
    for (const pkg of packages) {
        await prisma.creditPackage.upsert({
            where: { name: pkg.name },
            update: pkg,
            create: pkg,
        });
        console.log(`✅ Created/Updated package: ${pkg.name} (${pkg.credits + pkg.bonusCredits} credits)`);
    }
    console.log('✅ Seed completed!');
}
main()
    .catch((e) => {
    console.error('❌ Seed failed:', e);
    process.exit(1);
})
    .finally(async () => {
    await prisma.$disconnect();
});
//# sourceMappingURL=seed-packages.js.map