import "dotenv/config";
import { PrismaClient } from "@prisma/client";

const prisma = new PrismaClient();

async function main() {
    console.log("Start seeding credit packages...");

    // 1. Deactivate or Delete existing packages
    // We'll deactivate them to keep history if needed, or just delete if they are not referenced.
    // For simplicity and cleanliness in this task, let's delete existing active packages 
    // or mark them inactive if you prefer. Let's mark them inactive.
    await prisma.creditPackage.updateMany({
        where: { isActive: true },
        data: { isActive: false },
    });

    console.log("Deactivated old packages.");

    // 2. Create new Top-up Packages
    // $1 -> 10 Credits
    // $5 -> 50 Credits
    // $10 -> 100 Credits
    // $20 -> 200 Credits
    // $50 -> 500 Credits
    // $100 -> 1000 Credits

    const newPackages = [
        {
            name: "Top Up $1",
            credits: 10,
            bonusCredits: 0,
            priceUsd: 1.0,
            priceVnd: 25000.0, // Approx
            isActive: true,
            displayOrder: 1,
        },
        {
            name: "Top Up $5",
            credits: 50,
            bonusCredits: 0, // No bonus for now as per request "nạp bao nhiêu usd thì quy ra bấy nhiêu credit"
            priceUsd: 5.0,
            priceVnd: 125000.0,
            isActive: true,
            displayOrder: 2,
        },
        {
            name: "Top Up $10",
            credits: 100,
            bonusCredits: 0,
            priceUsd: 10.0,
            priceVnd: 250000.0,
            isActive: true,
            displayOrder: 3,
        },
        {
            name: "Top Up $20",
            credits: 200,
            bonusCredits: 0,
            priceUsd: 20.0,
            priceVnd: 500000.0,
            isActive: true,
            displayOrder: 4,
        },
        {
            name: "Top Up $50",
            credits: 500,
            bonusCredits: 0,
            priceUsd: 50.0,
            priceVnd: 1250000.0,
            isActive: true,
            displayOrder: 5,
        },
        {
            name: "Top Up $100",
            credits: 1000,
            bonusCredits: 0,
            priceUsd: 100.0,
            priceVnd: 2500000.0,
            isActive: true,
            displayOrder: 6,
        },
    ];

    for (const pkg of newPackages) {
        await prisma.creditPackage.create({
            data: pkg,
        });
    }

    console.log(`Created ${newPackages.length} new packages.`);
}

main()
    .catch((e) => {
        console.error(e);
        process.exit(1);
    })
    .finally(async () => {
        await prisma.$disconnect();
    });
