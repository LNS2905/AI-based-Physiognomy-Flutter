# ✅ TUVI CHAT SCHEMA - COMPLETE

## 📊 STATUS: FULLY IMPLEMENTED IN AI-PHYSIO-BE

**Date:** 2025-11-07  
**Backend:** ai-physio-be (Node.js + Prisma + PostgreSQL)  
**Purpose:** Database schema for AI Tuvi chatbot integration

---

## ✅ SCHEMA IMPLEMENTATION

### **1. Prisma Schema Updated** ✅

File: `prisma/schema.prisma`

**Added/Updated:**
- ✅ **TuviChart** model - Extended with chat system fields
- ✅ **TuviConversation** model - NEW
- ✅ **TuviMessage** model - NEW
- ✅ **MessageRole** enum - NEW (user/assistant/system)
- ✅ **MessageType** enum - NEW (initial_analysis/question/daily_fortune/clarification_request/tool_result)
- ✅ **User relations** - Added tuviCharts, tuviConversations

### **2. Database Tables Created** ✅

```sql
TuviChart          - ✅ UPDATED (added chartData field)
TuviConversation   - ✅ EXISTS
TuviMessage        - ✅ EXISTS
```

---

## 📋 SCHEMA DETAILS

### **TuviChart Model**

```prisma
model TuviChart {
  id     Int  @id @default(autoincrement())
  userId Int
  user   user @relation(fields: [userId], references: [id], onDelete: Cascade)

  // Data storage (2 options for compatibility)
  payload   Json? // Legacy: Request input
  houses    Json? // Legacy: 12 houses
  extra     Json? // Legacy: Additional info
  chartData Json? // NEW: Full response: {houses, extra, request, ...}

  // Tuvi Chat System fields
  ownerName      String   // "Bản thân", "Con trai", "Vợ"...
  birthDate      DateTime // Dương lịch đầy đủ
  birthHour      Int      // 1-12 (Chi giờ)
  gender         Gender
  solarBirthDate DateTime // Dương lịch
  lunarBirthDate String?  // Âm lịch (nếu có)
  birthPlace     String?  // Nơi sinh
  timezone       String?  // Múi giờ
  isPrimary      Boolean  @default(false) // Lá số chính

  createdAt DateTime @default(now())
  updatedAt DateTime @updatedAt
  delFlag   Boolean  @default(false)

  // Relations
  conversations TuviConversation[]

  @@index([userId])
  @@index([createdAt])
  @@index([userId, isPrimary])
  @@index([userId, delFlag])
}
```

### **TuviConversation Model**

```prisma
model TuviConversation {
  id     Int @id @default(autoincrement())
  userId Int
  user   user @relation(fields: [userId], references: [id], onDelete: Cascade)

  chartId Int
  chart   TuviChart @relation(fields: [chartId], references: [id], onDelete: Cascade)

  title String? // "Sự nghiệp 2025", "Tình duyên"...

  // Agent State - Trạng thái conversation
  agentState Json? // {
  //   "missingInfo": ["birthPlace"],
  //   "collectedInfo": {"birthPlace": "Hanoi"},
  //   "currentStep": "collecting_info"
  // }

  hasInitialAnalysis Boolean @default(false)

  createAt DateTime @default(now())
  updateAt DateTime @updatedAt
  delFlag  Boolean  @default(false)

  // Relations
  messages TuviMessage[]

  @@index([userId, delFlag])
  @@index([chartId])
  @@index([updateAt])
}
```

### **TuviMessage Model**

```prisma
model TuviMessage {
  id             Int              @id @default(autoincrement())
  conversationId Int
  conversation   TuviConversation @relation(fields: [conversationId], references: [id], onDelete: Cascade)

  role    MessageRole
  content String      @db.Text

  // Agent metadata
  messageType    MessageType?
  toolCalls      Json? // [{"tool": "chinese_daily", "params": {...}, "result": {...}}]
  contextDate    DateTime?

  // Sources (RAG + API)
  sources Json? // {"books": [...], "chineseAPI": {...}}

  processingTime Float? // milliseconds

  createAt DateTime @default(now())

  @@index([conversationId, createAt])
}
```

### **Enums**

```prisma
enum MessageRole {
  user
  assistant
  system
}

enum MessageType {
  initial_analysis      // Phân tích ban đầu
  question              // Câu hỏi thường
  daily_fortune         // Hỏi về "hôm nay"
  clarification_request // Agent hỏi lại
  tool_result           // Kết quả tool
}
```

---

## 🔄 DATA COMPATIBILITY

### **TuviChart Storage Options:**

**Option 1: Legacy format (lasotuvi backend)**
```json
{
  "payload": {...},  // Request input
  "houses": [...],   // 12 houses
  "extra": {...}     // Additional info
}
```

**Option 2: New format (chatbot)**
```json
{
  "chartData": {     // All-in-one
    "request": {...},
    "houses": [...],
    "extra": {...}
  }
}
```

Both formats supported! Choose based on your use case.

---

## 🎯 USAGE EXAMPLES

### **1. Create TuviChart**

```typescript
import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

// Create chart
const chart = await prisma.tuviChart.create({
  data: {
    userId: 1,
    ownerName: "Bản thân",
    birthDate: new Date("1990-03-15"),
    birthHour: 5,
    gender: "male",
    solarBirthDate: new Date("1990-03-15"),
    isPrimary: true,
    
    // Option 1: Legacy format
    payload: { day: 15, month: 3, year: 1990 },
    houses: [...],
    extra: {...},
    
    // Option 2: New format
    chartData: {
      request: { day: 15, month: 3, year: 1990 },
      houses: [...],
      extra: {...}
    }
  }
});
```

### **2. Create Conversation**

```typescript
const conversation = await prisma.tuviConversation.create({
  data: {
    userId: 1,
    chartId: chart.id,
    title: "Sự nghiệp 2025",
    hasInitialAnalysis: false,
    agentState: {
      currentStep: "initial",
      missingInfo: []
    }
  }
});
```

### **3. Add Messages**

```typescript
// User question
await prisma.tuviMessage.create({
  data: {
    conversationId: conversation.id,
    role: "user",
    content: "Công việc của tôi năm 2025 như thế nào?"
  }
});

// AI response
await prisma.tuviMessage.create({
  data: {
    conversationId: conversation.id,
    role: "assistant",
    content: "Dựa trên lá số của bạn...",
    messageType: "question",
    sources: {
      books: ["Tử vi đẩu số toàn thư"],
      chineseAPI: {...}
    },
    processingTime: 1234.56
  }
});
```

### **4. Get Conversation with Messages**

```typescript
const conv = await prisma.tuviConversation.findUnique({
  where: { id: conversationId },
  include: {
    chart: true,
    messages: {
      orderBy: { createAt: 'asc' }
    }
  }
});
```

---

## 🔗 INTEGRATION WITH LASOTUVI

### **Shared Database Architecture:**

```
┌─────────────────────────────────────┐
│    PostgreSQL (physio_db)          │
│    localhost:5432                   │
└──────────┬──────────────────────────┘
           │
    ┌──────┴────────┐
    │               │
┌───▼────┐    ┌────▼─────┐
│ai-physio│    │ lasotuvi │
│(Prisma) │    │(SQLAlchemy)│
└─────────┘    └──────────┘
```

**Both backends can:**
- ✅ Read/Write TuviChart
- ✅ Read/Write TuviConversation
- ✅ Read/Write TuviMessage

**lasotuvi (SQLAlchemy) models** already defined in:
- `lasotuvi/api/database_pg.py`
- Compatible with Prisma schema

---

## 🚀 NEXT STEPS FOR AI CHATBOT DEV

### **Backend API Endpoints to Create:**

```typescript
POST   /tuvi/conversations           - Create new conversation
GET    /tuvi/conversations/:id       - Get conversation with messages
POST   /tuvi/conversations/:id/messages - Add message
GET    /tuvi/conversations?userId=X - List user conversations
PUT    /tuvi/conversations/:id/state - Update agent state
GET    /tuvi/charts/:userId          - Get user's charts
POST   /tuvi/charts                  - Create new chart
```

### **Integration Flow:**

```
1. User opens chatbot
   → GET /tuvi/charts?userId=X&isPrimary=true
   → Get primary TuviChart

2. Start new conversation
   → POST /tuvi/conversations { userId, chartId, title }

3. User sends message
   → POST /tuvi/conversations/:id/messages
   → Call AI agent (RAG + Chinese API)
   → Save AI response

4. Continue conversation
   → GET /tuvi/conversations/:id
   → Return full conversation history
```

---

## 📝 DATABASE VERIFICATION

### **Check tables exist:**

```bash
docker exec physio_postgres_local psql -U physio_db -d physio_db -c "\dt"
```

Expected output:
```
TuviChart
TuviConversation
TuviMessage
```

### **Check enums:**

```bash
docker exec physio_postgres_local psql -U physio_db -d physio_db -c "SELECT enum_range(NULL::\"MessageRole\")"
```

Expected: `{user,assistant,system}`

---

## ✅ COMPLETION CHECKLIST

- [x] Prisma schema updated with TuviChart, TuviConversation, TuviMessage
- [x] MessageRole and MessageType enums added
- [x] User model relations updated
- [x] Database tables verified (TuviChart, TuviConversation, TuviMessage)
- [x] chartData field added to TuviChart
- [x] Enums created in database
- [x] Documentation created

---

## 🎉 SCHEMA COMPLETE!

**Status:** ✅ **READY FOR AI CHATBOT INTEGRATION**

**AI chatbot dev team can now:**
1. Build conversation API endpoints
2. Implement RAG system with Tuvi books
3. Integrate Chinese API for daily fortune
4. Connect mobile app to chatbot backend

---

**Last Updated:** 2025-11-07  
**Version:** 1.0  
**Database:** physio_db @ localhost:5432
