"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.UserService = void 0;
const inversify_1 = require("inversify");
const user_1 = require("../entities/user");
const password_util_1 = require("../utils/password/password.util");
const class_transformer_1 = require("class-transformer");
const error_response_1 = require("../business_objects/error.response");
const pagination_1 = require("../business_objects/pagination");
const enums_1 = require("../utils/enums/enums");
const class_validator_1 = require("class-validator");
const stripe_1 = require("../utils/payment/stripe");
const transaction_1 = require("../entities/transaction");
let UserService = class UserService {
    constructor(userRepository, userRoleRepository, transactionRepository) {
        this.userRepository = userRepository;
        this.userRoleRepository = userRoleRepository;
        this.transactionRepository = transactionRepository;
    }
    async createUser(userData) {
        delete userData.confirmPassword;
        const user = (0, class_transformer_1.plainToClass)(user_1.User, userData, {
            excludeExtraneousValues: true,
        });
        const username = userData.username ?? "";
        if ((0, class_validator_1.isEmail)(username)) {
            user.email = username;
        }
        else if ((0, class_validator_1.isPhoneNumber)(username)) {
            user.phone = username;
        }
        else {
            throw new error_response_1.ErrorResponseV2(enums_1.ErrorCode.INVALID_USERNAME);
        }
        user.password = await password_util_1.PasswordUtil.hashPassword(user.password);
        try {
            const created = await this.userRepository.create(user);
            if (!created || !created.id) {
                throw new error_response_1.ErrorResponseV2(enums_1.ErrorCode.NOT_FOUND_USER);
            }
            await this.userRoleRepository.createUserRole(created.id, [enums_1.RoleName.USER]);
            return (0, class_transformer_1.plainToClass)(user_1.BaseUser, created, { excludeExtraneousValues: true });
        } catch (error) {
            if (error.code === 'P2002') {
                throw new error_response_1.ErrorResponseV2(enums_1.ErrorCode.DUPLICATE_USER);
            }
            throw error;
        }
    }
    async createSpecialUser(userData, roleName) {
        delete userData.confirmPassword;
        const user = (0, class_transformer_1.plainToClass)(user_1.User, userData, {
            excludeExtraneousValues: true,
        });
        const username = userData.username ?? "";
        if ((0, class_validator_1.isEmail)(username)) {
            user.email = username;
        }
        else if ((0, class_validator_1.isPhoneNumber)(username)) {
            user.phone = username;
        }
        else {
            throw new error_response_1.ErrorResponseV2(enums_1.ErrorCode.INVALID_USERNAME);
        }
        user.password = await password_util_1.PasswordUtil.hashPassword(user.password);
        try {
            const created = await this.userRepository.create(user);
            if (!created || !created.id) {
                throw new error_response_1.ErrorResponseV2(enums_1.ErrorCode.NOT_FOUND_USER);
            }
            await this.userRoleRepository.createUserRole(created.id, roleName);
            return (0, class_transformer_1.plainToClass)(user_1.BaseUser, created, { excludeExtraneousValues: true });
        } catch (error) {
            if (error.code === 'P2002') {
                throw new error_response_1.ErrorResponseV2(enums_1.ErrorCode.DUPLICATE_USER);
            }
            throw error;
        }
    }
    async getUser(id) {
        return (0, class_transformer_1.plainToClass)(user_1.BaseUser, await this.userRepository.getById(id), {
            excludeExtraneousValues: true,
        });
    }
    async getUserByEmail(email) {
        return (0, class_transformer_1.plainToClass)(user_1.BaseUser, await this.userRepository.getByEmail(email), {
            excludeExtraneousValues: true,
        });
    }
    async getAllUser(para) {
        const source = await this.userRepository.getAll(para);
        const items = (0, class_transformer_1.plainToInstance)(user_1.BaseUser, source.items, {
            excludeExtraneousValues: true,
        });
        return new pagination_1.Pagination(items, source.totalCount, source.currentPage, source.pageSize);
    }
    async updateUsers(id, newData) {
        var user = await this.userRepository.getById(id);
        if (!user) {
            throw new error_response_1.ErrorResponseV2(enums_1.ErrorCode.NOT_FOUND_USER);
        }
        return (0, class_transformer_1.plainToClass)(user_1.BaseUser, await this.userRepository.update(id, newData), { excludeExtraneousValues: true });
    }
    async updateCurrentUsers(email, newData) {
        var user = await this.userRepository.getByEmail(email);
        if (!user || !user.id) {
            throw new error_response_1.ErrorResponseV2(enums_1.ErrorCode.NOT_FOUND_USER);
        }
        return (0, class_transformer_1.plainToClass)(user_1.BaseUser, await this.userRepository.update(user.id, newData), { excludeExtraneousValues: true });
    }
    async deleteUsers(id) {
        return (0, class_transformer_1.plainToClass)(user_1.BaseUser, await this.userRepository.delete(id), {
            excludeExtraneousValues: true,
        });
    }
    /**
     * Create Stripe Checkout Session for user recharge
     * @param data - Payment session request
     * @param email - User email (from JWT)
     * @returns Stripe Checkout Session
     */
    async recharge(data, email) {
        const user = await this.userRepository.getByEmail(email);
        if (!user || !user.id) {
            throw new error_response_1.ErrorResponseV2(enums_1.ErrorCode.NOT_FOUND_USER);
        }
        return stripe_1.StripeUtil.requestSessionPayment(data, user.id);
    }
    /**
     * Update user credits after successful payment
     * @param sessionId - Stripe session ID
     * @param userId - User ID
     * @returns Updated user object
     */
    async updateCredit(sessionId, userId) {
        // 1. Retrieve payment info from Stripe
        const paymentInfo = await stripe_1.StripeUtil.responseSessionPayment(sessionId);
        if (!paymentInfo || !paymentInfo.amount_total) {
            throw new error_response_1.ErrorResponseV2(enums_1.ErrorCode.STRIPE_PAYMENT_INCOMPLETE);
        }
        // 2. Get user from database
        const user = await this.userRepository.getById(userId);
        if (!user || !user.id) {
            throw new error_response_1.ErrorResponseV2(enums_1.ErrorCode.STRIPE_PAYMENT_INCOMPLETE);
        }
        // 3. Check if transaction already processed (idempotency)
        const existingTransaction = await this.transactionRepository.getByStripeId(paymentInfo.id);
        if (existingTransaction) {
            throw new error_response_1.ErrorResponseV2(enums_1.ErrorCode.STRIPE_PAYMENT_COMPLETE);
        }
        // 4. Initialize credits if null
        if (!user.credits) {
            user.credits = 0;
        }
        // 5. Convert from cents to credits
        // Formula: $1 USD = 25 credits
        // Example: 500 cents = $5 = 125 credits
        const creditAmount = Math.floor((paymentInfo.amount_total / 100) * 25);
        user.credits += creditAmount;
        // 6. Create transaction record (IN type)
        await this.transactionRepository.create({
            transactionType: transaction_1.TransactionType.IN.toString(),
            transactionStatus: true,
            creditAmount: creditAmount,
            description: `Top-up via Stripe: $${paymentInfo.amount_total / 100}`,
            stripePaymentId: paymentInfo.id,
            userId: user.id,
        });
        // 7. Update user credits in database
        return (0, class_transformer_1.plainToClass)(user_1.BaseUser, await this.userRepository.update(user.id, { credits: user.credits }), { excludeExtraneousValues: true });
    }
};
exports.UserService = UserService;
exports.UserService = UserService = __decorate([
    (0, inversify_1.injectable)(),
    __param(0, (0, inversify_1.inject)("IUserRepository")),
    __param(1, (0, inversify_1.inject)("IUserRoleRepository")),
    __param(2, (0, inversify_1.inject)("ITransactionRepository")),
    __metadata("design:paramtypes", [Object, Object, Object])
], UserService);
//# sourceMappingURL=user.service.js.map