"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CreditPackageController = void 0;
const tsoa_1 = require("tsoa");
const inversify_express_utils_1 = require("inversify-express-utils");
const prisma_1 = require("../utils/prisma"); // Import prismaManager
const inversify_1 = require("inversify");

let CreditPackageController = class CreditPackageController extends tsoa_1.Controller {
    async getAllCreditPackages() {
        try {
            // Use prismaManager.withConnection to ensure a valid connection
            return await prisma_1.prismaManager.withConnection(async (client) => {
                const packages = await client.creditPackage.findMany({
                    where: {
                        isActive: true
                    },
                    orderBy: {
                        priceUsd: 'asc'
                    }
                });
                return {
                    data: packages,
                    code: "OPERATION_SUCCESS",
                    message: "Successfully retrieved credit packages"
                };
            });
        }
        catch (error) {
            console.error("Error fetching credit packages:", error);
            this.setStatus(500);
            return {
                data: null,
                code: "INTERNAL_SERVER_ERROR",
                message: "Failed to retrieve credit packages"
            };
        }
    }
};
__decorate([
    (0, tsoa_1.Get)("/"),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], CreditPackageController.prototype, "getAllCreditPackages", null);
CreditPackageController = __decorate([
    (0, tsoa_1.Route)("credit-packages"),
    (0, inversify_express_utils_1.controller)("credit-packages")
], CreditPackageController);
exports.CreditPackageController = CreditPackageController;
