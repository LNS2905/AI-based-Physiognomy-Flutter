-- ============================================
-- UPDATE TUVICHART FOR CHAT SYSTEM
-- ============================================
-- Cập nhật TuviChart table để match với schema mới

-- 1. Make existing fields nullable (for compatibility)
ALTER TABLE "TuviChart" 
  ALTER COLUMN "payload" DROP NOT NULL,
  ALTER COLUMN "houses" DROP NOT NULL,
  ALTER COLUMN "extra" DROP NOT NULL;

-- 2. Add chartData field (alternative storage format)
ALTER TABLE "TuviChart" 
  ADD COLUMN IF NOT EXISTS "chartData" JSONB;

-- 3. Make chat system fields NOT NULL (as per schema requirement)
-- NOTE: Chỉ run nếu TuviChart table KHÔNG có data, hoặc đã có default values

-- ALTER TABLE "TuviChart" 
--   ALTER COLUMN "ownerName" SET NOT NULL,
--   ALTER COLUMN "birthDate" SET NOT NULL,
--   ALTER COLUMN "birthHour" SET NOT NULL,
--   ALTER COLUMN "gender" SET NOT NULL,
--   ALTER COLUMN "solarBirthDate" SET NOT NULL;

-- 4. Rename timestamp columns to match schema
-- createdAt -> createAt, updatedAt -> updateAt
-- WARNING: Prisma sẽ tự động handle việc này qua migration

-- 5. Check if TuviConversation and TuviMessage already exist
SELECT 
  CASE 
    WHEN EXISTS (SELECT FROM information_schema.tables WHERE table_name = 'TuviConversation') 
    THEN 'TuviConversation EXISTS ✅'
    ELSE 'TuviConversation NOT FOUND ❌'
  END as conversation_status,
  CASE 
    WHEN EXISTS (SELECT FROM information_schema.tables WHERE table_name = 'TuviMessage') 
    THEN 'TuviMessage EXISTS ✅'
    ELSE 'TuviMessage NOT FOUND ❌'
  END as message_status;

-- Done!
SELECT 'TuviChart updated for chat system!' AS status;
