import paramiko

hostname = "160.250.180.132"
username = "root"
password = "Do@nhkiet262205"

def execute_ssh_command(command):
    try:
        client = paramiko.SSHClient()
        client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        client.connect(hostname, username=username, password=password)
        
        print(f"--- Executing: {command} ---")
        stdin, stdout, stderr = client.exec_command(command)
        
        output = stdout.read().decode().strip()
        error = stderr.read().decode().strip()
        
        if output:
            print(output)
        if error:
            print(f"Error/Stderr: {error}")
            
        client.close()
    except Exception as e:
        print(f"Connection failed: {e}")

if __name__ == "__main__":
    print("Creating nodejs stripe test script inside container with NEW KEY...")
    
    js_script = """
const Stripe = require('stripe');
const stripe = new Stripe('sk_test_51SR6hxPofBTvOXyOkCNZzLSks11IrUpP03ymouaCI6QC4I91lZKSmOpn02OUUdKkQmYVkZYXK7iVG9G0kEd3wCz200TqIrV4Wa', {
    apiVersion: '2024-06-20'
});

async function test() {
    try {
        console.log('Testing Stripe connection...');
        const customers = await stripe.customers.list({ limit: 1 });
        console.log('Successfully listed customers. Count:', customers.data.length);

        if (customers.data.length > 0) {
            const customerId = customers.data[0].id;
            console.log('Testing Ephemeral Key creation for customer', customerId, '...');
            const key = await stripe.ephemeralKeys.create(
                { customer: customerId },
                { apiVersion: '2024-06-20' }
            );
            console.log('Successfully created Ephemeral Key');
        } else {
            console.log('No customers found, creating one...');
            const newCustomer = await stripe.customers.create({ email: 'test_debug_new@example.com' });
            console.log('Created customer', newCustomer.id);
            
             const key = await stripe.ephemeralKeys.create(
                { customer: newCustomer.id },
                { apiVersion: '2024-06-20' }
            );
            console.log('Successfully created Ephemeral Key');
        }
    } catch (error) {
        console.error('Stripe Error:', error);
    }
}

test();
"""
    
    # Write to a file on host first
    create_cmd = f"cat <<EOF > /root/test_stripe_new.js\n{js_script}\nEOF"
    execute_ssh_command(create_cmd)
    
    # Copy to container
    execute_ssh_command("docker cp /root/test_stripe_new.js glowlab_backend:/app/test_stripe_new.js")
    
    print("\nRunning nodejs stripe test script...")
    execute_ssh_command("docker exec glowlab_backend node test_stripe_new.js")
