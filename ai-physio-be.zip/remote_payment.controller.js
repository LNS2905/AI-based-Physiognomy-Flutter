"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.PaymentController = void 0;
const inversify_express_utils_1 = require("inversify-express-utils");
const tsoa_1 = require("tsoa");
const inversify_1 = require("inversify");
const general_response_1 = require("../business_objects/general.response");
const enums_1 = require("../utils/enums/enums");
let PaymentController = class PaymentController extends tsoa_1.Controller {
    constructor(userService) {
        super();
        this.userService = userService;
    }
    /**
     * Handle successful payment redirect from Stripe
     * @param session_id - Stripe session ID
     * @param userId - User ID
     * @returns Redirect to success page
     */
    async responseSessionPaymentSuccess(session_id, userId, redirect) {
        try {
            const user = await this.userService.updateCredit(session_id, userId);
            // Redirect to success page with user credits
            const redirectUrl = user
                ? `http://localhost:3000/payment-success?credits=${user.credits}`
                : "http://localhost:3000/payment-failed";
            return redirect(302, undefined, { Location: redirectUrl });
        }
        catch (error) {
            console.error("Payment success handler error:", error);
            return redirect(302, undefined, {
                Location: "http://localhost:3000/payment-failed",
            });
        }
    }
    /**
     * Handle cancelled payment redirect from Stripe
     * @param userId - User ID
     * @returns Redirect to cancel page
     */
    async responseSessionPaymentCancel(userId, redirect) {
        return redirect(302, undefined, {
            Location: "http://localhost:3000/payment-cancel",
        });
    }
    /**
     * Test endpoint to verify credit update logic
     * @param sessionId - Stripe session ID
     * @param userId - User ID
     * @returns Updated user with credits
     */
    async testUpdateCredit(sessionId, userId) {
        const result = await this.userService.updateCredit(sessionId, userId);
        return new general_response_1.GeneralResponse(enums_1.SuccessCode.OPERATION_SUCCESS, result);
    }
};
exports.PaymentController = PaymentController;
__decorate([
    (0, tsoa_1.Hidden)(),
    (0, tsoa_1.Get)("/success"),
    (0, inversify_express_utils_1.httpGet)("/success"),
    __param(0, (0, tsoa_1.Query)()),
    __param(1, (0, tsoa_1.Query)()),
    __param(2, (0, tsoa_1.Res)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Number, Function]),
    __metadata("design:returntype", Promise)
], PaymentController.prototype, "responseSessionPaymentSuccess", null);
__decorate([
    (0, tsoa_1.Get)("/cancel"),
    (0, inversify_express_utils_1.httpGet)("/cancel"),
    (0, tsoa_1.Hidden)(),
    __param(0, (0, tsoa_1.Query)()),
    __param(1, (0, tsoa_1.Res)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Number, Function]),
    __metadata("design:returntype", Promise)
], PaymentController.prototype, "responseSessionPaymentCancel", null);
__decorate([
    (0, tsoa_1.Post)("/test-update-credit"),
    (0, inversify_express_utils_1.httpPost)("/test-update-credit"),
    __param(0, (0, tsoa_1.Query)()),
    __param(1, (0, tsoa_1.Query)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Number]),
    __metadata("design:returntype", Promise)
], PaymentController.prototype, "testUpdateCredit", null);
exports.PaymentController = PaymentController = __decorate([
    (0, tsoa_1.Route)("payment"),
    (0, tsoa_1.Tags)("Payment"),
    (0, inversify_express_utils_1.controller)("payment"),
    __param(0, (0, inversify_1.inject)("IUserService")),
    __metadata("design:paramtypes", [Object])
], PaymentController);
//# sourceMappingURL=payment.controller.js.map